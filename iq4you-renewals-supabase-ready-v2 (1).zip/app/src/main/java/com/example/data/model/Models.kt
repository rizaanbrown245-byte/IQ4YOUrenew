package com.example.data.model

import java.time.LocalDate
import java.time.temporal.ChronoUnit

enum class RenewalStatus(val label: String) {
    EXPIRED("Expired"),
    DUE_TODAY("Due Today"),
    EXPIRING_SOON("Expiring Soon"),
    ACTIVE("Active");

    companion object {
        fun fromExpiryDate(expiryDateStr: String): RenewalStatus {
            return try {
                val expiry = LocalDate.parse(expiryDateStr)
                val today = LocalDate.now()
                val days = ChronoUnit.DAYS.between(today, expiry)
                when {
                    days < 0 -> EXPIRED
                    days == 0L -> DUE_TODAY
                    days <= 30 -> EXPIRING_SOON
                    else -> ACTIVE
                }
            } catch (e: Exception) {
                ACTIVE
            }
        }
    }
}

data class Customer(
    val id: Long = 0,
    val name: String,
    val phone: String,
    val email: String,
    val vehicleRegistration: String,
    val vehicleType: String, // Sedan, SUV, Bakkie / Light Commercial, Heavy Truck, Motorcycle
    val vehicleMakeModel: String,
    val licenseDiscNumber: String,
    val expiryDate: String, // "YYYY-MM-DD"
    val renewalFee: Double = 0.0,
    val notes: String = "",
    val lastReminderSent: String? = null
) {
    val status: RenewalStatus
        get() = RenewalStatus.fromExpiryDate(expiryDate)

    val daysUntilExpiry: Long
        get() {
            return try {
                val expiry = LocalDate.parse(expiryDate)
                ChronoUnit.DAYS.between(LocalDate.now(), expiry)
            } catch (e: Exception) {
                999L
            }
        }
}

enum class ReminderChannel(val displayName: String) {
    WHATSAPP("WhatsApp"),
    EMAIL("Email"),
    SYSTEM("System Notification"),
    SMS("SMS")
}

enum class ReminderStatus(val displayName: String) {
    DELIVERED("Delivered"),
    SENT("Sent"),
    QUEUED("Queued"),
    FAILED("Failed")
}

data class ReminderLog(
    val id: Long = 0,
    val customerId: Long,
    val customerName: String,
    val vehiclePlate: String,
    val channel: ReminderChannel,
    val status: ReminderStatus,
    val messageText: String,
    val timestamp: Long = System.currentTimeMillis()
)

data class AppSettings(
    val automaticReminders: Boolean = true,
    val remind30DaysBefore: Boolean = true,
    val remind7DaysBefore: Boolean = true,
    val consolidatePerContact: Boolean = true,
    val reminderTime: String = "09:00 AM",
    val backendUrl: String = "", // Modular placeholder for future free-tier database/API
    val backendConnected: Boolean = true,
    val lastSyncTime: String = "Just now"
)

data class DashboardStats(
    val dueToday: Int,
    val dueThisWeek: Int,
    val expired: Int,
    val totalCustomers: Int,
    val totalReminders: Int,
    val activeCount: Int
)
