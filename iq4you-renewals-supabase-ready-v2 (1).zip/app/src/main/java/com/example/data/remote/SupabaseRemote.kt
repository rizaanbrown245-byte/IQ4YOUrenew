package com.example.data.remote

import android.content.Context
import android.util.Base64
import com.example.BuildConfig
import com.example.data.local.CustomerEntity
import com.example.data.local.ReminderLogEntity
import com.example.data.local.AppSettingsEntity
import com.example.data.local.IQDao
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.time.LocalDateTime
import java.time.format.DateTimeFormatter
import java.util.UUID

class SupabaseRemote(private val context: Context) {
    private val client = OkHttpClient()
    private val prefs = context.getSharedPreferences("supabase_session", Context.MODE_PRIVATE)
    private val jsonType = "application/json".toMediaType()
    private val url get() = BuildConfig.SUPABASE_URL.trimEnd('/')
    private val key get() = BuildConfig.SUPABASE_PUBLISHABLE_KEY

    data class Result(val ok: Boolean, val message: String, val latencyMs: Long = 0)

    private fun configured() = url.startsWith("https://") && key.startsWith("sb_publishable_")

    private fun authHeaders(accessToken: String? = null): Map<String, String> {
        return buildMap {
            put("apikey", key)
            put("Content-Type", "application/json")
            put("Accept", "application/json")
            if (!accessToken.isNullOrBlank()) put("Authorization", "Bearer $accessToken")
        }
    }

    private suspend fun request(
        method: String,
        endpoint: String,
        body: String? = null,
        accessToken: String? = null,
        prefer: String? = null
    ): okhttp3.Response = withContext(Dispatchers.IO) {
        val builder = Request.Builder().url("$url$endpoint")
        authHeaders(accessToken).forEach { (k, v) -> builder.header(k, v) }
        if (prefer != null) builder.header("Prefer", prefer)
        val rb = body?.toRequestBody(jsonType)
        when (method) {
            "GET" -> builder.get()
            "POST" -> builder.post(rb ?: "{}".toRequestBody(jsonType))
            "PATCH" -> builder.patch(rb ?: "{}".toRequestBody(jsonType))
            "DELETE" -> builder.delete(rb)
            else -> builder.method(method, rb)
        }
        client.newCall(builder.build()).execute()
    }

    suspend fun signInAnonymously(): Result = withContext(Dispatchers.IO) {
        if (!configured()) return@withContext Result(false, "Supabase credentials are not configured in this build.")
        val start = System.currentTimeMillis()
        try {
            val existing = prefs.getString("access_token", null)
            if (!existing.isNullOrBlank()) {
                // Validate the current token cheaply.
                request("GET", "/rest/v1/customers?select=id&limit=1", existing).use { r ->
                    if (r.isSuccessful) return@withContext Result(true, "Authenticated", System.currentTimeMillis() - start)
                }
            }

            val refresh = prefs.getString("refresh_token", null)
            if (!refresh.isNullOrBlank()) {
                val refreshBody = JSONObject().put("refresh_token", refresh).toString()
                request("POST", "/auth/v1/token?grant_type=refresh_token", refreshBody).use { r ->
                    if (r.isSuccessful) {
                        val obj = JSONObject(r.body?.string().orEmpty())
                        saveSession(obj)
                        return@withContext Result(true, "Session refreshed", System.currentTimeMillis() - start)
                    }
                }
            }

            val body = "{}"
            request("POST", "/auth/v1/signup", body).use { r ->
                val text = r.body?.string().orEmpty()
                if (!r.isSuccessful) {
                    return@withContext Result(false, "Anonymous sign-in failed (${r.code}): ${text.take(180)}", System.currentTimeMillis() - start)
                }
                val obj = JSONObject(text)
                saveSession(obj)
                Result(true, "Anonymous account connected", System.currentTimeMillis() - start)
            }
        } catch (e: Exception) {
            Result(false, "Network error: ${e.message ?: "unknown error"}", System.currentTimeMillis() - start)
        }
    }

    private fun saveSession(obj: JSONObject) {
        val access = obj.optString("access_token")
        val refresh = obj.optString("refresh_token")
        if (access.isNotBlank()) {
            prefs.edit()
                .putString("access_token", access)
                .putString("refresh_token", refresh)
                .apply()
        }
    }

    private fun accessToken() = prefs.getString("access_token", null)

    suspend fun testConnection(): Result {
        val start = System.currentTimeMillis()
        val auth = signInAnonymously()
        if (!auth.ok) return auth.copy(latencyMs = System.currentTimeMillis() - start)
        return try {
            request("GET", "/rest/v1/customers?select=id&limit=1", accessToken()).use { r ->
                Result(r.isSuccessful, if (r.isSuccessful) "Supabase backend connected" else "Backend returned HTTP ${r.code}", System.currentTimeMillis() - start)
            }
        } catch (e: Exception) {
            Result(false, "Network error: ${e.message ?: "unknown error"}", System.currentTimeMillis() - start)
        }
    }

    suspend fun upsertCustomer(c: CustomerEntity): Result = upsert("customers", customerJson(c))
    suspend fun upsertLog(l: ReminderLogEntity): Result = upsert("reminder_logs", logJson(l))
    suspend fun upsertSettings(s: AppSettingsEntity): Result = upsert("app_settings", settingsJson(s))

    private suspend fun upsert(table: String, obj: JSONObject): Result {
        val auth = signInAnonymously()
        if (!auth.ok) return auth
        return try {
            request("POST", "/rest/v1/$table", obj.toString(), accessToken(), "resolution=merge-duplicates").use { r ->
                Result(r.isSuccessful, if (r.isSuccessful) "Synced" else "Sync failed HTTP ${r.code}: ${r.body?.string()?.take(180)}")
            }
        } catch (e: Exception) {
            Result(false, "Sync error: ${e.message ?: "unknown"}")
        }
    }

    suspend fun deleteCustomer(id: Long) = delete("customers?id=eq.$id")
    suspend fun deleteLog(id: Long) = delete("reminder_logs?id=eq.$id")
    suspend fun clearLogs() = delete("reminder_logs")

    private suspend fun delete(path: String): Result {
        val auth = signInAnonymously()
        if (!auth.ok) return auth
        return try {
            request("DELETE", "/rest/v1/$path", accessToken()).use { r ->
                Result(r.isSuccessful, if (r.isSuccessful) "Deleted remotely" else "Remote delete failed HTTP ${r.code}")
            }
        } catch (e: Exception) {
            Result(false, "Delete error: ${e.message ?: "unknown"}")
        }
    }

    suspend fun pullCustomers(): List<CustomerEntity> = pullArray("/rest/v1/customers?select=*&order=id.asc").map { o ->
        CustomerEntity(
            id = o.optLong("id"),
            name = o.optString("name"),
            phone = o.optString("phone"),
            email = o.optString("email"),
            vehicleRegistration = o.optString("vehicle_registration"),
            vehicleType = o.optString("vehicle_type"),
            vehicleMakeModel = o.optString("vehicle_make_model"),
            licenseDiscNumber = o.optString("license_disc_number"),
            expiryDate = o.optString("expiry_date"),
            renewalFee = o.optDouble("renewal_fee"),
            notes = o.optString("notes"),
            lastReminderSent = if (o.isNull("last_reminder_sent")) null else o.optString("last_reminder_sent")
        )
    }

    suspend fun pullLogs(): List<ReminderLogEntity> = pullArray("/rest/v1/reminder_logs?select=*&order=timestamp.desc").map { o ->
        ReminderLogEntity(
            id = o.optLong("id"),
            customerId = o.optLong("customer_id"),
            customerName = o.optString("customer_name"),
            vehiclePlate = o.optString("vehicle_plate"),
            channel = o.optString("channel"),
            status = o.optString("status"),
            messageText = o.optString("message_text"),
            timestamp = o.optLong("timestamp")
        )
    }

    suspend fun pullSettings(): AppSettingsEntity? {
        val a = pullArray("/rest/v1/app_settings?select=*&id=eq.1&limit=1")
        val o = a.firstOrNull() ?: return null
        return AppSettingsEntity(
            id = 1,
            automaticReminders = o.optBoolean("automatic_reminders", true),
            remind30DaysBefore = o.optBoolean("remind_30_days_before", true),
            remind7DaysBefore = o.optBoolean("remind_7_days_before", true),
            consolidatePerContact = o.optBoolean("consolidate_per_contact", true),
            reminderTime = o.optString("reminder_time", "09:00 AM"),
            backendUrl = BuildConfig.SUPABASE_URL,
            backendConnected = true,
            lastSyncTime = LocalDateTime.now().format(DateTimeFormatter.ofPattern("HH:mm, dd MMM"))
        )
    }

    private suspend fun pullArray(path: String): List<JSONObject> {
        val auth = signInAnonymously()
        if (!auth.ok) return emptyList()
        return try {
            request("GET", path, accessToken()).use { r ->
                if (!r.isSuccessful) emptyList()
                else {
                    val arr = JSONArray(r.body?.string().orEmpty())
                    (0 until arr.length()).map { arr.getJSONObject(it) }
                }
            }
        } catch (_: Exception) { emptyList() }
    }

    fun customerJson(c: CustomerEntity) = JSONObject()
        .put("id", c.id)
        .put("name", c.name)
        .put("phone", c.phone)
        .put("email", c.email)
        .put("vehicle_registration", c.vehicleRegistration)
        .put("vehicle_type", c.vehicleType)
        .put("vehicle_make_model", c.vehicleMakeModel)
        .put("license_disc_number", c.licenseDiscNumber)
        .put("expiry_date", c.expiryDate)
        .put("renewal_fee", c.renewalFee)
        .put("notes", c.notes)
        .put("last_reminder_sent", c.lastReminderSent)

    fun logJson(l: ReminderLogEntity) = JSONObject()
        .put("id", l.id)
        .put("customer_id", l.customerId)
        .put("customer_name", l.customerName)
        .put("vehicle_plate", l.vehiclePlate)
        .put("channel", l.channel)
        .put("status", l.status)
        .put("message_text", l.messageText)
        .put("timestamp", l.timestamp)

    fun settingsJson(s: AppSettingsEntity) = JSONObject()
        .put("id", 1)
        .put("automatic_reminders", s.automaticReminders)
        .put("remind_30_days_before", s.remind30DaysBefore)
        .put("remind_7_days_before", s.remind7DaysBefore)
        .put("consolidate_per_contact", s.consolidatePerContact)
        .put("reminder_time", s.reminderTime)
}
