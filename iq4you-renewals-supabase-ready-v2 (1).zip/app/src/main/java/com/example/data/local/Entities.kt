package com.example.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey
import com.example.data.model.Customer
import com.example.data.model.ReminderChannel
import com.example.data.model.ReminderLog
import com.example.data.model.ReminderStatus

@Entity(tableName = "customers")
data class CustomerEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val phone: String,
    val email: String,
    val vehicleRegistration: String,
    val vehicleType: String,
    val vehicleMakeModel: String,
    val licenseDiscNumber: String,
    val expiryDate: String,
    val renewalFee: Double,
    val notes: String,
    val lastReminderSent: String?
) {
    fun toDomain(): Customer = Customer(
        id = id,
        name = name,
        phone = phone,
        email = email,
        vehicleRegistration = vehicleRegistration,
        vehicleType = vehicleType,
        vehicleMakeModel = vehicleMakeModel,
        licenseDiscNumber = licenseDiscNumber,
        expiryDate = expiryDate,
        renewalFee = renewalFee,
        notes = notes,
        lastReminderSent = lastReminderSent
    )

    companion object {
        fun fromDomain(c: Customer): CustomerEntity = CustomerEntity(
            id = c.id,
            name = c.name,
            phone = c.phone,
            email = c.email,
            vehicleRegistration = c.vehicleRegistration,
            vehicleType = c.vehicleType,
            vehicleMakeModel = c.vehicleMakeModel,
            licenseDiscNumber = c.licenseDiscNumber,
            expiryDate = c.expiryDate,
            renewalFee = c.renewalFee,
            notes = c.notes,
            lastReminderSent = c.lastReminderSent
        )
    }
}

@Entity(tableName = "reminder_logs")
data class ReminderLogEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val customerId: Long,
    val customerName: String,
    val vehiclePlate: String,
    val channel: String,
    val status: String,
    val messageText: String,
    val timestamp: Long
) {
    fun toDomain(): ReminderLog = ReminderLog(
        id = id,
        customerId = customerId,
        customerName = customerName,
        vehiclePlate = vehiclePlate,
        channel = try { ReminderChannel.valueOf(channel) } catch (_: Exception) { ReminderChannel.WHATSAPP },
        status = try { ReminderStatus.valueOf(status) } catch (_: Exception) { ReminderStatus.DELIVERED },
        messageText = messageText,
        timestamp = timestamp
    )

    companion object {
        fun fromDomain(l: ReminderLog): ReminderLogEntity = ReminderLogEntity(
            id = l.id,
            customerId = l.customerId,
            customerName = l.customerName,
            vehiclePlate = l.vehiclePlate,
            channel = l.channel.name,
            status = l.status.name,
            messageText = l.messageText,
            timestamp = l.timestamp
        )
    }
}

@Entity(tableName = "app_settings")
data class AppSettingsEntity(
    @PrimaryKey val id: Int = 1,
    val automaticReminders: Boolean = true,
    val remind30DaysBefore: Boolean = true,
    val remind7DaysBefore: Boolean = true,
    val consolidatePerContact: Boolean = true,
    val reminderTime: String = "09:00 AM",
    val backendUrl: String = "",
    val backendConnected: Boolean = true,
    val lastSyncTime: String = "Just now"
)
