package com.example.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.sqlite.db.SupportSQLiteDatabase
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import java.time.LocalDate

@Database(
    entities = [
        CustomerEntity::class,
        ReminderLogEntity::class,
        AppSettingsEntity::class
    ],
    version = 1,
    exportSchema = false
)
abstract class IQDatabase : RoomDatabase() {
    abstract fun iqDao(): IQDao

    companion object {
        @Volatile
        private var INSTANCE: IQDatabase? = null

        fun getDatabase(context: Context): IQDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    IQDatabase::class.java,
                    "iq4you_renewals.db"
                )
                    .addCallback(DatabaseCallback())
                    .build()
                INSTANCE = instance
                instance
            }
        }

        private class DatabaseCallback : RoomDatabase.Callback() {
            override fun onCreate(db: SupportSQLiteDatabase) {
                super.onCreate(db)
                INSTANCE?.let { database ->
                    CoroutineScope(Dispatchers.IO).launch {
                        populateInitialData(database.iqDao())
                    }
                }
            }
        }

        suspend fun populateInitialData(dao: IQDao) {
            val today = LocalDate.now()

            val seedCustomers = listOf(
                CustomerEntity(
                    id = 1,
                    name = "Johan Van Der Merwe",
                    phone = "+27 82 555 1928",
                    email = "johan.vdm@apexlogistics.co.za",
                    vehicleRegistration = "CA 928-142",
                    vehicleType = "Bakkie / Pickup",
                    vehicleMakeModel = "Toyota Hilux 2.8 GD-6 Double Cab",
                    licenseDiscNumber = "SA-MV-928142-X",
                    expiryDate = today.minusDays(5).toString(),
                    renewalFee = 540.0,
                    notes = "Fleet vehicle #04. Primary commercial workhorse.",
                    lastReminderSent = "WhatsApp sent 3 days ago"
                ),
                CustomerEntity(
                    id = 2,
                    name = "Lerato Mokoena",
                    phone = "+27 73 892 4410",
                    email = "lerato.m@designhaus.co.za",
                    vehicleRegistration = "GP 412-881",
                    vehicleType = "SUV",
                    vehicleMakeModel = "Mazda CX-5 2.0 Dynamic",
                    licenseDiscNumber = "SA-MV-412881-A",
                    expiryDate = today.toString(),
                    renewalFee = 460.0,
                    notes = "Urgent: License disc expires today! Call or WhatsApp.",
                    lastReminderSent = "SMS sent today at 08:30"
                ),
                CustomerEntity(
                    id = 3,
                    name = "Thabo Sithole",
                    phone = "+27 81 223 9044",
                    email = "tsithole@freightways.co.za",
                    vehicleRegistration = "ZN 773-201",
                    vehicleType = "Commercial Truck",
                    vehicleMakeModel = "Isuzu NPR 400 Dropside",
                    licenseDiscNumber = "SA-MV-773201-B",
                    expiryDate = today.plusDays(2).toString(),
                    renewalFee = 890.0,
                    notes = "Requires heavy vehicle roadworthy cert with renewal.",
                    lastReminderSent = "WhatsApp sent yesterday"
                ),
                CustomerEntity(
                    id = 4,
                    name = "David Richardson",
                    phone = "+27 84 901 3321",
                    email = "drichardson@coastallaw.co.za",
                    vehicleRegistration = "CA 512-390",
                    vehicleType = "Sedan",
                    vehicleMakeModel = "BMW 320d M-Sport",
                    licenseDiscNumber = "SA-MV-512390-D",
                    expiryDate = today.plusDays(5).toString(),
                    renewalFee = 480.0,
                    notes = "Executive account. Prefers email reminder first.",
                    lastReminderSent = "Email queued"
                ),
                CustomerEntity(
                    id = 5,
                    name = "Priya Naidoo",
                    phone = "+27 72 456 7890",
                    email = "priya.naidoo@medicare.org",
                    vehicleRegistration = "ND 602-114",
                    vehicleType = "Sedan",
                    vehicleMakeModel = "Volkswagen Polo 1.0 TSI Comfortline",
                    licenseDiscNumber = "SA-MV-602114-K",
                    expiryDate = today.minusDays(14).toString(),
                    renewalFee = 420.0,
                    notes = "Overdue penalty accumulating. Follow up urgently.",
                    lastReminderSent = "WhatsApp delivered"
                ),
                CustomerEntity(
                    id = 6,
                    name = "Kagiso Khumalo",
                    phone = "+27 83 345 6712",
                    email = "kagiso@translink.net",
                    vehicleRegistration = "GP 882-901",
                    vehicleType = "Commercial Van",
                    vehicleMakeModel = "Mercedes-Benz Sprinter 516 CDI",
                    licenseDiscNumber = "SA-MV-882901-M",
                    expiryDate = today.plusDays(12).toString(),
                    renewalFee = 720.0,
                    notes = "Monthly fleet check scheduled.",
                    lastReminderSent = null
                ),
                CustomerEntity(
                    id = 7,
                    name = "Anika Smit",
                    phone = "+27 76 112 3345",
                    email = "anika.smit@capevineyards.co.za",
                    vehicleRegistration = "CA 319-804",
                    vehicleType = "SUV",
                    vehicleMakeModel = "Toyota Fortuner 2.4 GD-6",
                    licenseDiscNumber = "SA-MV-319804-R",
                    expiryDate = today.plusDays(24).toString(),
                    renewalFee = 510.0,
                    notes = "Annual renewal. Disc collection requested in Paarl.",
                    lastReminderSent = null
                ),
                CustomerEntity(
                    id = 8,
                    name = "Sipho Ndlovu",
                    phone = "+27 82 789 0123",
                    email = "sipho.n@urbanpulse.co.za",
                    vehicleRegistration = "GP 109-773",
                    vehicleType = "Motorcycle",
                    vehicleMakeModel = "BMW R1250 GS Adventure",
                    licenseDiscNumber = "SA-MV-109773-P",
                    expiryDate = today.plusMonths(2).toString(),
                    renewalFee = 290.0,
                    notes = "Weekend adventure bike. Owner active.",
                    lastReminderSent = null
                ),
                CustomerEntity(
                    id = 9,
                    name = "Michael Botha",
                    phone = "+27 83 991 2288",
                    email = "mbotha@valleydairy.co.za",
                    vehicleRegistration = "CA 701-449",
                    vehicleType = "Bakkie / Pickup",
                    vehicleMakeModel = "Ford Ranger 2.0 Single Turbo XL",
                    licenseDiscNumber = "SA-MV-701449-C",
                    expiryDate = today.plusMonths(3).toString(),
                    renewalFee = 490.0,
                    notes = "Farm vehicle. In good standing.",
                    lastReminderSent = null
                )
            )

            dao.insertCustomers(seedCustomers)

            val now = System.currentTimeMillis()
            val hourMs = 3600_000L
            val dayMs = 86400_000L

            val seedLogs = listOf(
                ReminderLogEntity(
                    id = 1,
                    customerId = 2,
                    customerName = "Lerato Mokoena",
                    vehiclePlate = "GP 412-881",
                    channel = "WHATSAPP",
                    status = "DELIVERED",
                    messageText = "Hello Lerato, vehicle license GP 412-881 (Mazda CX-5) is DUE TODAY. Please renew to avoid penalty fees.",
                    timestamp = now - (2 * hourMs)
                ),
                ReminderLogEntity(
                    id = 2,
                    customerId = 1,
                    customerName = "Johan Van Der Merwe",
                    vehiclePlate = "CA 928-142",
                    channel = "WHATSAPP",
                    status = "DELIVERED",
                    messageText = "Hi Johan, reminder from IQ4YOU: Vehicle CA 928-142 license disc has expired. Renew online or contact us.",
                    timestamp = now - (1 * dayMs)
                ),
                ReminderLogEntity(
                    id = 3,
                    customerId = 3,
                    customerName = "Thabo Sithole",
                    vehiclePlate = "ZN 773-201",
                    channel = "EMAIL",
                    status = "SENT",
                    messageText = "IQ4YOU Notice: Commercial vehicle ZN 773-201 expiry on ${today.plusDays(2)}. Roadworthy certification required.",
                    timestamp = now - (2 * dayMs)
                ),
                ReminderLogEntity(
                    id = 4,
                    customerId = 5,
                    customerName = "Priya Naidoo",
                    vehiclePlate = "ND 602-114",
                    channel = "WHATSAPP",
                    status = "DELIVERED",
                    messageText = "Urgent: Vehicle ND 602-114 disc expired 14 days ago. Late penalty applies. IQ4YOU renewal assistance available.",
                    timestamp = now - (3 * dayMs)
                ),
                ReminderLogEntity(
                    id = 5,
                    customerId = 4,
                    customerName = "David Richardson",
                    vehiclePlate = "CA 512-390",
                    channel = "SYSTEM",
                    status = "QUEUED",
                    messageText = "Scheduled 7-day upcoming renewal notice for BMW 320d CA 512-390.",
                    timestamp = now - (4 * dayMs)
                )
            )

            dao.insertReminderLogs(seedLogs)

            val initialSettings = AppSettingsEntity(
                id = 1,
                automaticReminders = true,
                remind30DaysBefore = true,
                remind7DaysBefore = true,
                consolidatePerContact = true,
                reminderTime = "08:30 AM",
                backendUrl = "",
                backendConnected = true,
                lastSyncTime = "Live Local Sync"
            )
            dao.saveSettings(initialSettings)
        }
    }
}
