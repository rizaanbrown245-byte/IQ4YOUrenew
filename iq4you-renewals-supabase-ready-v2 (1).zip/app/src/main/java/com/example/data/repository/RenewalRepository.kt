package com.example.data.repository

import com.example.data.model.AppSettings
import com.example.data.model.Customer
import com.example.data.model.DashboardStats
import com.example.data.model.ReminderChannel
import com.example.data.model.ReminderLog
import kotlinx.coroutines.flow.Flow

/**
 * Clean data interface for IQ4YOU Renewals.
 * Decoupled from the storage implementation so that this can easily be backed by
 * Room local database today and swapped or synced with a free-tier remote backend later.
 */
interface RenewalRepository {
    fun getCustomers(): Flow<List<Customer>>
    fun getCustomerById(id: Long): Flow<Customer?>
    suspend fun addCustomer(customer: Customer): Long
    suspend fun updateCustomer(customer: Customer)
    suspend fun deleteCustomer(id: Long)

    fun getDashboardStats(): Flow<DashboardStats>

    fun getReminderLogs(): Flow<List<ReminderLog>>
    suspend fun logReminder(log: ReminderLog): Long
    suspend fun clearReminderLogs()

    fun getSettings(): Flow<AppSettings>
    suspend fun saveSettings(settings: AppSettings)

    suspend fun sendTestReminder(customerId: Long?, channel: ReminderChannel): ReminderLog
    suspend fun testBackendConnection(endpointUrl: String): BackendTestResult
    suspend fun resetToSampleData()
    suspend fun ensureDataInitialized()
}

data class BackendTestResult(
    val isSuccess: Boolean,
    val latencyMs: Long,
    val message: String,
    val timestamp: String
)
