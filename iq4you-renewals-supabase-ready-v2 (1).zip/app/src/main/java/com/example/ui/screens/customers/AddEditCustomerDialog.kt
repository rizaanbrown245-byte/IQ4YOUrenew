package com.example.ui.screens.customers

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.DirectionsCar
import androidx.compose.material.icons.filled.DocumentScanner
import androidx.compose.material.icons.filled.Person
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardCapitalization
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.data.model.Customer
import com.example.data.util.LicenseDiscParser
import com.example.ui.screens.dashboard.ScanLicenseDialog
import com.example.ui.theme.CharcoalBorder
import com.example.ui.theme.CharcoalCard
import com.example.ui.theme.CharcoalElevated
import com.example.ui.theme.IQYellow
import com.example.ui.theme.StatusGreen
import com.example.ui.theme.TextDark
import com.example.ui.theme.TextLightGray
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextWhite
import com.example.ui.viewmodel.ScannedLicenseData
import java.time.LocalDate

@Composable
fun AddEditCustomerDialog(
    initialCustomer: Customer? = null,
    prefillRegistration: String? = null,
    prefillMakeModel: String? = null,
    prefillType: String? = null,
    prefillDiscNumber: String? = null,
    prefillExpiryDate: String? = null,
    prefillName: String? = null,
    prefillPhone: String? = null,
    prefillFee: Double? = null,
    onDismiss: () -> Unit,
    onSaveCustomer: (Customer) -> Unit
) {
    var name by remember {
        mutableStateOf(initialCustomer?.name ?: prefillName ?: "")
    }
    var phone by remember {
        mutableStateOf(initialCustomer?.phone ?: prefillPhone ?: "+27 ")
    }
    var email by remember {
        mutableStateOf(initialCustomer?.email ?: "")
    }
    var registration by remember {
        mutableStateOf(initialCustomer?.vehicleRegistration ?: prefillRegistration ?: "")
    }
    var makeModel by remember {
        mutableStateOf(initialCustomer?.vehicleMakeModel ?: prefillMakeModel ?: "")
    }
    var discNumber by remember {
        mutableStateOf(initialCustomer?.licenseDiscNumber ?: prefillDiscNumber ?: "")
    }
    var expiryDate by remember {
        mutableStateOf(
            initialCustomer?.expiryDate
                ?: prefillExpiryDate
                ?: LocalDate.now().plusMonths(1).toString()
        )
    }
    var renewalFeeStr by remember {
        mutableStateOf(
            initialCustomer?.renewalFee?.toString()
                ?: prefillFee?.toString()
                ?: "480.0"
        )
    }
    var notes by remember {
        mutableStateOf(initialCustomer?.notes ?: "")
    }

    val vehicleTypes = listOf("Sedan", "SUV", "Bakkie / Pickup", "Commercial Truck", "Commercial Van", "Motorcycle")
    var selectedVehicleType by remember {
        mutableStateOf(
            initialCustomer?.vehicleType ?: prefillType ?: vehicleTypes[0]
        )
    }

    var errorMessage by remember { mutableStateOf<String?>(null) }
    var showScanDialog by remember { mutableStateOf(false) }
    var autoFilledBanner by remember { mutableStateOf<String?>(null) }
    val sampleDiscs = remember { LicenseDiscParser.getSampleDiscs() }

    val applyScannedData: (ScannedLicenseData) -> Unit = { scanned ->
        registration = scanned.vehiclePlate
        makeModel = scanned.vehicleMakeModel
        selectedVehicleType = scanned.vehicleType
        discNumber = scanned.licenseDiscNumber
        expiryDate = scanned.expiryDate
        renewalFeeStr = scanned.renewalFee.toString()
        if (scanned.customerName.isNotBlank() && (name.isBlank() || name == "New Customer")) {
            name = scanned.customerName
        }
        if (scanned.phone.isNotBlank() && (phone.isBlank() || phone == "+27 ")) {
            phone = scanned.phone
        }
        autoFilledBanner = "Auto-filled from ${scanned.vehiclePlate} (${scanned.vehicleMakeModel})"
        showScanDialog = false
    }

    Dialog(onDismissRequest = onDismiss) {
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 12.dp),
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = CharcoalCard),
            border = BorderStroke(1.dp, CharcoalBorder)
        ) {
            Column(
                modifier = Modifier
                    .padding(20.dp)
                    .verticalScroll(rememberScrollState())
            ) {
                // Title Row
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = if (initialCustomer != null) "Edit Customer & Vehicle" else "Add New Customer",
                            style = MaterialTheme.typography.titleMedium,
                            color = TextWhite,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "Vehicle renewal & license tracking",
                            fontSize = 11.sp,
                            color = TextMuted
                        )
                    }

                    IconButton(
                        onClick = onDismiss,
                        modifier = Modifier.size(28.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Close,
                            contentDescription = "Close",
                            tint = TextMuted
                        )
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                // Auto-Fill from License Disc Action Box
                Surface(
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("box_autofill_license_disc"),
                    shape = RoundedCornerShape(12.dp),
                    color = CharcoalElevated,
                    border = BorderStroke(1.dp, IQYellow.copy(alpha = 0.5f))
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                modifier = Modifier.weight(1f)
                            ) {
                                Surface(
                                    shape = RoundedCornerShape(6.dp),
                                    color = IQYellow
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.DocumentScanner,
                                        contentDescription = null,
                                        tint = TextDark,
                                        modifier = Modifier
                                            .padding(4.dp)
                                            .size(16.dp)
                                    )
                                }
                                Spacer(modifier = Modifier.width(8.dp))
                                Column {
                                    Text(
                                        text = "Auto-Fill from License Disc",
                                        color = TextWhite,
                                        fontSize = 13.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                    Text(
                                        text = "Scan NaTIS barcode or test presets",
                                        color = TextMuted,
                                        fontSize = 10.sp
                                    )
                                }
                            }

                            Button(
                                onClick = { showScanDialog = true },
                                colors = ButtonDefaults.buttonColors(containerColor = IQYellow),
                                shape = RoundedCornerShape(8.dp),
                                modifier = Modifier.testTag("btn_open_disc_scanner")
                            ) {
                                Text(
                                    text = "Scan Disc",
                                    color = TextDark,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 11.sp
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(8.dp))

                        // Quick 1-tap presets for testing
                        Text(
                            text = "Quick 1-tap auto-fill presets:",
                            fontSize = 10.sp,
                            color = TextLightGray
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .horizontalScroll(rememberScrollState()),
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            sampleDiscs.forEach { sample ->
                                Surface(
                                    shape = RoundedCornerShape(6.dp),
                                    color = CharcoalCard,
                                    border = BorderStroke(1.dp, CharcoalBorder),
                                    modifier = Modifier.clickable { applyScannedData(sample) }
                                ) {
                                    Text(
                                        text = "${sample.vehiclePlate} (${sample.vehicleType.take(6)})",
                                        color = IQYellow,
                                        fontSize = 10.sp,
                                        fontWeight = FontWeight.Medium,
                                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                                    )
                                }
                            }
                        }

                        if (autoFilledBanner != null) {
                            Spacer(modifier = Modifier.height(8.dp))
                            Surface(
                                shape = RoundedCornerShape(6.dp),
                                color = StatusGreen.copy(alpha = 0.15f),
                                border = BorderStroke(1.dp, StatusGreen)
                            ) {
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(horizontal = 8.dp, vertical = 5.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.CheckCircle,
                                        contentDescription = null,
                                        tint = StatusGreen,
                                        modifier = Modifier.size(14.dp)
                                    )
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text(
                                        text = autoFilledBanner!!,
                                        color = StatusGreen,
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.SemiBold,
                                        modifier = Modifier.weight(1f)
                                    )
                                }
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                // Customer details
                Text(
                    text = "CUSTOMER INFORMATION",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    color = IQYellow,
                    letterSpacing = 0.5.sp
                )
                Spacer(modifier = Modifier.height(6.dp))

                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it },
                    label = { Text("Customer Name / Business") },
                    placeholder = { Text("e.g. Johan Van Der Merwe") },
                    leadingIcon = { Icon(Icons.Default.Person, contentDescription = null, tint = IQYellow) },
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("input_customer_name"),
                    singleLine = true,
                    colors = customTextFieldColors()
                )

                Spacer(modifier = Modifier.height(8.dp))

                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = phone,
                        onValueChange = { phone = it },
                        label = { Text("Phone / WhatsApp") },
                        modifier = Modifier
                            .weight(1f)
                            .testTag("input_customer_phone"),
                        singleLine = true,
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                        colors = customTextFieldColors()
                    )

                    OutlinedTextField(
                        value = email,
                        onValueChange = { email = it },
                        label = { Text("Email") },
                        modifier = Modifier
                            .weight(1f)
                            .testTag("input_customer_email"),
                        singleLine = true,
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Email),
                        colors = customTextFieldColors()
                    )
                }

                Spacer(modifier = Modifier.height(16.dp))

                // Vehicle Details
                Text(
                    text = "VEHICLE & RENEWAL DETAILS",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    color = IQYellow,
                    letterSpacing = 0.5.sp
                )
                Spacer(modifier = Modifier.height(6.dp))

                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = registration,
                        onValueChange = { registration = it.uppercase() },
                        label = { Text("Registration Plate") },
                        placeholder = { Text("CA 123-456") },
                        leadingIcon = { Icon(Icons.Default.DirectionsCar, contentDescription = null, tint = IQYellow) },
                        modifier = Modifier
                            .weight(1f)
                            .testTag("input_vehicle_plate"),
                        singleLine = true,
                        keyboardOptions = KeyboardOptions(capitalization = KeyboardCapitalization.Characters),
                        colors = customTextFieldColors()
                    )

                    OutlinedTextField(
                        value = discNumber,
                        onValueChange = { discNumber = it },
                        label = { Text("Disc Number / Barcode") },
                        modifier = Modifier.weight(1f),
                        singleLine = true,
                        colors = customTextFieldColors()
                    )
                }

                Spacer(modifier = Modifier.height(8.dp))

                OutlinedTextField(
                    value = makeModel,
                    onValueChange = { makeModel = it },
                    label = { Text("Make & Model") },
                    placeholder = { Text("e.g. Toyota Hilux 2.8 GD-6") },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true,
                    colors = customTextFieldColors()
                )

                Spacer(modifier = Modifier.height(8.dp))

                // Vehicle Type selector chips
                Text(text = "Vehicle Category", color = TextLightGray, fontSize = 12.sp)
                Spacer(modifier = Modifier.height(4.dp))
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    vehicleTypes.forEach { type ->
                        val isSelected = selectedVehicleType == type
                        FilterChip(
                            selected = isSelected,
                            onClick = { selectedVehicleType = type },
                            label = { Text(type, fontSize = 11.sp) },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = IQYellow,
                                selectedLabelColor = TextDark,
                                containerColor = CharcoalElevated,
                                labelColor = TextLightGray
                            ),
                            border = BorderStroke(1.dp, if (isSelected) IQYellow else CharcoalBorder)
                        )
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                // Expiry Date and Fee
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = expiryDate,
                        onValueChange = { expiryDate = it },
                        label = { Text("Expiry Date (YYYY-MM-DD)") },
                        modifier = Modifier
                            .weight(1.2f)
                            .testTag("input_expiry_date"),
                        singleLine = true,
                        colors = customTextFieldColors()
                    )

                    OutlinedTextField(
                        value = renewalFeeStr,
                        onValueChange = { renewalFeeStr = it },
                        label = { Text("Renewal Fee (R)") },
                        modifier = Modifier.weight(0.8f),
                        singleLine = true,
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                        colors = customTextFieldColors()
                    )
                }

                Spacer(modifier = Modifier.height(4.dp))

                // Quick expiry presets
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    val today = LocalDate.now()
                    QuickDateButton("Due Today") { expiryDate = today.toString() }
                    QuickDateButton("+7 Days") { expiryDate = today.plusDays(7).toString() }
                    QuickDateButton("+30 Days") { expiryDate = today.plusDays(30).toString() }
                    QuickDateButton("+1 Year") { expiryDate = today.plusYears(1).toString() }
                }

                Spacer(modifier = Modifier.height(8.dp))

                OutlinedTextField(
                    value = notes,
                    onValueChange = { notes = it },
                    label = { Text("Notes (Fleet #, instructions)") },
                    modifier = Modifier.fillMaxWidth(),
                    maxLines = 3,
                    colors = customTextFieldColors()
                )

                if (errorMessage != null) {
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = errorMessage!!,
                        color = MaterialTheme.colorScheme.error,
                        fontSize = 12.sp
                    )
                }

                Spacer(modifier = Modifier.height(18.dp))

                // Actions
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    OutlinedButton(
                        onClick = onDismiss,
                        modifier = Modifier.weight(1f),
                        shape = RoundedCornerShape(10.dp),
                        border = BorderStroke(1.dp, CharcoalBorder)
                    ) {
                        Text("Cancel", color = TextWhite)
                    }

                    Button(
                        onClick = {
                            if (name.isBlank()) {
                                errorMessage = "Customer name is required"
                                return@Button
                            }
                            if (registration.isBlank()) {
                                errorMessage = "Vehicle registration is required"
                                return@Button
                            }
                            val parsedFee = renewalFeeStr.toDoubleOrNull() ?: 0.0

                            val newOrUpdated = Customer(
                                id = initialCustomer?.id ?: 0,
                                name = name.trim(),
                                phone = phone.trim(),
                                email = email.trim(),
                                vehicleRegistration = registration.trim().uppercase(),
                                vehicleType = selectedVehicleType,
                                vehicleMakeModel = if (makeModel.isBlank()) "Standard Vehicle" else makeModel.trim(),
                                licenseDiscNumber = if (discNumber.isBlank()) "SA-${registration.replace(" ", "")}" else discNumber.trim(),
                                expiryDate = expiryDate.trim(),
                                renewalFee = parsedFee,
                                notes = notes.trim(),
                                lastReminderSent = initialCustomer?.lastReminderSent
                            )
                            onSaveCustomer(newOrUpdated)
                        },
                        modifier = Modifier
                            .weight(1.3f)
                            .testTag("submit_customer_button"),
                        shape = RoundedCornerShape(10.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = IQYellow)
                    ) {
                        Text(
                            text = if (initialCustomer != null) "Save Changes" else "Create Customer",
                            color = TextDark,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }
        }
    }

    if (showScanDialog) {
        ScanLicenseDialog(
            onDismiss = { showScanDialog = false },
            onScanSuccess = applyScannedData
        )
    }
}

@Composable
private fun QuickDateButton(label: String, onClick: () -> Unit) {
    Surface(
        shape = RoundedCornerShape(6.dp),
        color = CharcoalElevated,
        border = BorderStroke(1.dp, CharcoalBorder),
        onClick = onClick
    ) {
        Text(
            text = label,
            color = IQYellow,
            fontSize = 10.sp,
            fontWeight = FontWeight.SemiBold,
            modifier = Modifier.padding(horizontal = 6.dp, vertical = 3.dp)
        )
    }
}

@Composable
private fun customTextFieldColors() = OutlinedTextFieldDefaults.colors(
    focusedBorderColor = IQYellow,
    unfocusedBorderColor = CharcoalBorder,
    focusedLabelColor = IQYellow,
    unfocusedLabelColor = TextMuted,
    cursorColor = IQYellow,
    focusedTextColor = TextWhite,
    unfocusedTextColor = TextWhite,
    focusedContainerColor = CharcoalElevated,
    unfocusedContainerColor = CharcoalElevated
)
