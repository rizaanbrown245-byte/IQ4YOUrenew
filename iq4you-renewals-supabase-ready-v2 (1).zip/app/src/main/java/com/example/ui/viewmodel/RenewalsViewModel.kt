package com.example.ui.viewmodel

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.widget.Toast
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.data.model.AppSettings
import com.example.data.model.Customer
import com.example.data.model.DashboardStats
import com.example.data.model.ReminderChannel
import com.example.data.model.ReminderLog
import com.example.data.model.ReminderStatus
import com.example.data.model.RenewalStatus
import com.example.data.repository.BackendTestResult
import com.example.data.repository.RenewalRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.time.LocalDate
import java.time.YearMonth
import java.time.format.DateTimeFormatter

enum class CustomerFilterTab(val title: String) {
    ALL("All"),
    ACTIVE("Active"),
    EXPIRING_SOON("Expiring soon"),
    EXPIRED("Expired")
}

data class ScannedLicenseData(
    val vehiclePlate: String,
    val vehicleMakeModel: String,
    val vehicleType: String,
    val licenseDiscNumber: String,
    val expiryDate: String,
    val customerName: String = "",
    val phone: String = "",
    val renewalFee: Double = 500.0
)

class RenewalsViewModel(
    private val repository: RenewalRepository
) : ViewModel() {

    init {
        viewModelScope.launch {
            repository.ensureDataInitialized()
        }
    }

    val allCustomers: StateFlow<List<Customer>> = repository.getCustomers()
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

    val dashboardStats: StateFlow<DashboardStats> = repository.getDashboardStats()
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = DashboardStats(0, 0, 0, 0, 0, 0)
        )

    val reminderLogs: StateFlow<List<ReminderLog>> = repository.getReminderLogs()
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

    val appSettings: StateFlow<AppSettings> = repository.getSettings()
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = AppSettings()
        )

    // Customer screen state
    private val _searchQuery = MutableStateFlow("")
    val searchQuery = _searchQuery.asStateFlow()

    private val _selectedFilterTab = MutableStateFlow(CustomerFilterTab.ALL)
    val selectedFilterTab = _selectedFilterTab.asStateFlow()

    val filteredCustomers: StateFlow<List<Customer>> = combine(
        allCustomers,
        _searchQuery,
        _selectedFilterTab
    ) { list, query, filter ->
        val trimmed = query.trim().lowercase()
        list.filter { customer ->
            val matchesQuery = trimmed.isEmpty() ||
                customer.name.lowercase().contains(trimmed) ||
                customer.vehicleRegistration.lowercase().contains(trimmed) ||
                customer.vehicleType.lowercase().contains(trimmed) ||
                customer.vehicleMakeModel.lowercase().contains(trimmed)

            val matchesFilter = when (filter) {
                CustomerFilterTab.ALL -> true
                CustomerFilterTab.ACTIVE -> customer.status == RenewalStatus.ACTIVE
                CustomerFilterTab.EXPIRING_SOON -> customer.status == RenewalStatus.EXPIRING_SOON || customer.status == RenewalStatus.DUE_TODAY
                CustomerFilterTab.EXPIRED -> customer.status == RenewalStatus.EXPIRED
            }

            matchesQuery && matchesFilter
        }
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList()
    )

    // Needs attention list for Dashboard (expired, due today, or due in next 7 days)
    val needsAttentionCustomers: StateFlow<List<Customer>> = allCustomers.combine(_searchQuery) { list, _ ->
        list.filter { customer ->
            customer.status == RenewalStatus.EXPIRED ||
                customer.status == RenewalStatus.DUE_TODAY ||
                (customer.status == RenewalStatus.EXPIRING_SOON && customer.daysUntilExpiry in 1..7)
        }.sortedBy { it.daysUntilExpiry }
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList()
    )

    // Calendar state
    private val _calendarMonth = MutableStateFlow(YearMonth.now())
    val calendarMonth = _calendarMonth.asStateFlow()

    private val _selectedCalendarDate = MutableStateFlow<LocalDate?>(null)
    val selectedCalendarDate = _selectedCalendarDate.asStateFlow()

    val calendarMonthlyRenewals: StateFlow<List<Customer>> = combine(
        allCustomers,
        _calendarMonth,
        _selectedCalendarDate
    ) { list, month, selectedDate ->
        if (selectedDate != null) {
            val dateStr = selectedDate.toString()
            list.filter { it.expiryDate == dateStr }
        } else {
            list.filter { customer ->
                try {
                    val date = LocalDate.parse(customer.expiryDate)
                    YearMonth.from(date) == month
                } catch (e: Exception) {
                    false
                }
            }.sortedBy { it.expiryDate }
        }
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList()
    )

    // Backend test state
    private val _backendTestStatus = MutableStateFlow<BackendTestResult?>(null)
    val backendTestStatus = _backendTestStatus.asStateFlow()

    private val _isBackendTesting = MutableStateFlow(false)
    val isBackendTesting = _isBackendTesting.asStateFlow()

    fun setSearchQuery(query: String) {
        _searchQuery.value = query
    }

    fun setFilterTab(tab: CustomerFilterTab) {
        _selectedFilterTab.value = tab
    }

    fun nextMonth() {
        _calendarMonth.value = _calendarMonth.value.plusMonths(1)
        _selectedCalendarDate.value = null
    }

    fun previousMonth() {
        _calendarMonth.value = _calendarMonth.value.minusMonths(1)
        _selectedCalendarDate.value = null
    }

    fun selectCalendarDate(date: LocalDate?) {
        if (_selectedCalendarDate.value == date) {
            _selectedCalendarDate.value = null // toggle off
        } else {
            _selectedCalendarDate.value = date
        }
    }

    fun addCustomer(customer: Customer) {
        viewModelScope.launch {
            repository.addCustomer(customer)
        }
    }

    fun updateCustomer(customer: Customer) {
        viewModelScope.launch {
            repository.updateCustomer(customer)
        }
    }

    fun deleteCustomer(id: Long) {
        viewModelScope.launch {
            repository.deleteCustomer(id)
        }
    }

    fun sendDirectWhatsApp(context: Context, customer: Customer) {
        viewModelScope.launch {
            val cleanPhone = customer.phone.replace("[^0-9+]".toRegex(), "")
            val message = "Hello ${customer.name}, this is IQ4YOU Renewals. Friendly reminder that your vehicle license plate ${customer.vehicleRegistration} (${customer.vehicleMakeModel}) renewal is due on ${customer.expiryDate}. Please let us know if you'd like us to assist with your disc renewal!"
            val uri = Uri.parse("https://api.whatsapp.com/send?phone=$cleanPhone&text=${Uri.encode(message)}")

            val intent = Intent(Intent.ACTION_VIEW, uri)
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            try {
                context.startActivity(intent)
            } catch (e: Exception) {
                // Fallback to generic message intent or toast
                Toast.makeText(context, "Opening WhatsApp for ${customer.name}...", Toast.LENGTH_SHORT).show()
            }

            // Log this reminder in audit trail
            repository.logReminder(
                ReminderLog(
                    customerId = customer.id,
                    customerName = customer.name,
                    vehiclePlate = customer.vehicleRegistration,
                    channel = ReminderChannel.WHATSAPP,
                    status = ReminderStatus.DELIVERED,
                    messageText = message,
                    timestamp = System.currentTimeMillis()
                )
            )
            repository.updateCustomer(customer.copy(lastReminderSent = "WhatsApp sent just now"))
        }
    }

    fun sendDirectEmail(context: Context, customer: Customer) {
        viewModelScope.launch {
            val subject = "IQ4YOU Vehicle License Renewal: ${customer.vehicleRegistration}"
            val body = "Dear ${customer.name},\n\nThis is a renewal notification from IQ4YOU Renewals regarding your vehicle ${customer.vehicleMakeModel} (Registration: ${customer.vehicleRegistration}).\n\nYour license disc renewal expiry date is ${customer.expiryDate}.\nRenewal Fee: R${"%.2f".format(customer.renewalFee)}\n\nPlease ensure your disc is renewed on time to avoid penalties.\n\nWarm regards,\nIQ4YOU Renewals"

            val intent = Intent(Intent.ACTION_SENDTO).apply {
                data = Uri.parse("mailto:${customer.email}")
                putExtra(Intent.EXTRA_SUBJECT, subject)
                putExtra(Intent.EXTRA_TEXT, body)
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }

            try {
                context.startActivity(intent)
            } catch (e: Exception) {
                Toast.makeText(context, "Email client launched for ${customer.email}", Toast.LENGTH_SHORT).show()
            }

            repository.logReminder(
                ReminderLog(
                    customerId = customer.id,
                    customerName = customer.name,
                    vehiclePlate = customer.vehicleRegistration,
                    channel = ReminderChannel.EMAIL,
                    status = ReminderStatus.SENT,
                    messageText = "Email notice sent to ${customer.email} for vehicle ${customer.vehicleRegistration}.",
                    timestamp = System.currentTimeMillis()
                )
            )
            repository.updateCustomer(customer.copy(lastReminderSent = "Email sent just now"))
        }
    }

    fun sendTestReminder(context: Context) {
        viewModelScope.launch {
            val log = repository.sendTestReminder(null, ReminderChannel.WHATSAPP)
            Toast.makeText(context, "Test reminder logged to audit history: ${log.customerName}", Toast.LENGTH_LONG).show()
        }
    }

    fun updateSettings(settings: AppSettings) {
        viewModelScope.launch {
            repository.saveSettings(settings)
        }
    }

    fun testBackendConnection() {
        viewModelScope.launch {
            _isBackendTesting.value = true
            val currentSettings = appSettings.value
            val result = repository.testBackendConnection(currentSettings.backendUrl)
            _backendTestStatus.value = result
            _isBackendTesting.value = false
        }
    }

    fun resetData(context: Context) {
        viewModelScope.launch {
            repository.resetToSampleData()
            Toast.makeText(context, "Data restored to initial records", Toast.LENGTH_SHORT).show()
        }
    }

    fun clearAuditHistory(context: Context) {
        viewModelScope.launch {
            repository.clearReminderLogs()
            Toast.makeText(context, "Reminder audit logs cleared", Toast.LENGTH_SHORT).show()
        }
    }

    class Factory(private val repository: RenewalRepository) : ViewModelProvider.Factory {
        @Suppress("UNCHECKED_CAST")
        override fun <T : ViewModel> create(modelClass: Class<T>): T {
            return RenewalsViewModel(repository) as T
        }
    }
}
