package com.example.ui.screens.dashboard

import android.content.Context
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.DocumentScanner
import androidx.compose.material.icons.filled.Email
import androidx.compose.material.icons.filled.NotificationsActive
import androidx.compose.material.icons.filled.People
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.Customer
import com.example.data.model.DashboardStats
import com.example.data.model.RenewalStatus
import com.example.ui.components.BrandHeader
import com.example.ui.components.SectionHeader
import com.example.ui.components.StatusBadge
import com.example.ui.components.VehiclePlateBadge
import com.example.ui.screens.customers.AddEditCustomerDialog
import com.example.ui.theme.CharcoalBorder
import com.example.ui.theme.CharcoalCard
import com.example.ui.theme.CharcoalElevated
import com.example.ui.theme.IQYellow
import com.example.ui.theme.StatusBlue
import com.example.ui.theme.StatusGreen
import com.example.ui.theme.StatusOrange
import com.example.ui.theme.StatusRed
import com.example.ui.theme.StatusYellow
import com.example.ui.theme.TextDark
import com.example.ui.theme.TextLightGray
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextWhite
import com.example.ui.viewmodel.RenewalsViewModel
import com.example.ui.viewmodel.ScannedLicenseData

@Composable
fun DashboardScreen(
    viewModel: RenewalsViewModel,
    onNavigateToCustomers: () -> Unit,
    onNavigateToHistory: () -> Unit,
    modifier: Modifier = Modifier
) {
    val stats by viewModel.dashboardStats.collectAsState()
    val needsAttention by viewModel.needsAttentionCustomers.collectAsState()
    val settings by viewModel.appSettings.collectAsState()
    val context = LocalContext.current

    var showScanDialog by remember { mutableStateOf(false) }
    var scannedDataForNewCustomer by remember { mutableStateOf<ScannedLicenseData?>(null) }
    var showAddCustomerDialog by remember { mutableStateOf(false) }
    var customerToEdit by remember { mutableStateOf<Customer?>(null) }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp)
            .testTag("dashboard_screen"),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            BrandHeader(isOnline = settings.backendConnected)
        }

        // Section: Key Expiry Metrics Grid (3 primary cards)
        item {
            Column {
                Text(
                    text = "RENEWAL STATUS OVERVIEW",
                    color = TextMuted,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 0.8.sp,
                    modifier = Modifier.padding(bottom = 8.dp)
                )

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    // Due Today Card
                    MetricCard(
                        count = stats.dueToday,
                        title = "Due Today",
                        subtitle = "Immediate action",
                        accentColor = StatusOrange,
                        modifier = Modifier
                            .weight(1f)
                            .testTag("metric_due_today"),
                        onClick = onNavigateToCustomers
                    )

                    // Due This Week Card
                    MetricCard(
                        count = stats.dueThisWeek,
                        title = "Due This Week",
                        subtitle = "Next 7 days",
                        accentColor = StatusYellow,
                        modifier = Modifier
                            .weight(1f)
                            .testTag("metric_due_week"),
                        onClick = onNavigateToCustomers
                    )

                    // Expired Card
                    MetricCard(
                        count = stats.expired,
                        title = "Expired",
                        subtitle = "Overdue fees",
                        accentColor = StatusRed,
                        modifier = Modifier
                            .weight(1f)
                            .testTag("metric_expired"),
                        onClick = onNavigateToCustomers
                    )
                }
            }
        }

        // Section: Record Counts & Stats Ribbon
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = CharcoalCard),
                border = BorderStroke(1.dp, CharcoalBorder)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 12.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    StatSummaryItem(
                        icon = Icons.Default.People,
                        count = stats.totalCustomers,
                        label = "Customers",
                        tint = IQYellow
                    )
                    Box(
                        modifier = Modifier
                            .height(28.dp)
                            .width(1.dp)
                            .background(CharcoalBorder)
                    )
                    StatSummaryItem(
                        icon = Icons.Default.CheckCircle,
                        count = stats.activeCount,
                        label = "Active & Safe",
                        tint = StatusGreen
                    )
                    Box(
                        modifier = Modifier
                            .height(28.dp)
                            .width(1.dp)
                            .background(CharcoalBorder)
                    )
                    StatSummaryItem(
                        icon = Icons.Default.NotificationsActive,
                        count = stats.totalReminders,
                        label = "Reminders Sent",
                        tint = StatusBlue,
                        onClick = onNavigateToHistory
                    )
                }
            }
        }

        // Section: Quick Actions
        item {
            Column {
                Text(
                    text = "QUICK ACTIONS",
                    color = TextMuted,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 0.8.sp,
                    modifier = Modifier.padding(bottom = 8.dp)
                )

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    // Quick Action: Scan License
                    QuickActionButton(
                        title = "Scan License",
                        subtitle = "Auto-fill disc",
                        icon = Icons.Default.DocumentScanner,
                        buttonColor = IQYellow,
                        iconTint = TextDark,
                        textColor = TextDark,
                        modifier = Modifier
                            .weight(1.1f)
                            .testTag("action_scan_license"),
                        onClick = { showScanDialog = true }
                    )

                    // Quick Action: WhatsApp Action
                    QuickActionButton(
                        title = "WhatsApp",
                        subtitle = "Send reminders",
                        icon = Icons.Default.NotificationsActive,
                        buttonColor = CharcoalElevated,
                        iconTint = StatusGreen,
                        textColor = TextWhite,
                        modifier = Modifier
                            .weight(1f)
                            .testTag("action_whatsapp_reminder"),
                        onClick = {
                            val target = needsAttention.firstOrNull()
                            if (target != null) {
                                viewModel.sendDirectWhatsApp(context, target)
                            } else {
                                onNavigateToCustomers()
                            }
                        }
                    )

                    // Quick Action: Email Action
                    QuickActionButton(
                        title = "Email Notice",
                        subtitle = "Direct dispatch",
                        icon = Icons.Default.Email,
                        buttonColor = CharcoalElevated,
                        iconTint = StatusBlue,
                        textColor = TextWhite,
                        modifier = Modifier
                            .weight(1f)
                            .testTag("action_email_notice"),
                        onClick = {
                            val target = needsAttention.firstOrNull()
                            if (target != null) {
                                viewModel.sendDirectEmail(context, target)
                            } else {
                                onNavigateToCustomers()
                            }
                        }
                    )
                }
            }
        }

        // Section: Needs Attention
        item {
            SectionHeader(
                title = "Needs Attention",
                badgeCount = needsAttention.size,
                actionText = "View All",
                onActionClick = onNavigateToCustomers
            )
        }

        if (needsAttention.isEmpty()) {
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = CharcoalCard),
                    border = BorderStroke(1.dp, CharcoalBorder)
                ) {
                    Row(
                        modifier = Modifier.padding(20.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Default.CheckCircle,
                            contentDescription = null,
                            tint = StatusGreen,
                            modifier = Modifier.size(28.dp)
                        )
                        Spacer(modifier = Modifier.width(12.dp))
                        Column {
                            Text(
                                text = "All Vehicle Renewals Up to Date",
                                color = TextWhite,
                                fontWeight = FontWeight.Bold,
                                fontSize = 14.sp
                            )
                            Text(
                                text = "No expired or urgent upcoming discs today.",
                                color = TextMuted,
                                fontSize = 12.sp
                            )
                        }
                    }
                }
            }
        } else {
            items(needsAttention) { customer ->
                NeedsAttentionCard(
                    customer = customer,
                    onWhatsAppClick = { viewModel.sendDirectWhatsApp(context, customer) },
                    onEmailClick = { viewModel.sendDirectEmail(context, customer) },
                    onEditClick = {
                        customerToEdit = customer
                        showAddCustomerDialog = true
                    }
                )
            }
        }

        item {
            Spacer(modifier = Modifier.height(24.dp))
        }
    }

    // Scan License Dialog
    if (showScanDialog) {
        ScanLicenseDialog(
            onDismiss = { showScanDialog = false },
            onScanSuccess = { scanned ->
                showScanDialog = false
                scannedDataForNewCustomer = scanned
                showAddCustomerDialog = true
            }
        )
    }

    // Add or Edit Customer Dialog
    if (showAddCustomerDialog) {
        AddEditCustomerDialog(
            initialCustomer = customerToEdit,
            prefillRegistration = scannedDataForNewCustomer?.vehiclePlate,
            prefillMakeModel = scannedDataForNewCustomer?.vehicleMakeModel,
            prefillType = scannedDataForNewCustomer?.vehicleType,
            prefillDiscNumber = scannedDataForNewCustomer?.licenseDiscNumber,
            prefillExpiryDate = scannedDataForNewCustomer?.expiryDate,
            prefillName = scannedDataForNewCustomer?.customerName,
            prefillPhone = scannedDataForNewCustomer?.phone,
            prefillFee = scannedDataForNewCustomer?.renewalFee,
            onDismiss = {
                showAddCustomerDialog = false
                scannedDataForNewCustomer = null
                customerToEdit = null
            },
            onSaveCustomer = { customer ->
                if (customer.id == 0L) {
                    viewModel.addCustomer(customer)
                } else {
                    viewModel.updateCustomer(customer)
                }
                showAddCustomerDialog = false
                scannedDataForNewCustomer = null
                customerToEdit = null
            }
        )
    }
}

@Composable
private fun MetricCard(
    count: Int,
    title: String,
    subtitle: String,
    accentColor: Color,
    modifier: Modifier = Modifier,
    onClick: () -> Unit
) {
    Card(
        modifier = modifier.clickable { onClick() },
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = CharcoalCard),
        border = BorderStroke(1.dp, CharcoalBorder)
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    modifier = Modifier
                        .size(10.dp)
                        .clip(CircleShape)
                        .background(accentColor)
                )
                Text(
                    text = title,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    color = TextLightGray
                )
            }

            Spacer(modifier = Modifier.height(10.dp))

            Text(
                text = count.toString(),
                fontSize = 28.sp,
                fontWeight = FontWeight.Black,
                color = accentColor
            )

            Text(
                text = subtitle,
                fontSize = 10.sp,
                color = TextMuted
            )
        }
    }
}

@Composable
private fun StatSummaryItem(
    icon: ImageVector,
    count: Int,
    label: String,
    tint: Color,
    onClick: (() -> Unit)? = null
) {
    Row(
        verticalAlignment = Alignment.CenterVertically,
        modifier = Modifier
            .then(if (onClick != null) Modifier.clickable { onClick() } else Modifier)
            .padding(vertical = 4.dp)
    ) {
        Box(
            modifier = Modifier
                .size(32.dp)
                .clip(RoundedCornerShape(8.dp))
                .background(tint.copy(alpha = 0.15f)),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = icon,
                contentDescription = null,
                tint = tint,
                modifier = Modifier.size(18.dp)
            )
        }
        Spacer(modifier = Modifier.width(8.dp))
        Column {
            Text(
                text = count.toString(),
                color = TextWhite,
                fontWeight = FontWeight.Bold,
                fontSize = 15.sp
            )
            Text(
                text = label,
                color = TextMuted,
                fontSize = 10.sp
            )
        }
    }
}

@Composable
private fun QuickActionButton(
    title: String,
    subtitle: String,
    icon: ImageVector,
    buttonColor: Color,
    iconTint: Color,
    textColor: Color,
    modifier: Modifier = Modifier,
    onClick: () -> Unit
) {
    Surface(
        modifier = modifier.clickable { onClick() },
        shape = RoundedCornerShape(12.dp),
        color = buttonColor,
        border = BorderStroke(1.dp, if (buttonColor == IQYellow) IQYellow else CharcoalBorder)
    ) {
        Column(
            modifier = Modifier.padding(12.dp),
            horizontalAlignment = Alignment.Start
        ) {
            Icon(
                imageVector = icon,
                contentDescription = title,
                tint = iconTint,
                modifier = Modifier.size(22.dp)
            )
            Spacer(modifier = Modifier.height(8.dp))
            Text(
                text = title,
                fontWeight = FontWeight.Bold,
                fontSize = 12.sp,
                color = textColor
            )
            Text(
                text = subtitle,
                fontSize = 10.sp,
                color = if (buttonColor == IQYellow) TextDark.copy(alpha = 0.8f) else TextMuted
            )
        }
    }
}

@Composable
private fun NeedsAttentionCard(
    customer: Customer,
    onWhatsAppClick: () -> Unit,
    onEmailClick: () -> Unit,
    onEditClick: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onEditClick() },
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = CharcoalCard),
        border = BorderStroke(1.dp, CharcoalBorder)
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                VehiclePlateBadge(plate = customer.vehicleRegistration)
                StatusBadge(
                    status = customer.status,
                    daysLeft = customer.daysUntilExpiry
                )
            }

            Spacer(modifier = Modifier.height(10.dp))

            Text(
                text = customer.name,
                fontWeight = FontWeight.Bold,
                fontSize = 15.sp,
                color = TextWhite
            )

            Text(
                text = "${customer.vehicleMakeModel} • ${customer.vehicleType}",
                fontSize = 12.sp,
                color = TextLightGray
            )

            Spacer(modifier = Modifier.height(6.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Expiry: ${customer.expiryDate}",
                    fontSize = 11.sp,
                    color = TextMuted
                )

                if (customer.renewalFee > 0) {
                    Text(
                        text = "R${"%.2f".format(customer.renewalFee)}",
                        fontWeight = FontWeight.SemiBold,
                        fontSize = 12.sp,
                        color = IQYellow
                    )
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Action Row
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                // WhatsApp Button
                Button(
                    onClick = onWhatsAppClick,
                    modifier = Modifier.weight(1f),
                    shape = RoundedCornerShape(8.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = StatusGreen.copy(alpha = 0.2f))
                ) {
                    Icon(
                        imageVector = Icons.Default.NotificationsActive,
                        contentDescription = "WhatsApp",
                        tint = StatusGreen,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "WhatsApp",
                        color = StatusGreen,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold
                    )
                }

                // Email Button
                Button(
                    onClick = onEmailClick,
                    modifier = Modifier.weight(1f),
                    shape = RoundedCornerShape(8.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = CharcoalElevated),
                    border = BorderStroke(1.dp, CharcoalBorder)
                ) {
                    Icon(
                        imageVector = Icons.Default.Email,
                        contentDescription = "Email",
                        tint = TextWhite,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "Email",
                        color = TextWhite,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.SemiBold
                    )
                }
            }
        }
    }
}
