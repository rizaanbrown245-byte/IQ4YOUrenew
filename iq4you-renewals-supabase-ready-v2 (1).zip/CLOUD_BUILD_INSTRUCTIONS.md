# IQ4YOU Renewals — cloud APK build

This project has been prepared for a GitHub Actions cloud build.

## What was prepared

- The Android project's custom debug signing configuration was removed so Gradle can use the standard Android debug signing configuration in the cloud.
- A GitHub Actions workflow was added at `.github/workflows/build-apk.yml`.
- The workflow installs Java 17 and Gradle 9.3.1, builds `:app:assembleDebug`, and uploads the APK as a downloadable workflow artifact.
- The workflow does not require the Gradle Wrapper, because it explicitly installs Gradle in the GitHub Actions runner.

## Build output

After the workflow succeeds, the APK is available as the artifact named:

`IQ4YOU-Renewals-debug-APK`

This is a debug-signed APK intended for installation/testing on Android devices. A separate release signing key should be used before public Play Store distribution.
