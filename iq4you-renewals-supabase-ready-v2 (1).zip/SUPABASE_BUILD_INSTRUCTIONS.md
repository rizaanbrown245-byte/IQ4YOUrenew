# IQ4YOU Renewals + Supabase

1. In Supabase, enable **Authentication -> Sign-In / Providers -> Anonymous Sign-Ins**.
2. Open SQL Editor and run every statement in `SUPABASE_SETUP.sql`.
3. In GitHub repository Settings -> Secrets and variables -> Actions, create:
   - `SUPABASE_URL` = your Supabase project URL
   - `SUPABASE_PUBLISHABLE_KEY` = the `sb_publishable_...` key you copied
4. Replace the repository workflow `.github/workflows/build-apk.yml` with the contents of `SUPABASE_GITHUB_WORKFLOW.yml`.
5. Run the GitHub Action and download the `IQ4YOU-Renewals-Supabase-APK` artifact.

The Android app keeps Room as its offline/local database. When Supabase is reachable it authenticates with an anonymous Supabase user and synchronizes customers, reminder logs and settings. RLS policies isolate each anonymous user.

Never put a Supabase `sb_secret_...` or legacy `service_role` key in the APK.
