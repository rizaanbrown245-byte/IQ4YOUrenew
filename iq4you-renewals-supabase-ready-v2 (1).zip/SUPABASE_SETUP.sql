-- IQ4YOU Renewals - Supabase database setup
-- Run this in Supabase SQL Editor AFTER enabling Anonymous Sign-Ins.
-- The app uses an authenticated anonymous Supabase user, so customer data is
-- isolated per app installation with Row Level Security.

create table if not exists public.customers (
  user_id uuid not null default auth.uid(),
  id bigint not null,
  name text not null,
  phone text not null default '',
  email text not null default '',
  vehicle_registration text not null default '',
  vehicle_type text not null default '',
  vehicle_make_model text not null default '',
  license_disc_number text not null default '',
  expiry_date date not null,
  renewal_fee double precision not null default 0,
  notes text not null default '',
  last_reminder_sent text,
  primary key (user_id, id)
);

create table if not exists public.reminder_logs (
  user_id uuid not null default auth.uid(),
  id bigint not null,
  customer_id bigint not null,
  customer_name text not null,
  vehicle_plate text not null,
  channel text not null,
  status text not null,
  message_text text not null,
  timestamp bigint not null,
  primary key (user_id, id)
);

create table if not exists public.app_settings (
  user_id uuid not null default auth.uid(),
  id integer not null default 1,
  automatic_reminders boolean not null default true,
  remind_30_days_before boolean not null default true,
  remind_7_days_before boolean not null default true,
  consolidate_per_contact boolean not null default true,
  reminder_time text not null default '09:00 AM',
  primary key (user_id, id)
);

alter table public.customers enable row level security;
alter table public.reminder_logs enable row level security;
alter table public.app_settings enable row level security;

grant select, insert, update, delete on public.customers to authenticated;
grant select, insert, update, delete on public.reminder_logs to authenticated;
grant select, insert, update, delete on public.app_settings to authenticated;

drop policy if exists "IQ4YOU customers select own" on public.customers;
drop policy if exists "IQ4YOU customers insert own" on public.customers;
drop policy if exists "IQ4YOU customers update own" on public.customers;
drop policy if exists "IQ4YOU customers delete own" on public.customers;

create policy "IQ4YOU customers select own"
on public.customers for select to authenticated
using (user_id = (select auth.uid()));

create policy "IQ4YOU customers insert own"
on public.customers for insert to authenticated
with check (user_id = (select auth.uid()));

create policy "IQ4YOU customers update own"
on public.customers for update to authenticated
using (user_id = (select auth.uid()))
with check (user_id = (select auth.uid()));

create policy "IQ4YOU customers delete own"
on public.customers for delete to authenticated
using (user_id = (select auth.uid()));

drop policy if exists "IQ4YOU logs select own" on public.reminder_logs;
drop policy if exists "IQ4YOU logs insert own" on public.reminder_logs;
drop policy if exists "IQ4YOU logs update own" on public.reminder_logs;
drop policy if exists "IQ4YOU logs delete own" on public.reminder_logs;

create policy "IQ4YOU logs select own"
on public.reminder_logs for select to authenticated
using (user_id = (select auth.uid()));

create policy "IQ4YOU logs insert own"
on public.reminder_logs for insert to authenticated
with check (user_id = (select auth.uid()));

create policy "IQ4YOU logs update own"
on public.reminder_logs for update to authenticated
using (user_id = (select auth.uid()))
with check (user_id = (select auth.uid()));

create policy "IQ4YOU logs delete own"
on public.reminder_logs for delete to authenticated
using (user_id = (select auth.uid()));

drop policy if exists "IQ4YOU settings select own" on public.app_settings;
drop policy if exists "IQ4YOU settings insert own" on public.app_settings;
drop policy if exists "IQ4YOU settings update own" on public.app_settings;
drop policy if exists "IQ4YOU settings delete own" on public.app_settings;

create policy "IQ4YOU settings select own"
on public.app_settings for select to authenticated
using (user_id = (select auth.uid()));

create policy "IQ4YOU settings insert own"
on public.app_settings for insert to authenticated
with check (user_id = (select auth.uid()));

create policy "IQ4YOU settings update own"
on public.app_settings for update to authenticated
using (user_id = (select auth.uid()))
with check (user_id = (select auth.uid()));

create policy "IQ4YOU settings delete own"
on public.app_settings for delete to authenticated
using (user_id = (select auth.uid()));
