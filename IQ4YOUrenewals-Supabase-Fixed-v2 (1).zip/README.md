# IQ4YOU Renewals

Vehicle license and renewal tracker with Gemini AI document extraction, customer records, expiry calendar, reminder logs, and automation settings.

## Supabase connection fix

The app now performs a real HTTP reachability test against the Supabase REST endpoint instead of reporting a simulated/assumed success. It also:

- Uses the build-time `SUPABASE_URL` value, with the IQ4YOU Supabase project URL as the safe public URL fallback.
- Uses `SUPABASE_PUBLISHABLE_KEY` (or the legacy `SUPABASE_ANON_KEY`) when supplied.
- Normalizes the URL and probes `/rest/v1/`.
- Distinguishes DNS/host-resolution failures, timeouts, HTTP responses, and other connection failures.
- Persists the successful backend connection state after the test.
- Keeps Supabase secrets out of source control.

### GitHub Actions secrets

Create these repository secrets:

- `SUPABASE_URL`
- `SUPABASE_PUBLISHABLE_KEY`
- `GEMINI_API_KEY` (if Gemini document analysis is used)

The included workflow passes the Supabase values into Gradle at build time and uploads the debug APK as an Actions artifact.

### Local build

Create a `.env` or provide matching Gradle/environment properties for the keys in `.env.example`. The Android project can be opened in Android Studio and built normally.
