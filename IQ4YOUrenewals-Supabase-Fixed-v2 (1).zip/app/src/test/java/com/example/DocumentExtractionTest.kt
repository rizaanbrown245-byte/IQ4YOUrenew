package com.example

import com.example.data.service.GeminiDocumentAnalyzer
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test

class DocumentExtractionTest {

    @Test
    fun testPdfDocumentPresetExtraction() {
        val pdfPreset = GeminiDocumentAnalyzer.generateFallbackExtraction(
            fileName = "Gauteng_MVLX_Renewal_Notice.pdf",
            isPdf = true
        )

        assertNotNull(pdfPreset)
        assertEquals("Sipho Dlamini", pdfPreset.customerName)
        assertEquals("JH 84 BK GP", pdfPreset.vehicleRegistration)
        assertEquals("Toyota Hilux 2.8 GD-6 Raider", pdfPreset.vehicleMakeModel)
        assertEquals("Bakkie / Pickup", pdfPreset.vehicleType)
        assertEquals("B9821445", pdfPreset.licenseDiscNumber)
        assertTrue(pdfPreset.renewalFee > 0)
        assertTrue(pdfPreset.expiryDate.isNotBlank())
        assertEquals("application/pdf", pdfPreset.sourceMimeType)
    }

    @Test
    fun testImageDocumentPresetExtraction() {
        val imagePreset = GeminiDocumentAnalyzer.generateFallbackExtraction(
            fileName = "Western_Cape_Disc_Capture.jpg",
            isPdf = false
        )

        assertNotNull(imagePreset)
        assertEquals("Cheryl Hendricks", imagePreset.customerName)
        assertEquals("CA 482-910", imagePreset.vehicleRegistration)
        assertEquals("Volkswagen Polo 1.0 TSI Life", imagePreset.vehicleMakeModel)
        assertEquals("Sedan", imagePreset.vehicleType)
        assertEquals("D4782910", imagePreset.licenseDiscNumber)
        assertEquals("image/jpeg", imagePreset.sourceMimeType)
    }

    @Test
    fun testSamplePresetsAvailable() {
        val presets = GeminiDocumentAnalyzer.getSamplePresets()
        assertTrue(presets.isNotEmpty())
        assertTrue(presets.any { it.isPdf })
        assertTrue(presets.any { !it.isPdf })
    }
}
