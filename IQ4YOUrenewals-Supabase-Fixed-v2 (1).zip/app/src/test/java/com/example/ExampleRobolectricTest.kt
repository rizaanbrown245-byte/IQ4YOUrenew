package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.data.model.Customer
import com.example.data.model.RenewalStatus
import org.junit.Assert.assertEquals
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config
import java.time.LocalDate

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

  @Test
  fun `read string from context`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val appName = context.getString(R.string.app_name)
    assertEquals("IQ4YOU Renewals", appName)
  }

  @Test
  fun `verify renewal status calculations`() {
    val todayStr = LocalDate.now().toString()
    val customerToday = Customer(
      id = 1,
      name = "Test Client",
      phone = "+27 82 111 2222",
      email = "test@iq4you.co.za",
      vehicleRegistration = "CA 123-456",
      vehicleType = "Sedan",
      vehicleMakeModel = "VW Polo",
      licenseDiscNumber = "SA-123456",
      expiryDate = todayStr,
      renewalFee = 450.0
    )
    assertEquals(RenewalStatus.DUE_TODAY, customerToday.status)
    assertEquals(0L, customerToday.daysUntilExpiry)

    val expiredCustomer = customerToday.copy(expiryDate = LocalDate.now().minusDays(5).toString())
    assertEquals(RenewalStatus.EXPIRED, expiredCustomer.status)

    val upcomingCustomer = customerToday.copy(expiryDate = LocalDate.now().plusDays(14).toString())
    assertEquals(RenewalStatus.EXPIRING_SOON, upcomingCustomer.status)
  }

  @Test
  fun `verify license disc barcode parser auto-fills fields`() {
    val rawBarcode = "%SA-MV-928142-W%CA 928-142%NATIS88219%Bakkie%TOYOTA%HILUX 2.8 GD-6%WHITE%2026-10-31%540.00%Johan Van Der Merwe%+27 82 911 3842%"
    val parsed = com.example.data.util.LicenseDiscParser.parseBarcode(rawBarcode)

    assertEquals("CA 928-142", parsed.vehiclePlate)
    assertEquals("Bakkie / Pickup", parsed.vehicleType)
    assertEquals("2026-10-31", parsed.expiryDate)
    assertEquals("SA-MV-928142-W", parsed.licenseDiscNumber)
    assertEquals(540.0, parsed.renewalFee, 0.01)
  }
}
