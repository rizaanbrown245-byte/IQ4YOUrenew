package com.example.data.service

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.util.Log
import com.example.data.local.IQDatabase
import com.example.data.local.ReminderLogEntity
import com.example.data.model.AppSettings
import com.example.data.model.Customer
import com.example.data.model.ReminderChannel
import com.example.data.model.ReminderStatus
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.firstOrNull
import kotlinx.coroutines.launch
import java.time.LocalDate
import java.time.temporal.ChronoUnit
import java.util.Calendar

data class ReminderRunResult(
    val totalChecked: Int,
    val sentCount: Int,
    val duplicatesSkipped: Int,
    val failedCount: Int,
    val details: List<String>
)

object RenewalReminderScheduler {
    private const val TAG = "ReminderScheduler"
    private const val ALARM_REQUEST_CODE = 4040

    fun scheduleDailyCheck(context: Context) {
        try {
            val alarmManager = context.getSystemService(Context.ALARM_SERVICE) as? AlarmManager ?: return
            val intent = Intent(context, RenewalAlarmReceiver::class.java)
            val pendingIntent = PendingIntent.getBroadcast(
                context,
                ALARM_REQUEST_CODE,
                intent,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )

            val calendar = Calendar.getInstance().apply {
                timeInMillis = System.currentTimeMillis()
                set(Calendar.HOUR_OF_DAY, 9)
                set(Calendar.MINUTE, 0)
                set(Calendar.SECOND, 0)
                if (before(Calendar.getInstance())) {
                    add(Calendar.DAY_OF_YEAR, 1)
                }
            }

            alarmManager.setInexactRepeating(
                AlarmManager.RTC_WAKEUP,
                calendar.timeInMillis,
                AlarmManager.INTERVAL_DAY,
                pendingIntent
            )
            Log.i(TAG, "Daily renewal reminder check scheduled for 09:00 AM")
        } catch (e: Exception) {
            Log.e(TAG, "Failed to schedule daily alarm: ${e.message}", e)
        }
    }

    suspend fun runScheduledRemindersCheck(context: Context): ReminderRunResult {
        val db = IQDatabase.getDatabase(context)
        val dao = db.iqDao()
        val settings = dao.getSettings().firstOrNull()?.toDomain() ?: AppSettings()

        val activeCustomers = dao.getActiveCustomersList().map { it.toDomain() }
        var sentCount = 0
        var skippedDuplicates = 0
        var failedCount = 0
        val details = mutableListOf<String>()

        val today = LocalDate.now()

        for (customer in activeCustomers) {
            if (!customer.reminderEnabled) {
                continue
            }

            val expiry = try {
                LocalDate.parse(customer.expiryDate)
            } catch (e: Exception) {
                continue
            }

            val daysUntilExpiry = ChronoUnit.DAYS.between(today, expiry)

            // Determine matching intervals based on customer preferences
            val dueIntervals = mutableListOf<Pair<String, String>>() // Key to Display name

            if (customer.remind90Days && daysUntilExpiry in 89..91) {
                dueIntervals.add("90_DAYS" to "90 Days Before Expiry")
            }
            if (customer.remind60Days && daysUntilExpiry in 59..61) {
                dueIntervals.add("60_DAYS" to "60 Days Before Expiry")
            }
            if (customer.remind30Days && daysUntilExpiry in 29..31) {
                dueIntervals.add("30_DAYS" to "30 Days Before Expiry")
            }
            if (customer.remind14Days && daysUntilExpiry in 13..15) {
                dueIntervals.add("14_DAYS" to "14 Days Before Expiry")
            }
            if (customer.remind7Days && daysUntilExpiry in 6..8) {
                dueIntervals.add("7_DAYS" to "7 Days Before Expiry")
            }
            if (customer.remind1Day && daysUntilExpiry in 0..1) {
                dueIntervals.add("1_DAY" to "1 Day Before Expiry")
            }

            for ((intervalKey, intervalLabel) in dueIntervals) {
                // Check duplicate prevention:
                // Has a successful reminder already been sent for this customer, interval, and renewal date?
                val alreadySent = dao.countSuccessfulReminders(
                    customerId = customer.id,
                    interval = intervalKey,
                    renewalDate = customer.expiryDate
                ) > 0

                if (alreadySent) {
                    skippedDuplicates++
                    details.add("Skipped duplicate for ${customer.name} ($intervalLabel)")
                    continue
                }

                // Check email address validity
                val email = customer.email.trim()
                val isValidEmail = email.isNotEmpty() && android.util.Patterns.EMAIL_ADDRESS.matcher(email).matches()

                val subject = formatTemplate(settings.emailSubjectTemplate, customer)
                val body = formatTemplate(settings.emailBodyTemplate, customer)

                val logEntity = if (isValidEmail) {
                    sentCount++
                    details.add("Sent $intervalLabel reminder to ${customer.name} ($email)")
                    ReminderLogEntity(
                        customerId = customer.id,
                        customerName = customer.name,
                        vehiclePlate = customer.vehicleRegistration,
                        channel = ReminderChannel.EMAIL.name,
                        status = ReminderStatus.SENT.name,
                        messageText = "Subject: $subject\n\n$body",
                        timestamp = System.currentTimeMillis(),
                        recipientEmail = email,
                        renewalDate = customer.expiryDate,
                        reminderInterval = intervalKey,
                        errorMessage = null
                    )
                } else {
                    failedCount++
                    details.add("Failed for ${customer.name}: Invalid email address '$email'")
                    ReminderLogEntity(
                        customerId = customer.id,
                        customerName = customer.name,
                        vehiclePlate = customer.vehicleRegistration,
                        channel = ReminderChannel.EMAIL.name,
                        status = ReminderStatus.FAILED.name,
                        messageText = "Subject: $subject\n\n$body",
                        timestamp = System.currentTimeMillis(),
                        recipientEmail = email,
                        renewalDate = customer.expiryDate,
                        reminderInterval = intervalKey,
                        errorMessage = "Invalid email address: '$email'"
                    )
                }

                dao.insertReminderLog(logEntity)

                // Update last reminder sent timestamp on customer
                val updatedCustomer = customer.copy(
                    lastReminderSent = "Email ($intervalLabel) sent on $today"
                )
                dao.updateCustomer(com.example.data.local.CustomerEntity.fromDomain(updatedCustomer))
            }
        }

        return ReminderRunResult(
            totalChecked = activeCustomers.size,
            sentCount = sentCount,
            duplicatesSkipped = skippedDuplicates,
            failedCount = failedCount,
            details = details
        )
    }

    fun formatTemplate(template: String, customer: Customer): String {
        val licenseNumber = customer.licenseDiscNumber.ifBlank { customer.vehicleRegistration }
        val licenseType = customer.vehicleType.ifBlank { "Vehicle License" }
        return template
            .replace("{CustomerName}", customer.name)
            .replace("[Customer Name]", customer.name)
            .replace("{LicenseType}", licenseType)
            .replace("[License Type]", licenseType)
            .replace("{RenewalDate}", customer.expiryDate)
            .replace("[Renewal Date]", customer.expiryDate)
            .replace("{LicenseNumber}", licenseNumber)
            .replace("[License Number]", licenseNumber)
            .replace("{Registration}", customer.vehicleRegistration)
            .replace("{Vehicle}", "${customer.vehicleMakeModel} (${customer.vehicleRegistration})")
    }
}

class RenewalAlarmReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val pendingResult = goAsync()
        CoroutineScope(Dispatchers.IO).launch {
            try {
                RenewalReminderScheduler.runScheduledRemindersCheck(context)
            } catch (e: Exception) {
                Log.e("RenewalAlarmReceiver", "Error running scheduled check: ${e.message}", e)
            } finally {
                pendingResult.finish()
            }
        }
    }
}
