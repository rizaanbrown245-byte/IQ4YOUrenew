package com.example.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey
import com.example.data.model.AppSettings
import com.example.data.model.Customer
import com.example.data.model.ReminderChannel
import com.example.data.model.ReminderLog
import com.example.data.model.ReminderStatus

@Entity(tableName = "customers")
data class CustomerEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val phone: String,
    val email: String,
    val vehicleRegistration: String,
    val vehicleType: String,
    val vehicleMakeModel: String,
    val licenseDiscNumber: String,
    val expiryDate: String,
    val renewalFee: Double,
    val notes: String,
    val lastReminderSent: String?,
    val idNumber: String = "",
    val companyName: String = "",
    val address: String = "",
    val issueDate: String = "",
    val isDeleted: Boolean = false,
    val deletedAt: Long? = null,
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis(),
    val reminderEnabled: Boolean = true,
    val remind90Days: Boolean = true,
    val remind60Days: Boolean = true,
    val remind30Days: Boolean = true,
    val remind14Days: Boolean = true,
    val remind7Days: Boolean = true,
    val remind1Day: Boolean = true
) {
    fun toDomain(): Customer = Customer(
        id = id,
        name = name,
        phone = phone,
        email = email,
        vehicleRegistration = vehicleRegistration,
        vehicleType = vehicleType,
        vehicleMakeModel = vehicleMakeModel,
        licenseDiscNumber = licenseDiscNumber,
        expiryDate = expiryDate,
        renewalFee = renewalFee,
        notes = notes,
        lastReminderSent = lastReminderSent,
        idNumber = idNumber,
        companyName = companyName,
        address = address,
        issueDate = issueDate,
        isDeleted = isDeleted,
        deletedAt = deletedAt,
        createdAt = createdAt,
        updatedAt = updatedAt,
        reminderEnabled = reminderEnabled,
        remind90Days = remind90Days,
        remind60Days = remind60Days,
        remind30Days = remind30Days,
        remind14Days = remind14Days,
        remind7Days = remind7Days,
        remind1Day = remind1Day
    )

    companion object {
        fun fromDomain(c: Customer): CustomerEntity = CustomerEntity(
            id = c.id,
            name = c.name,
            phone = c.phone,
            email = c.email,
            vehicleRegistration = c.vehicleRegistration,
            vehicleType = c.vehicleType,
            vehicleMakeModel = c.vehicleMakeModel,
            licenseDiscNumber = c.licenseDiscNumber,
            expiryDate = c.expiryDate,
            renewalFee = c.renewalFee,
            notes = c.notes,
            lastReminderSent = c.lastReminderSent,
            idNumber = c.idNumber,
            companyName = c.companyName,
            address = c.address,
            issueDate = c.issueDate,
            isDeleted = c.isDeleted,
            deletedAt = c.deletedAt,
            createdAt = c.createdAt,
            updatedAt = c.updatedAt,
            reminderEnabled = c.reminderEnabled,
            remind90Days = c.remind90Days,
            remind60Days = c.remind60Days,
            remind30Days = c.remind30Days,
            remind14Days = c.remind14Days,
            remind7Days = c.remind7Days,
            remind1Day = c.remind1Day
        )
    }
}

@Entity(tableName = "reminder_logs")
data class ReminderLogEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val customerId: Long,
    val customerName: String,
    val vehiclePlate: String,
    val channel: String,
    val status: String,
    val messageText: String,
    val timestamp: Long,
    val recipientEmail: String = "",
    val renewalDate: String = "",
    val reminderInterval: String = "",
    val errorMessage: String? = null
) {
    fun toDomain(): ReminderLog = ReminderLog(
        id = id,
        customerId = customerId,
        customerName = customerName,
        vehiclePlate = vehiclePlate,
        channel = try { ReminderChannel.valueOf(channel) } catch (_: Exception) { ReminderChannel.WHATSAPP },
        status = try { ReminderStatus.valueOf(status) } catch (_: Exception) { ReminderStatus.DELIVERED },
        messageText = messageText,
        timestamp = timestamp,
        recipientEmail = recipientEmail,
        renewalDate = renewalDate,
        reminderInterval = reminderInterval,
        errorMessage = errorMessage
    )

    companion object {
        fun fromDomain(l: ReminderLog): ReminderLogEntity = ReminderLogEntity(
            id = l.id,
            customerId = l.customerId,
            customerName = l.customerName,
            vehiclePlate = l.vehiclePlate,
            channel = l.channel.name,
            status = l.status.name,
            messageText = l.messageText,
            timestamp = l.timestamp,
            recipientEmail = l.recipientEmail,
            renewalDate = l.renewalDate,
            reminderInterval = l.reminderInterval,
            errorMessage = l.errorMessage
        )
    }
}

@Entity(tableName = "app_settings")
data class AppSettingsEntity(
    @PrimaryKey val id: Int = 1,
    val automaticReminders: Boolean = true,
    val remind90DaysDefault: Boolean = true,
    val remind60DaysDefault: Boolean = true,
    val remind30DaysBefore: Boolean = true,
    val remind14DaysBefore: Boolean = true,
    val remind7DaysBefore: Boolean = true,
    val remind1DayBefore: Boolean = true,
    val consolidatePerContact: Boolean = true,
    val reminderTime: String = "09:00 AM",
    val emailSubjectTemplate: String = "License Renewal Reminder – {CustomerName}",
    val emailBodyTemplate: String = "Hello {CustomerName},\n\nThis is a reminder that your {LicenseType} is due for renewal on {RenewalDate}.\n\nLicense Number: {LicenseNumber}\n\nPlease contact us if you require assistance with your renewal.\n\nKind regards,\nIQ4U Renewals",
    val backendUrl: String = "",
    val backendConnected: Boolean = true,
    val lastSyncTime: String = "Just now",
    val cloudSyncEnabled: Boolean = true
) {
    fun toDomain(): AppSettings = AppSettings(
        automaticReminders = automaticReminders,
        remind90DaysDefault = remind90DaysDefault,
        remind60DaysDefault = remind60DaysDefault,
        remind30DaysBefore = remind30DaysBefore,
        remind14DaysBefore = remind14DaysBefore,
        remind7DaysBefore = remind7DaysBefore,
        remind1DayBefore = remind1DayBefore,
        consolidatePerContact = consolidatePerContact,
        reminderTime = reminderTime,
        emailSubjectTemplate = emailSubjectTemplate,
        emailBodyTemplate = emailBodyTemplate,
        backendUrl = backendUrl,
        backendConnected = backendConnected,
        lastSyncTime = lastSyncTime,
        cloudSyncEnabled = cloudSyncEnabled
    )

    companion object {
        fun fromDomain(s: AppSettings): AppSettingsEntity = AppSettingsEntity(
            id = 1,
            automaticReminders = s.automaticReminders,
            remind90DaysDefault = s.remind90DaysDefault,
            remind60DaysDefault = s.remind60DaysDefault,
            remind30DaysBefore = s.remind30DaysBefore,
            remind14DaysBefore = s.remind14DaysBefore,
            remind7DaysBefore = s.remind7DaysBefore,
            remind1DayBefore = s.remind1DayBefore,
            consolidatePerContact = s.consolidatePerContact,
            reminderTime = s.reminderTime,
            emailSubjectTemplate = s.emailSubjectTemplate,
            emailBodyTemplate = s.emailBodyTemplate,
            backendUrl = s.backendUrl,
            backendConnected = s.backendConnected,
            lastSyncTime = s.lastSyncTime,
            cloudSyncEnabled = s.cloudSyncEnabled
        )
    }
}

