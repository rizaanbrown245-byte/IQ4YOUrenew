package com.example.data.local

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Dao
interface IQDao {
    @Query("SELECT * FROM customers WHERE isDeleted = 0 ORDER BY expiryDate ASC")
    fun getAllActiveCustomers(): Flow<List<CustomerEntity>>

    @Query("SELECT * FROM customers WHERE isDeleted = 1 ORDER BY deletedAt DESC")
    fun getRecycleBinCustomers(): Flow<List<CustomerEntity>>

    @Query("SELECT * FROM customers ORDER BY expiryDate ASC")
    fun getAllCustomers(): Flow<List<CustomerEntity>>

    @Query("SELECT * FROM customers WHERE isDeleted = 0")
    suspend fun getActiveCustomersList(): List<CustomerEntity>

    @Query("SELECT * FROM customers WHERE id = :id")
    fun getCustomerById(id: Long): Flow<CustomerEntity?>

    @Query("SELECT * FROM customers WHERE id = :id")
    suspend fun getCustomerByIdSync(id: Long): CustomerEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertCustomer(customer: CustomerEntity): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertCustomers(customers: List<CustomerEntity>)

    @Update
    suspend fun updateCustomer(customer: CustomerEntity)

    @Query("UPDATE customers SET isDeleted = 1, deletedAt = :deletedAt, updatedAt = :updatedAt WHERE id = :id")
    suspend fun softDeleteCustomer(id: Long, deletedAt: Long = System.currentTimeMillis(), updatedAt: Long = System.currentTimeMillis())

    @Query("UPDATE customers SET isDeleted = 0, deletedAt = NULL, updatedAt = :updatedAt WHERE id = :id")
    suspend fun restoreCustomer(id: Long, updatedAt: Long = System.currentTimeMillis())

    @Query("DELETE FROM customers WHERE id = :id")
    suspend fun permanentlyDeleteCustomer(id: Long)

    @Query("DELETE FROM customers WHERE isDeleted = 1")
    suspend fun emptyRecycleBin()

    @Query("SELECT * FROM reminder_logs ORDER BY timestamp DESC")
    fun getAllReminderLogs(): Flow<List<ReminderLogEntity>>

    @Query("SELECT * FROM reminder_logs WHERE customerId = :customerId ORDER BY timestamp DESC")
    fun getReminderLogsForCustomer(customerId: Long): Flow<List<ReminderLogEntity>>

    @Query("SELECT COUNT(*) FROM reminder_logs WHERE customerId = :customerId AND reminderInterval = :interval AND renewalDate = :renewalDate AND status = 'SENT'")
    suspend fun countSuccessfulReminders(customerId: Long, interval: String, renewalDate: String): Int

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertReminderLog(log: ReminderLogEntity): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertReminderLogs(logs: List<ReminderLogEntity>)

    @Query("DELETE FROM reminder_logs")
    suspend fun clearReminderLogs()

    @Query("SELECT * FROM app_settings WHERE id = 1")
    fun getSettings(): Flow<AppSettingsEntity?>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun saveSettings(settings: AppSettingsEntity)

    @Query("SELECT COUNT(*) FROM customers WHERE isDeleted = 0")
    suspend fun getActiveCustomerCount(): Int

    @Query("SELECT COUNT(*) FROM customers WHERE isDeleted = 1")
    suspend fun getRecycleBinCount(): Int

    @Query("SELECT COUNT(*) FROM customers")
    suspend fun getCustomerCount(): Int

    @Query("DELETE FROM customers")
    suspend fun clearAllCustomers()
}

