package com.example.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.migration.Migration
import androidx.sqlite.db.SupportSQLiteDatabase
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import java.time.LocalDate

@Database(
    entities = [
        CustomerEntity::class,
        ReminderLogEntity::class,
        AppSettingsEntity::class
    ],
    version = 2,
    exportSchema = false
)
abstract class IQDatabase : RoomDatabase() {
    abstract fun iqDao(): IQDao

    companion object {
        @Volatile
        private var INSTANCE: IQDatabase? = null

        val MIGRATION_1_2 = object : Migration(1, 2) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL("ALTER TABLE customers ADD COLUMN idNumber TEXT NOT NULL DEFAULT ''")
                db.execSQL("ALTER TABLE customers ADD COLUMN companyName TEXT NOT NULL DEFAULT ''")
                db.execSQL("ALTER TABLE customers ADD COLUMN address TEXT NOT NULL DEFAULT ''")
                db.execSQL("ALTER TABLE customers ADD COLUMN issueDate TEXT NOT NULL DEFAULT ''")
                db.execSQL("ALTER TABLE customers ADD COLUMN isDeleted INTEGER NOT NULL DEFAULT 0")
                db.execSQL("ALTER TABLE customers ADD COLUMN deletedAt INTEGER DEFAULT NULL")
                db.execSQL("ALTER TABLE customers ADD COLUMN createdAt INTEGER NOT NULL DEFAULT ${System.currentTimeMillis()}")
                db.execSQL("ALTER TABLE customers ADD COLUMN updatedAt INTEGER NOT NULL DEFAULT ${System.currentTimeMillis()}")
                db.execSQL("ALTER TABLE customers ADD COLUMN reminderEnabled INTEGER NOT NULL DEFAULT 1")
                db.execSQL("ALTER TABLE customers ADD COLUMN remind90Days INTEGER NOT NULL DEFAULT 1")
                db.execSQL("ALTER TABLE customers ADD COLUMN remind60Days INTEGER NOT NULL DEFAULT 1")
                db.execSQL("ALTER TABLE customers ADD COLUMN remind30Days INTEGER NOT NULL DEFAULT 1")
                db.execSQL("ALTER TABLE customers ADD COLUMN remind14Days INTEGER NOT NULL DEFAULT 1")
                db.execSQL("ALTER TABLE customers ADD COLUMN remind7Days INTEGER NOT NULL DEFAULT 1")
                db.execSQL("ALTER TABLE customers ADD COLUMN remind1Day INTEGER NOT NULL DEFAULT 1")

                db.execSQL("ALTER TABLE reminder_logs ADD COLUMN recipientEmail TEXT NOT NULL DEFAULT ''")
                db.execSQL("ALTER TABLE reminder_logs ADD COLUMN renewalDate TEXT NOT NULL DEFAULT ''")
                db.execSQL("ALTER TABLE reminder_logs ADD COLUMN reminderInterval TEXT NOT NULL DEFAULT ''")
                db.execSQL("ALTER TABLE reminder_logs ADD COLUMN errorMessage TEXT DEFAULT NULL")

                db.execSQL("ALTER TABLE app_settings ADD COLUMN remind90DaysDefault INTEGER NOT NULL DEFAULT 1")
                db.execSQL("ALTER TABLE app_settings ADD COLUMN remind60DaysDefault INTEGER NOT NULL DEFAULT 1")
                db.execSQL("ALTER TABLE app_settings ADD COLUMN remind14DaysBefore INTEGER NOT NULL DEFAULT 1")
                db.execSQL("ALTER TABLE app_settings ADD COLUMN remind1DayBefore INTEGER NOT NULL DEFAULT 1")
                db.execSQL("ALTER TABLE app_settings ADD COLUMN emailSubjectTemplate TEXT NOT NULL DEFAULT 'License Renewal Reminder – {CustomerName}'")
                db.execSQL("ALTER TABLE app_settings ADD COLUMN emailBodyTemplate TEXT NOT NULL DEFAULT 'Hello {CustomerName},\\n\\nThis is a reminder that your {LicenseType} is due for renewal on {RenewalDate}.\\n\\nLicense Number: {LicenseNumber}\\n\\nPlease contact us if you require assistance with your renewal.\\n\\nKind regards,\\nIQ4U Renewals'")
                db.execSQL("ALTER TABLE app_settings ADD COLUMN cloudSyncEnabled INTEGER NOT NULL DEFAULT 1")
            }
        }

        fun getDatabase(context: Context): IQDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    IQDatabase::class.java,
                    "iq4you_renewals.db"
                )
                    .addMigrations(MIGRATION_1_2)
                    .fallbackToDestructiveMigration(dropAllTables = true)
                    .addCallback(DatabaseCallback())
                    .build()
                INSTANCE = instance
                instance
            }
        }

        private class DatabaseCallback : RoomDatabase.Callback() {
            override fun onCreate(db: SupportSQLiteDatabase) {
                super.onCreate(db)
                INSTANCE?.let { database ->
                    CoroutineScope(Dispatchers.IO).launch {
                        populateInitialData(database.iqDao())
                    }
                }
            }
        }

        suspend fun populateInitialData(dao: IQDao) {
            val today = LocalDate.now()
            val now = System.currentTimeMillis()
            val hourMs = 3600_000L
            val dayMs = 86400_000L

            val seedCustomers = listOf(
                CustomerEntity(
                    id = 1,
                    name = "Johan Van Der Merwe",
                    phone = "+27 82 555 1928",
                    email = "johan.vdm@apexlogistics.co.za",
                    idNumber = "8204155092083",
                    companyName = "Apex Logistics (Pty) Ltd",
                    address = "14 Voortrekker Road, Bellville, Cape Town",
                    vehicleRegistration = "CA 928-142",
                    vehicleType = "Bakkie / Pickup",
                    vehicleMakeModel = "Toyota Hilux 2.8 GD-6 Double Cab",
                    licenseDiscNumber = "SA-MV-928142-X",
                    issueDate = today.minusYears(1).minusDays(5).toString(),
                    expiryDate = today.minusDays(5).toString(),
                    renewalFee = 540.0,
                    notes = "Fleet vehicle #04. Primary commercial workhorse.",
                    lastReminderSent = "Email reminder sent 3 days ago",
                    isDeleted = false,
                    deletedAt = null,
                    createdAt = now - (30 * dayMs),
                    updatedAt = now,
                    reminderEnabled = true,
                    remind90Days = true,
                    remind60Days = true,
                    remind30Days = true,
                    remind14Days = true,
                    remind7Days = true,
                    remind1Day = true
                ),
                CustomerEntity(
                    id = 2,
                    name = "Lerato Mokoena",
                    phone = "+27 73 892 4410",
                    email = "lerato.m@designhaus.co.za",
                    idNumber = "8908220194087",
                    companyName = "DesignHaus Studio",
                    address = "22 Rosebank Avenue, Rosebank, Johannesburg",
                    vehicleRegistration = "GP 412-881",
                    vehicleType = "SUV",
                    vehicleMakeModel = "Mazda CX-5 2.0 Dynamic",
                    licenseDiscNumber = "SA-MV-412881-A",
                    issueDate = today.minusYears(1).toString(),
                    expiryDate = today.toString(),
                    renewalFee = 460.0,
                    notes = "Urgent: License disc expires today! Call or email.",
                    lastReminderSent = "Email reminder sent today at 08:30",
                    isDeleted = false,
                    deletedAt = null,
                    createdAt = now - (60 * dayMs),
                    updatedAt = now,
                    reminderEnabled = true,
                    remind90Days = true,
                    remind60Days = true,
                    remind30Days = true,
                    remind14Days = true,
                    remind7Days = true,
                    remind1Day = true
                ),
                CustomerEntity(
                    id = 3,
                    name = "Thabo Sithole",
                    phone = "+27 81 223 9044",
                    email = "tsithole@freightways.co.za",
                    idNumber = "7706195123081",
                    companyName = "FreightWays Express",
                    address = "8 Freight Rd, Durban Harbor, Durban",
                    vehicleRegistration = "ZN 773-201",
                    vehicleType = "Commercial Truck",
                    vehicleMakeModel = "Isuzu NPR 400 Dropside",
                    licenseDiscNumber = "SA-MV-773201-B",
                    issueDate = today.minusYears(1).plusDays(2).toString(),
                    expiryDate = today.plusDays(2).toString(),
                    renewalFee = 890.0,
                    notes = "Requires heavy vehicle roadworthy cert with renewal.",
                    lastReminderSent = "Email sent yesterday",
                    isDeleted = false,
                    deletedAt = null,
                    createdAt = now - (90 * dayMs),
                    updatedAt = now,
                    reminderEnabled = true,
                    remind90Days = true,
                    remind60Days = true,
                    remind30Days = true,
                    remind14Days = true,
                    remind7Days = true,
                    remind1Day = true
                ),
                CustomerEntity(
                    id = 4,
                    name = "David Richardson",
                    phone = "+27 84 901 3321",
                    email = "drichardson@coastallaw.co.za",
                    idNumber = "8511045089088",
                    companyName = "Coastal Law Chambers",
                    address = "102 Strand Street, Cape Town",
                    vehicleRegistration = "CA 512-390",
                    vehicleType = "Sedan",
                    vehicleMakeModel = "BMW 320d M-Sport",
                    licenseDiscNumber = "SA-MV-512390-D",
                    issueDate = today.minusYears(1).plusDays(5).toString(),
                    expiryDate = today.plusDays(5).toString(),
                    renewalFee = 480.0,
                    notes = "Executive account. Prefers email reminder first.",
                    lastReminderSent = "Email queued",
                    isDeleted = false,
                    deletedAt = null,
                    createdAt = now - (45 * dayMs),
                    updatedAt = now,
                    reminderEnabled = true,
                    remind90Days = true,
                    remind60Days = true,
                    remind30Days = true,
                    remind14Days = true,
                    remind7Days = true,
                    remind1Day = true
                ),
                CustomerEntity(
                    id = 5,
                    name = "Priya Naidoo",
                    phone = "+27 72 456 7890",
                    email = "priya.naidoo@medicare.org",
                    idNumber = "9103290078082",
                    companyName = "MediCare Clinic Group",
                    address = "55 Musgrave Road, Musgrave, Durban",
                    vehicleRegistration = "ND 602-114",
                    vehicleType = "Sedan",
                    vehicleMakeModel = "Volkswagen Polo 1.0 TSI Comfortline",
                    licenseDiscNumber = "SA-MV-602114-K",
                    issueDate = today.minusYears(1).minusDays(14).toString(),
                    expiryDate = today.minusDays(14).toString(),
                    renewalFee = 420.0,
                    notes = "Overdue penalty accumulating. Follow up urgently.",
                    lastReminderSent = "Email sent",
                    isDeleted = false,
                    deletedAt = null,
                    createdAt = now - (120 * dayMs),
                    updatedAt = now,
                    reminderEnabled = true,
                    remind90Days = true,
                    remind60Days = true,
                    remind30Days = true,
                    remind14Days = true,
                    remind7Days = true,
                    remind1Day = true
                ),
                CustomerEntity(
                    id = 6,
                    name = "Kagiso Khumalo",
                    phone = "+27 83 345 6712",
                    email = "kagiso@translink.net",
                    idNumber = "8801125201086",
                    companyName = "Translink Couriers",
                    address = "77 Airport Road, Kempton Park, Gauteng",
                    vehicleRegistration = "GP 882-901",
                    vehicleType = "Commercial Van",
                    vehicleMakeModel = "Mercedes-Benz Sprinter 516 CDI",
                    licenseDiscNumber = "SA-MV-882901-M",
                    issueDate = today.minusYears(1).plusDays(12).toString(),
                    expiryDate = today.plusDays(12).toString(),
                    renewalFee = 720.0,
                    notes = "Monthly fleet check scheduled.",
                    lastReminderSent = null,
                    isDeleted = false,
                    deletedAt = null,
                    createdAt = now - (15 * dayMs),
                    updatedAt = now,
                    reminderEnabled = true,
                    remind90Days = true,
                    remind60Days = true,
                    remind30Days = true,
                    remind14Days = true,
                    remind7Days = true,
                    remind1Day = true
                ),
                CustomerEntity(
                    id = 7,
                    name = "Anika Smit",
                    phone = "+27 76 112 3345",
                    email = "anika.smit@capevineyards.co.za",
                    idNumber = "9307040182084",
                    companyName = "Cape Vineyards Estate",
                    address = "Klein Drakenstein Rd, Paarl, Western Cape",
                    vehicleRegistration = "CA 319-804",
                    vehicleType = "SUV",
                    vehicleMakeModel = "Toyota Fortuner 2.4 GD-6",
                    licenseDiscNumber = "SA-MV-319804-R",
                    issueDate = today.minusYears(1).plusDays(24).toString(),
                    expiryDate = today.plusDays(24).toString(),
                    renewalFee = 510.0,
                    notes = "Annual renewal. Disc collection requested in Paarl.",
                    lastReminderSent = null,
                    isDeleted = false,
                    deletedAt = null,
                    createdAt = now - (10 * dayMs),
                    updatedAt = now,
                    reminderEnabled = true,
                    remind90Days = true,
                    remind60Days = true,
                    remind30Days = true,
                    remind14Days = true,
                    remind7Days = true,
                    remind1Day = true
                ),
                CustomerEntity(
                    id = 8,
                    name = "Sipho Ndlovu",
                    phone = "+27 82 789 0123",
                    email = "sipho.n@urbanpulse.co.za",
                    idNumber = "9505185491089",
                    companyName = "Urban Pulse Events",
                    address = "12 Sandton Drive, Sandton, Johannesburg",
                    vehicleRegistration = "GP 109-773",
                    vehicleType = "Motorcycle",
                    vehicleMakeModel = "BMW R1250 GS Adventure",
                    licenseDiscNumber = "SA-MV-109773-P",
                    issueDate = today.minusYears(1).plusMonths(2).toString(),
                    expiryDate = today.plusMonths(2).toString(),
                    renewalFee = 290.0,
                    notes = "Weekend adventure bike. Owner active.",
                    lastReminderSent = null,
                    isDeleted = false,
                    deletedAt = null,
                    createdAt = now - (5 * dayMs),
                    updatedAt = now,
                    reminderEnabled = true,
                    remind90Days = true,
                    remind60Days = true,
                    remind30Days = true,
                    remind14Days = true,
                    remind7Days = true,
                    remind1Day = true
                ),
                CustomerEntity(
                    id = 9,
                    name = "Michael Botha",
                    phone = "+27 83 991 2288",
                    email = "mbotha@valleydairy.co.za",
                    idNumber = "8012015094080",
                    companyName = "Valley Dairy Farms",
                    address = "R44 Farm Road, Stellenbosch",
                    vehicleRegistration = "CA 701-449",
                    vehicleType = "Bakkie / Pickup",
                    vehicleMakeModel = "Ford Ranger 2.0 Single Turbo XL",
                    licenseDiscNumber = "SA-MV-701449-C",
                    issueDate = today.minusYears(1).plusMonths(3).toString(),
                    expiryDate = today.plusMonths(3).toString(),
                    renewalFee = 490.0,
                    notes = "Farm vehicle. In good standing.",
                    lastReminderSent = null,
                    isDeleted = false,
                    deletedAt = null,
                    createdAt = now - (2 * dayMs),
                    updatedAt = now,
                    reminderEnabled = true,
                    remind90Days = true,
                    remind60Days = true,
                    remind30Days = true,
                    remind14Days = true,
                    remind7Days = true,
                    remind1Day = true
                ),
                // Recycle Bin Seed Item so the user/admin can test Restore or Permanent Delete immediately:
                CustomerEntity(
                    id = 10,
                    name = "Willem De Klerk (Decommissioned)",
                    phone = "+27 82 334 1199",
                    email = "willem.dk@oldfleet.co.za",
                    idNumber = "7502115082087",
                    companyName = "Old Fleet Holdings",
                    address = "5 Industrial Rd, Maitland, Cape Town",
                    vehicleRegistration = "CA 881-209",
                    vehicleType = "Commercial Truck",
                    vehicleMakeModel = "Scania R480 Topline",
                    licenseDiscNumber = "SA-MV-881209-Z",
                    issueDate = today.minusYears(2).toString(),
                    expiryDate = today.minusMonths(2).toString(),
                    renewalFee = 1250.0,
                    notes = "Vehicle sold. Archived in Recycle Bin.",
                    lastReminderSent = "Archived",
                    isDeleted = true,
                    deletedAt = now - (1 * dayMs),
                    createdAt = now - (200 * dayMs),
                    updatedAt = now - (1 * dayMs),
                    reminderEnabled = false,
                    remind90Days = false,
                    remind60Days = false,
                    remind30Days = false,
                    remind14Days = false,
                    remind7Days = false,
                    remind1Day = false
                )
            )

            dao.insertCustomers(seedCustomers)

            val seedLogs = listOf(
                ReminderLogEntity(
                    id = 1,
                    customerId = 2,
                    customerName = "Lerato Mokoena",
                    vehiclePlate = "GP 412-881",
                    recipientEmail = "lerato.m@designhaus.co.za",
                    renewalDate = today.toString(),
                    reminderInterval = "DUE_TODAY",
                    channel = "EMAIL",
                    status = "SENT",
                    messageText = "Hello Lerato Mokoena,\n\nThis is a reminder that your SUV is due for renewal on ${today}.\n\nLicense Number: SA-MV-412881-A\n\nPlease contact us if you require assistance with your renewal.\n\nKind regards,\nIQ4U Renewals",
                    timestamp = now - (2 * hourMs)
                ),
                ReminderLogEntity(
                    id = 2,
                    customerId = 1,
                    customerName = "Johan Van Der Merwe",
                    vehiclePlate = "CA 928-142",
                    recipientEmail = "johan.vdm@apexlogistics.co.za",
                    renewalDate = today.minusDays(5).toString(),
                    reminderInterval = "OVERDUE",
                    channel = "EMAIL",
                    status = "SENT",
                    messageText = "Hello Johan Van Der Merwe,\n\nThis is an urgent reminder that your Bakkie / Pickup license expired on ${today.minusDays(5)}.\n\nLicense Number: SA-MV-928142-X\n\nKind regards,\nIQ4U Renewals",
                    timestamp = now - (1 * dayMs)
                ),
                ReminderLogEntity(
                    id = 3,
                    customerId = 3,
                    customerName = "Thabo Sithole",
                    vehiclePlate = "ZN 773-201",
                    recipientEmail = "tsithole@freightways.co.za",
                    renewalDate = today.plusDays(2).toString(),
                    reminderInterval = "1_DAY",
                    channel = "EMAIL",
                    status = "SENT",
                    messageText = "Hello Thabo Sithole,\n\nThis is a reminder that your Commercial Truck is due for renewal on ${today.plusDays(2)}.\n\nLicense Number: SA-MV-773201-B\n\nKind regards,\nIQ4U Renewals",
                    timestamp = now - (2 * dayMs)
                ),
                ReminderLogEntity(
                    id = 4,
                    customerId = 5,
                    customerName = "Priya Naidoo",
                    vehiclePlate = "ND 602-114",
                    recipientEmail = "priya.naidoo@medicare.org",
                    renewalDate = today.minusDays(14).toString(),
                    reminderInterval = "14_DAYS",
                    channel = "EMAIL",
                    status = "SENT",
                    messageText = "Urgent: Vehicle ND 602-114 disc expired 14 days ago. Late penalty applies. IQ4YOU renewal assistance available.",
                    timestamp = now - (3 * dayMs)
                ),
                ReminderLogEntity(
                    id = 5,
                    customerId = 4,
                    customerName = "David Richardson",
                    vehiclePlate = "CA 512-390",
                    recipientEmail = "drichardson@coastallaw.co.za",
                    renewalDate = today.plusDays(5).toString(),
                    reminderInterval = "7_DAYS",
                    channel = "EMAIL",
                    status = "SENT",
                    messageText = "Hello David Richardson,\n\nThis is a reminder that your Sedan is due for renewal on ${today.plusDays(5)}.\n\nLicense Number: SA-MV-512390-D\n\nKind regards,\nIQ4U Renewals",
                    timestamp = now - (4 * dayMs)
                )
            )

            dao.insertReminderLogs(seedLogs)

            val initialSettings = AppSettingsEntity(
                id = 1,
                automaticReminders = true,
                remind90DaysDefault = true,
                remind60DaysDefault = true,
                remind30DaysBefore = true,
                remind14DaysBefore = true,
                remind7DaysBefore = true,
                remind1DayBefore = true,
                consolidatePerContact = true,
                reminderTime = "09:00 AM",
                emailSubjectTemplate = "License Renewal Reminder – {CustomerName}",
                emailBodyTemplate = "Hello {CustomerName},\n\nThis is a reminder that your {LicenseType} is due for renewal on {RenewalDate}.\n\nLicense Number: {LicenseNumber}\n\nPlease contact us if you require assistance with your renewal.\n\nKind regards,\nIQ4U Renewals",
                backendUrl = "",
                backendConnected = true,
                lastSyncTime = "Persistent Room & Cloud Ready",
                cloudSyncEnabled = true
            )
            dao.saveSettings(initialSettings)
        }
    }
}

