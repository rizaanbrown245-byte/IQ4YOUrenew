package com.example.data.service

import android.content.Context
import android.util.Log
import com.example.data.model.Customer
import com.google.firebase.FirebaseApp
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.SetOptions
import kotlinx.coroutines.tasks.await
import kotlinx.coroutines.withTimeoutOrNull

class FirestoreService(private val context: Context) {

    private val firestore: FirebaseFirestore? by lazy {
        try {
            if (FirebaseApp.getApps(context).isNotEmpty()) {
                FirebaseFirestore.getInstance()
            } else {
                null
            }
        } catch (e: Exception) {
            Log.w(TAG, "Firebase not initialized: ${e.message}")
            null
        }
    }

    fun isCloudAvailable(): Boolean {
        return firestore != null
    }

    suspend fun saveCustomer(customer: Customer): Boolean {
        val db = firestore ?: return false
        return try {
            val docRef = db.collection(COLLECTION_CUSTOMERS).document(customer.id.toString())
            val data = customerToMap(customer)
            withTimeoutOrNull(5000L) {
                docRef.set(data, SetOptions.merge()).await()
            } != null
        } catch (e: Exception) {
            Log.e(TAG, "Error saving customer to Firestore: ${e.message}", e)
            false
        }
    }

    suspend fun softDeleteCustomer(id: Long, deletedAt: Long): Boolean {
        val db = firestore ?: return false
        return try {
            val docRef = db.collection(COLLECTION_CUSTOMERS).document(id.toString())
            withTimeoutOrNull(5000L) {
                docRef.update(
                    mapOf(
                        "isDeleted" to true,
                        "deletedAt" to deletedAt,
                        "updatedAt" to System.currentTimeMillis()
                    )
                ).await()
            } != null
        } catch (e: Exception) {
            Log.e(TAG, "Error soft-deleting customer in Firestore: ${e.message}", e)
            false
        }
    }

    suspend fun restoreCustomer(id: Long): Boolean {
        val db = firestore ?: return false
        return try {
            val docRef = db.collection(COLLECTION_CUSTOMERS).document(id.toString())
            withTimeoutOrNull(5000L) {
                docRef.update(
                    mapOf(
                        "isDeleted" to false,
                        "deletedAt" to null,
                        "updatedAt" to System.currentTimeMillis()
                    )
                ).await()
            } != null
        } catch (e: Exception) {
            Log.e(TAG, "Error restoring customer in Firestore: ${e.message}", e)
            false
        }
    }

    suspend fun permanentlyDeleteCustomer(id: Long): Boolean {
        val db = firestore ?: return false
        return try {
            val docRef = db.collection(COLLECTION_CUSTOMERS).document(id.toString())
            withTimeoutOrNull(5000L) {
                docRef.delete().await()
            } != null
        } catch (e: Exception) {
            Log.e(TAG, "Error permanently deleting customer in Firestore: ${e.message}", e)
            false
        }
    }

    suspend fun fetchAllRemoteCustomers(): List<Customer>? {
        val db = firestore ?: return null
        return try {
            withTimeoutOrNull(8000L) {
                val snapshot = db.collection(COLLECTION_CUSTOMERS).get().await()
                snapshot.documents.mapNotNull { doc ->
                    try {
                        mapToCustomer(doc.id.toLongOrNull() ?: 0L, doc.data ?: emptyMap())
                    } catch (e: Exception) {
                        null
                    }
                }
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error fetching customers from Firestore: ${e.message}", e)
            null
        }
    }

    private fun customerToMap(c: Customer): Map<String, Any?> {
        return mapOf(
            "id" to c.id,
            "name" to c.name,
            "phone" to c.phone,
            "email" to c.email,
            "idNumber" to c.idNumber,
            "companyName" to c.companyName,
            "address" to c.address,
            "vehicleRegistration" to c.vehicleRegistration,
            "vehicleType" to c.vehicleType,
            "vehicleMakeModel" to c.vehicleMakeModel,
            "licenseDiscNumber" to c.licenseDiscNumber,
            "issueDate" to c.issueDate,
            "expiryDate" to c.expiryDate,
            "renewalFee" to c.renewalFee,
            "notes" to c.notes,
            "lastReminderSent" to c.lastReminderSent,
            "isDeleted" to c.isDeleted,
            "deletedAt" to c.deletedAt,
            "createdAt" to c.createdAt,
            "updatedAt" to c.updatedAt,
            "reminderEnabled" to c.reminderEnabled,
            "remind90Days" to c.remind90Days,
            "remind60Days" to c.remind60Days,
            "remind30Days" to c.remind30Days,
            "remind14Days" to c.remind14Days,
            "remind7Days" to c.remind7Days,
            "remind1Day" to c.remind1Day
        )
    }

    private fun mapToCustomer(id: Long, map: Map<String, Any?>): Customer {
        return Customer(
            id = (map["id"] as? Number)?.toLong() ?: id,
            name = map["name"] as? String ?: "",
            phone = map["phone"] as? String ?: "",
            email = map["email"] as? String ?: "",
            idNumber = map["idNumber"] as? String ?: "",
            companyName = map["companyName"] as? String ?: "",
            address = map["address"] as? String ?: "",
            vehicleRegistration = map["vehicleRegistration"] as? String ?: "",
            vehicleType = map["vehicleType"] as? String ?: "Sedan",
            vehicleMakeModel = map["vehicleMakeModel"] as? String ?: "",
            licenseDiscNumber = map["licenseDiscNumber"] as? String ?: "",
            issueDate = map["issueDate"] as? String ?: "",
            expiryDate = map["expiryDate"] as? String ?: "",
            renewalFee = (map["renewalFee"] as? Number)?.toDouble() ?: 0.0,
            notes = map["notes"] as? String ?: "",
            lastReminderSent = map["lastReminderSent"] as? String,
            isDeleted = map["isDeleted"] as? Boolean ?: false,
            deletedAt = (map["deletedAt"] as? Number)?.toLong(),
            createdAt = (map["createdAt"] as? Number)?.toLong() ?: System.currentTimeMillis(),
            updatedAt = (map["updatedAt"] as? Number)?.toLong() ?: System.currentTimeMillis(),
            reminderEnabled = map["reminderEnabled"] as? Boolean ?: true,
            remind90Days = map["remind90Days"] as? Boolean ?: true,
            remind60Days = map["remind60Days"] as? Boolean ?: true,
            remind30Days = map["remind30Days"] as? Boolean ?: true,
            remind14Days = map["remind14Days"] as? Boolean ?: true,
            remind7Days = map["remind7Days"] as? Boolean ?: true,
            remind1Day = map["remind1Day"] as? Boolean ?: true
        )
    }

    companion object {
        private const val TAG = "FirestoreService"
        private const val COLLECTION_CUSTOMERS = "customers"
    }
}
