package com.example.ui.screens.history

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.ClearAll
import androidx.compose.material.icons.filled.Email
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.NotificationsActive
import androidx.compose.material.icons.filled.Schedule
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.ReminderChannel
import com.example.data.model.ReminderLog
import com.example.data.model.ReminderStatus
import com.example.ui.components.BrandHeader
import com.example.ui.components.VehiclePlateBadge
import com.example.ui.theme.CharcoalBorder
import com.example.ui.theme.CharcoalCard
import com.example.ui.theme.CharcoalElevated
import com.example.ui.theme.IQYellow
import com.example.ui.theme.StatusBlue
import com.example.ui.theme.StatusGreen
import com.example.ui.theme.StatusOrange
import com.example.ui.theme.StatusRed
import com.example.ui.theme.TextDark
import com.example.ui.theme.TextLightGray
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextWhite
import com.example.ui.viewmodel.RenewalsViewModel
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun RenewalHistoryScreen(
    viewModel: RenewalsViewModel,
    modifier: Modifier = Modifier
) {
    val reminderLogs by viewModel.reminderLogs.collectAsState()
    val settings by viewModel.appSettings.collectAsState()
    val context = LocalContext.current

    var selectedChannelFilter by remember { mutableStateOf<ReminderChannel?>(null) }
    var showClearDialog by remember { mutableStateOf(false) }

    val filteredLogs = remember(reminderLogs, selectedChannelFilter) {
        if (selectedChannelFilter == null) {
            reminderLogs
        } else {
            reminderLogs.filter { it.channel == selectedChannelFilter }
        }
    }

    val dateFormatter = remember { SimpleDateFormat("dd MMM yyyy, HH:mm", Locale.getDefault()) }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp)
            .testTag("history_screen"),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            BrandHeader(isOnline = settings.backendConnected)
        }

        // Header Title and Clear Action
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "Renewal History & Audit",
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.Bold,
                        color = TextWhite
                    )
                    Text(
                        text = "Complete log of automated & manual dispatches",
                        fontSize = 12.sp,
                        color = TextMuted
                    )
                }

                if (reminderLogs.isNotEmpty()) {
                    OutlinedButton(
                        onClick = { showClearDialog = true },
                        shape = RoundedCornerShape(8.dp),
                        border = BorderStroke(1.dp, CharcoalBorder),
                        modifier = Modifier.testTag("clear_history_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.ClearAll,
                            contentDescription = null,
                            tint = TextMuted,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Clear", color = TextMuted, fontSize = 12.sp)
                    }
                }
            }
        }

        // Channel Filters Row
        item {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                // "All" filter chip
                val isAllSelected = selectedChannelFilter == null
                FilterChip(
                    selected = isAllSelected,
                    onClick = { selectedChannelFilter = null },
                    label = { Text("All (${reminderLogs.size})", fontSize = 12.sp) },
                    colors = FilterChipDefaults.filterChipColors(
                        selectedContainerColor = IQYellow,
                        selectedLabelColor = TextDark,
                        containerColor = CharcoalElevated,
                        labelColor = TextLightGray
                    ),
                    border = BorderStroke(1.dp, if (isAllSelected) IQYellow else CharcoalBorder)
                )

                // Individual channels
                ReminderChannel.values().forEach { channel ->
                    val isSelected = selectedChannelFilter == channel
                    val count = reminderLogs.count { it.channel == channel }
                    FilterChip(
                        selected = isSelected,
                        onClick = { selectedChannelFilter = channel },
                        label = { Text("${channel.displayName} ($count)", fontSize = 12.sp) },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = IQYellow,
                            selectedLabelColor = TextDark,
                            containerColor = CharcoalElevated,
                            labelColor = TextLightGray
                        ),
                        border = BorderStroke(1.dp, if (isSelected) IQYellow else CharcoalBorder)
                    )
                }
            }
        }

        // History Log Items
        if (filteredLogs.isEmpty()) {
            item {
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(top = 16.dp),
                    shape = RoundedCornerShape(14.dp),
                    colors = CardDefaults.cardColors(containerColor = CharcoalCard),
                    border = BorderStroke(1.dp, CharcoalBorder)
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(32.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Icon(
                            imageVector = Icons.Default.History,
                            contentDescription = null,
                            tint = TextMuted,
                            modifier = Modifier.size(40.dp)
                        )
                        Spacer(modifier = Modifier.height(10.dp))
                        Text(
                            text = "No History Records Found",
                            color = TextWhite,
                            fontWeight = FontWeight.Bold,
                            fontSize = 15.sp
                        )
                        Text(
                            text = "Dispatched reminders and renewal messages will be recorded here.",
                            color = TextMuted,
                            fontSize = 12.sp
                        )
                    }
                }
            }
        } else {
            items(filteredLogs, key = { it.id }) { log ->
                HistoryItemCard(log = log, dateFormatter = dateFormatter)
            }
        }

        item {
            Spacer(modifier = Modifier.height(24.dp))
        }
    }

    if (showClearDialog) {
        AlertDialog(
            onDismissRequest = { showClearDialog = false },
            title = {
                Text(
                    text = "Clear Audit History?",
                    color = TextWhite,
                    fontWeight = FontWeight.Bold
                )
            },
            text = {
                Text(
                    text = "This will erase all reminder logs from local audit storage. Customer vehicle records will not be affected.",
                    color = TextLightGray
                )
            },
            containerColor = CharcoalCard,
            confirmButton = {
                Button(
                    onClick = {
                        viewModel.clearAuditHistory(context)
                        showClearDialog = false
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = StatusRed)
                ) {
                    Text("Clear All Logs", color = TextWhite, fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { showClearDialog = false }) {
                    Text("Cancel", color = TextLightGray)
                }
            }
        )
    }
}

@Composable
private fun HistoryItemCard(
    log: ReminderLog,
    dateFormatter: SimpleDateFormat
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = CharcoalCard),
        border = BorderStroke(1.dp, CharcoalBorder)
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            // Header Row: Channel & Status
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Channel Badge
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Surface(
                        shape = RoundedCornerShape(6.dp),
                        color = when (log.channel) {
                            ReminderChannel.WHATSAPP -> StatusGreen.copy(alpha = 0.2f)
                            ReminderChannel.EMAIL -> StatusBlue.copy(alpha = 0.2f)
                            ReminderChannel.SYSTEM -> IQYellow.copy(alpha = 0.2f)
                            ReminderChannel.SMS -> StatusOrange.copy(alpha = 0.2f)
                        }
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                imageVector = when (log.channel) {
                                    ReminderChannel.WHATSAPP -> Icons.Default.NotificationsActive
                                    ReminderChannel.EMAIL -> Icons.Default.Email
                                    ReminderChannel.SYSTEM -> Icons.Default.Schedule
                                    ReminderChannel.SMS -> Icons.Default.NotificationsActive
                                },
                                contentDescription = null,
                                tint = when (log.channel) {
                                    ReminderChannel.WHATSAPP -> StatusGreen
                                    ReminderChannel.EMAIL -> StatusBlue
                                    ReminderChannel.SYSTEM -> IQYellow
                                    ReminderChannel.SMS -> StatusOrange
                                },
                                modifier = Modifier.size(13.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = log.channel.displayName,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = when (log.channel) {
                                    ReminderChannel.WHATSAPP -> StatusGreen
                                    ReminderChannel.EMAIL -> StatusBlue
                                    ReminderChannel.SYSTEM -> IQYellow
                                    ReminderChannel.SMS -> StatusOrange
                                }
                            )
                        }
                    }

                    Spacer(modifier = Modifier.width(8.dp))

                    Text(
                        text = dateFormatter.format(Date(log.timestamp)),
                        fontSize = 11.sp,
                        color = TextMuted
                    )
                }

                // Delivery Status Pill
                Surface(
                    shape = RoundedCornerShape(6.dp),
                    color = when (log.status) {
                        ReminderStatus.DELIVERED -> StatusGreen.copy(alpha = 0.15f)
                        ReminderStatus.SENT -> StatusBlue.copy(alpha = 0.15f)
                        ReminderStatus.QUEUED -> StatusOrange.copy(alpha = 0.15f)
                        ReminderStatus.FAILED -> StatusRed.copy(alpha = 0.15f)
                    }
                ) {
                    Text(
                        text = log.status.displayName,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        color = when (log.status) {
                            ReminderStatus.DELIVERED -> StatusGreen
                            ReminderStatus.SENT -> StatusBlue
                            ReminderStatus.QUEUED -> StatusOrange
                            ReminderStatus.FAILED -> StatusRed
                        },
                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 3.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Customer & Vehicle
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = log.customerName,
                    fontWeight = FontWeight.Bold,
                    fontSize = 15.sp,
                    color = TextWhite
                )
                VehiclePlateBadge(plate = log.vehiclePlate)
            }

            Spacer(modifier = Modifier.height(8.dp))

            // Message text container
            Surface(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(8.dp),
                color = CharcoalElevated
            ) {
                Text(
                    text = log.messageText,
                    fontSize = 12.sp,
                    color = TextLightGray,
                    modifier = Modifier.padding(10.dp)
                )
            }
        }
    }
}
