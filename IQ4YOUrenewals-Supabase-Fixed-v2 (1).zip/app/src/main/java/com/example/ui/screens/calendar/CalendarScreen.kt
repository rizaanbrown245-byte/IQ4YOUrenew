package com.example.ui.screens.calendar

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ChevronLeft
import androidx.compose.material.icons.filled.ChevronRight
import androidx.compose.material.icons.filled.Email
import androidx.compose.material.icons.filled.NotificationsActive
import androidx.compose.material.icons.filled.Today
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.Customer
import com.example.data.model.RenewalStatus
import com.example.ui.components.BrandHeader
import com.example.ui.components.SectionHeader
import com.example.ui.components.StatusBadge
import com.example.ui.components.VehiclePlateBadge
import com.example.ui.theme.CharcoalBorder
import com.example.ui.theme.CharcoalCard
import com.example.ui.theme.CharcoalElevated
import com.example.ui.theme.IQYellow
import com.example.ui.theme.StatusGreen
import com.example.ui.theme.StatusOrange
import com.example.ui.theme.StatusRed
import com.example.ui.theme.StatusYellow
import com.example.ui.theme.TextDark
import com.example.ui.theme.TextLightGray
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextWhite
import com.example.ui.viewmodel.RenewalsViewModel
import java.time.DayOfWeek
import java.time.LocalDate
import java.time.YearMonth
import java.time.format.DateTimeFormatter

@Composable
fun CalendarScreen(
    viewModel: RenewalsViewModel,
    modifier: Modifier = Modifier
) {
    val currentMonth by viewModel.calendarMonth.collectAsState()
    val selectedDate by viewModel.selectedCalendarDate.collectAsState()
    val monthlyRenewals by viewModel.calendarMonthlyRenewals.collectAsState()
    val allCustomers by viewModel.allCustomers.collectAsState()
    val settings by viewModel.appSettings.collectAsState()
    val context = LocalContext.current

    val monthTitle = currentMonth.format(DateTimeFormatter.ofPattern("MMMM yyyy"))

    // Map each date in this month to customers expiring on that date
    val renewalsByDate = allCustomers.groupBy { it.expiryDate }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp)
            .testTag("calendar_screen"),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            BrandHeader(isOnline = settings.backendConnected)
        }

        // Calendar Month Navigator
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = CharcoalCard),
                border = BorderStroke(1.dp, CharcoalBorder)
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    // Header with Month Name and Prev / Next
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(
                                text = monthTitle,
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold,
                                color = TextWhite
                            )
                            Text(
                                text = "${monthlyRenewals.size} renewals this month",
                                fontSize = 11.sp,
                                color = IQYellow
                            )
                        }

                        Row(verticalAlignment = Alignment.CenterVertically) {
                            IconButton(
                                onClick = { viewModel.previousMonth() },
                                modifier = Modifier
                                    .size(36.dp)
                                    .testTag("calendar_prev_month")
                            ) {
                                Icon(
                                    imageVector = Icons.Default.ChevronLeft,
                                    contentDescription = "Previous month",
                                    tint = TextWhite
                                )
                            }

                            IconButton(
                                onClick = { viewModel.nextMonth() },
                                modifier = Modifier
                                    .size(36.dp)
                                    .testTag("calendar_next_month")
                            ) {
                                Icon(
                                    imageVector = Icons.Default.ChevronRight,
                                    contentDescription = "Next month",
                                    tint = TextWhite
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    // Monday-first Weekday Header (Mon, Tue, Wed, Thu, Fri, Sat, Sun)
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceAround
                    ) {
                        val daysOfWeek = listOf("Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun")
                        daysOfWeek.forEach { dayName ->
                            Text(
                                text = dayName,
                                color = if (dayName == "Sat" || dayName == "Sun") TextMuted else TextLightGray,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                textAlign = TextAlign.Center,
                                modifier = Modifier.weight(1f)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    // Calendar Days Grid (Monday-first)
                    MonthCalendarGrid(
                        yearMonth = currentMonth,
                        selectedDate = selectedDate,
                        renewalsByDate = renewalsByDate,
                        onDateSelected = { date -> viewModel.selectCalendarDate(date) }
                    )
                }
            }
        }

        // Agenda Section
        item {
            SectionHeader(
                title = if (selectedDate != null) {
                    "Renewals for ${selectedDate!!.format(DateTimeFormatter.ofPattern("dd MMM yyyy"))}"
                } else {
                    "Monthly Renewal Agenda ($monthTitle)"
                },
                badgeCount = monthlyRenewals.size,
                actionText = if (selectedDate != null) "Show All Month" else null,
                onActionClick = { viewModel.selectCalendarDate(null) }
            )
        }

        if (monthlyRenewals.isEmpty()) {
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = CharcoalCard),
                    border = BorderStroke(1.dp, CharcoalBorder)
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(28.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Icon(
                            imageVector = Icons.Default.Today,
                            contentDescription = null,
                            tint = TextMuted,
                            modifier = Modifier.size(36.dp)
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = "No Renewals Scheduled",
                            color = TextWhite,
                            fontWeight = FontWeight.Bold,
                            fontSize = 14.sp
                        )
                        Text(
                            text = if (selectedDate != null) "No vehicle discs expire on this specific date." else "No vehicle license discs expire in $monthTitle.",
                            color = TextMuted,
                            fontSize = 12.sp,
                            textAlign = TextAlign.Center
                        )
                    }
                }
            }
        } else {
            items(monthlyRenewals, key = { it.id }) { customer ->
                CalendarAgendaItem(
                    customer = customer,
                    onWhatsApp = { viewModel.sendDirectWhatsApp(context, customer) },
                    onEmail = { viewModel.sendDirectEmail(context, customer) }
                )
            }
        }

        item {
            Spacer(modifier = Modifier.height(24.dp))
        }
    }
}

@Composable
private fun MonthCalendarGrid(
    yearMonth: YearMonth,
    selectedDate: LocalDate?,
    renewalsByDate: Map<String, List<Customer>>,
    onDateSelected: (LocalDate) -> Unit
) {
    val firstDayOfMonth = yearMonth.atDay(1)
    val daysInMonth = yearMonth.lengthOfMonth()

    // DayOfWeek in Java: MONDAY is 1, SUNDAY is 7.
    // For Monday-first layout:
    // Monday = offset 0, Tuesday = 1, ..., Sunday = 6.
    val startOffset = firstDayOfMonth.dayOfWeek.value - 1

    val totalCells = ((startOffset + daysInMonth + 6) / 7) * 7
    val today = LocalDate.now()

    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
        for (week in 0 until (totalCells / 7)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceAround
            ) {
                for (dayOfWeek in 0..6) {
                    val cellIndex = week * 7 + dayOfWeek
                    val dayNumber = cellIndex - startOffset + 1

                    if (dayNumber in 1..daysInMonth) {
                        val date = yearMonth.atDay(dayNumber)
                        val isSelected = selectedDate == date
                        val isToday = today == date
                        val dateStr = date.toString()
                        val dayRenewals = renewalsByDate[dateStr].orEmpty()

                        CalendarDayCell(
                            day = dayNumber,
                            isToday = isToday,
                            isSelected = isSelected,
                            renewals = dayRenewals,
                            modifier = Modifier
                                .weight(1f)
                                .aspectRatio(1f)
                                .padding(2.dp),
                            onClick = { onDateSelected(date) }
                        )
                    } else {
                        // Empty slot
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .aspectRatio(1f)
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun CalendarDayCell(
    day: Int,
    isToday: Boolean,
    isSelected: Boolean,
    renewals: List<Customer>,
    modifier: Modifier = Modifier,
    onClick: () -> Unit
) {
    val hasRenewals = renewals.isNotEmpty()

    // Determine badge color based on renewal urgency
    val dotColor = when {
        renewals.any { it.status == RenewalStatus.EXPIRED } -> StatusRed
        renewals.any { it.status == RenewalStatus.DUE_TODAY } -> StatusOrange
        renewals.any { it.status == RenewalStatus.EXPIRING_SOON } -> StatusYellow
        hasRenewals -> StatusGreen
        else -> Color.Transparent
    }

    Box(
        modifier = modifier
            .clip(RoundedCornerShape(8.dp))
            .background(
                when {
                    isSelected -> IQYellow
                    isToday -> CharcoalElevated
                    else -> Color.Transparent
                }
            )
            .then(
                if (isToday && !isSelected) {
                    Modifier.border(1.dp, IQYellow, RoundedCornerShape(8.dp))
                } else {
                    Modifier
                }
            )
            .clickable { onClick() },
        contentAlignment = Alignment.Center
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Text(
                text = day.toString(),
                fontSize = 12.sp,
                fontWeight = if (isToday || isSelected || hasRenewals) FontWeight.Bold else FontWeight.Normal,
                color = when {
                    isSelected -> TextDark
                    isToday -> IQYellow
                    else -> TextWhite
                }
            )

            if (hasRenewals) {
                Spacer(modifier = Modifier.height(2.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(2.dp)) {
                    Box(
                        modifier = Modifier
                            .size(5.dp)
                            .clip(CircleShape)
                            .background(if (isSelected) TextDark else dotColor)
                    )
                }
            }
        }
    }
}

@Composable
private fun CalendarAgendaItem(
    customer: Customer,
    onWhatsApp: () -> Unit,
    onEmail: () -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = CharcoalCard),
        border = BorderStroke(1.dp, CharcoalBorder)
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                VehiclePlateBadge(plate = customer.vehicleRegistration)
                StatusBadge(
                    status = customer.status,
                    daysLeft = customer.daysUntilExpiry
                )
            }

            Spacer(modifier = Modifier.height(8.dp))

            Text(
                text = customer.name,
                fontWeight = FontWeight.Bold,
                fontSize = 15.sp,
                color = TextWhite
            )

            Text(
                text = "${customer.vehicleMakeModel} • Due on ${customer.expiryDate}",
                fontSize = 12.sp,
                color = TextLightGray
            )

            Spacer(modifier = Modifier.height(8.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                if (customer.renewalFee > 0) {
                    Text(
                        text = "Renewal Fee: R${"%.2f".format(customer.renewalFee)}",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = IQYellow
                    )
                } else {
                    Spacer(modifier = Modifier.width(1.dp))
                }

                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Surface(
                        shape = RoundedCornerShape(6.dp),
                        color = StatusGreen.copy(alpha = 0.2f),
                        modifier = Modifier.clickable { onWhatsApp() }
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                imageVector = Icons.Default.NotificationsActive,
                                contentDescription = "WhatsApp",
                                tint = StatusGreen,
                                modifier = Modifier.size(13.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = "WhatsApp",
                                color = StatusGreen,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }

                    Surface(
                        shape = RoundedCornerShape(6.dp),
                        color = CharcoalElevated,
                        border = BorderStroke(1.dp, CharcoalBorder),
                        modifier = Modifier.clickable { onEmail() }
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                imageVector = Icons.Default.Email,
                                contentDescription = "Email",
                                tint = TextLightGray,
                                modifier = Modifier.size(13.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = "Email",
                                color = TextLightGray,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Medium
                            )
                        }
                    }
                }
            }
        }
    }
}
