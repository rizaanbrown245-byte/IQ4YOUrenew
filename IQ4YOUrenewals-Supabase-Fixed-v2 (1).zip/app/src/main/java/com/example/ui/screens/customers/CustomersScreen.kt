package com.example.ui.screens.customers

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.DocumentScanner
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Email
import androidx.compose.material.icons.filled.NotificationsActive
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Phone
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Badge
import androidx.compose.material3.BadgedBox
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.Customer
import com.example.ui.components.BrandHeader
import com.example.ui.components.StatusBadge
import com.example.ui.components.VehiclePlateBadge
import com.example.ui.screens.dashboard.ScanLicenseDialog
import com.example.ui.theme.CharcoalBorder
import com.example.ui.theme.CharcoalCard
import com.example.ui.theme.CharcoalElevated
import com.example.ui.theme.IQYellow
import com.example.ui.theme.StatusBlue
import com.example.ui.theme.StatusGreen
import com.example.ui.theme.StatusOrange
import com.example.ui.theme.StatusRed
import com.example.ui.theme.TextDark
import com.example.ui.theme.TextLightGray
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextWhite
import com.example.ui.viewmodel.CustomerFilterTab
import com.example.ui.viewmodel.RenewalsViewModel
import com.example.ui.viewmodel.ScannedLicenseData

@Composable
fun CustomersScreen(
    viewModel: RenewalsViewModel,
    onNavigateToRecycleBin: () -> Unit = {},
    modifier: Modifier = Modifier
) {
    val customers by viewModel.filteredCustomers.collectAsState()
    val allCustomersList by viewModel.allCustomers.collectAsState()
    val recycleBinCustomers by viewModel.recycleBinCustomers.collectAsState()
    val searchQuery by viewModel.searchQuery.collectAsState()
    val selectedFilter by viewModel.selectedFilterTab.collectAsState()
    val settings by viewModel.appSettings.collectAsState()
    val context = LocalContext.current

    var showAddEditDialog by remember { mutableStateOf(false) }
    var showScanDialog by remember { mutableStateOf(false) }
    var scannedPrefillData by remember { mutableStateOf<ScannedLicenseData?>(null) }
    var customerToEdit by remember { mutableStateOf<Customer?>(null) }
    var customerToDelete by remember { mutableStateOf<Customer?>(null) }

    Scaffold(
        modifier = modifier
            .fillMaxSize()
            .testTag("customers_screen"),
        containerColor = Color.Transparent,
        floatingActionButton = {
            FloatingActionButton(
                onClick = {
                    customerToEdit = null
                    showAddEditDialog = true
                },
                containerColor = IQYellow,
                contentColor = TextDark,
                shape = CircleShape,
                modifier = Modifier.testTag("fab_add_customer")
            ) {
                Icon(
                    imageVector = Icons.Default.Add,
                    contentDescription = "Add Customer",
                    modifier = Modifier.size(24.dp)
                )
            }
        }
    ) { innerPadding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            item {
                BrandHeader(isOnline = settings.backendConnected)
            }

            // Title & Add Button header
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = "Customer Registry",
                            style = MaterialTheme.typography.titleLarge,
                            fontWeight = FontWeight.Bold,
                            color = TextWhite
                        )
                        Text(
                            text = "${allCustomersList.size} vehicles monitored",
                            fontSize = 12.sp,
                            color = TextMuted
                        )
                    }

                    Row(
                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        IconButton(
                            onClick = onNavigateToRecycleBin,
                            modifier = Modifier.testTag("btn_customers_recycle_bin")
                        ) {
                            if (recycleBinCustomers.isNotEmpty()) {
                                BadgedBox(
                                    badge = {
                                        Badge(
                                            containerColor = StatusRed,
                                            contentColor = TextWhite
                                        ) {
                                            Text(
                                                text = recycleBinCustomers.size.toString(),
                                                fontSize = 10.sp
                                            )
                                        }
                                    }
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Delete,
                                        contentDescription = "Recycle Bin",
                                        tint = IQYellow
                                    )
                                }
                            } else {
                                Icon(
                                    imageVector = Icons.Default.Delete,
                                    contentDescription = "Recycle Bin",
                                    tint = TextMuted
                                )
                            }
                        }

                        OutlinedButton(
                            onClick = { showScanDialog = true },
                            colors = ButtonDefaults.outlinedButtonColors(contentColor = IQYellow),
                            border = BorderStroke(1.dp, IQYellow.copy(alpha = 0.6f)),
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier.testTag("scan_disc_header_button")
                        ) {
                            Icon(
                                imageVector = Icons.Default.DocumentScanner,
                                contentDescription = null,
                                tint = IQYellow,
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = "Auto-Fill Disc",
                                color = IQYellow,
                                fontWeight = FontWeight.Bold,
                                fontSize = 12.sp
                            )
                        }

                        Button(
                            onClick = {
                                customerToEdit = null
                                scannedPrefillData = null
                                showAddEditDialog = true
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = IQYellow),
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier.testTag("add_customer_header_button")
                        ) {
                            Icon(
                                imageVector = Icons.Default.Add,
                                contentDescription = null,
                                tint = TextDark,
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = "Add",
                                color = TextDark,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
            }

            // Search Bar
            item {
                OutlinedTextField(
                    value = searchQuery,
                    onValueChange = { viewModel.setSearchQuery(it) },
                    placeholder = { Text("Search by name, plate, vehicle type...", color = TextMuted, fontSize = 13.sp) },
                    leadingIcon = {
                        Icon(
                            imageVector = Icons.Default.Search,
                            contentDescription = "Search",
                            tint = IQYellow
                        )
                    },
                    trailingIcon = {
                        if (searchQuery.isNotEmpty()) {
                            IconButton(onClick = { viewModel.setSearchQuery("") }) {
                                Icon(
                                    imageVector = Icons.Default.Clear,
                                    contentDescription = "Clear search",
                                    tint = TextMuted
                                )
                            }
                        }
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("search_customer_input"),
                    shape = RoundedCornerShape(12.dp),
                    singleLine = true,
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedContainerColor = CharcoalCard,
                        unfocusedContainerColor = CharcoalCard,
                        focusedBorderColor = IQYellow,
                        unfocusedBorderColor = CharcoalBorder,
                        cursorColor = IQYellow,
                        focusedTextColor = TextWhite,
                        unfocusedTextColor = TextWhite
                    )
                )
            }

            // Filter Tabs: All / Active / Expiring soon / Expired
            item {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    CustomerFilterTab.values().forEach { tab ->
                        val isSelected = selectedFilter == tab
                        FilterChip(
                            selected = isSelected,
                            onClick = { viewModel.setFilterTab(tab) },
                            label = {
                                Text(
                                    text = tab.title,
                                    fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                                    fontSize = 12.sp
                                )
                            },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = IQYellow,
                                selectedLabelColor = TextDark,
                                containerColor = CharcoalElevated,
                                labelColor = TextLightGray
                            ),
                            border = BorderStroke(1.dp, if (isSelected) IQYellow else CharcoalBorder)
                        )
                    }
                }
            }

            // Customer List
            if (customers.isEmpty()) {
                item {
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(top = 20.dp),
                        shape = RoundedCornerShape(14.dp),
                        colors = CardDefaults.cardColors(containerColor = CharcoalCard),
                        border = BorderStroke(1.dp, CharcoalBorder)
                    ) {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(32.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Icon(
                                imageVector = Icons.Default.Search,
                                contentDescription = null,
                                tint = TextMuted,
                                modifier = Modifier.size(40.dp)
                            )
                            Spacer(modifier = Modifier.height(10.dp))
                            Text(
                                text = "No Customers Found",
                                color = TextWhite,
                                fontWeight = FontWeight.Bold,
                                fontSize = 15.sp
                            )
                            Text(
                                text = if (searchQuery.isNotEmpty()) "Try adjusting your search criteria." else "Tap + Add to record your first vehicle renewal.",
                                color = TextMuted,
                                fontSize = 12.sp
                            )
                        }
                    }
                }
            } else {
                items(customers, key = { it.id }) { customer ->
                    CustomerCard(
                        customer = customer,
                        onEdit = {
                            customerToEdit = customer
                            showAddEditDialog = true
                        },
                        onDelete = {
                            customerToDelete = customer
                        },
                        onWhatsApp = { viewModel.sendDirectWhatsApp(context, customer) },
                        onEmail = { viewModel.sendDirectEmail(context, customer) }
                    )
                }
            }

            item {
                Spacer(modifier = Modifier.height(80.dp))
            }
        }
    }

    // Add / Edit Dialog
    if (showAddEditDialog) {
        AddEditCustomerDialog(
            initialCustomer = customerToEdit,
            prefillRegistration = scannedPrefillData?.vehiclePlate,
            prefillMakeModel = scannedPrefillData?.vehicleMakeModel,
            prefillType = scannedPrefillData?.vehicleType,
            prefillDiscNumber = scannedPrefillData?.licenseDiscNumber,
            prefillExpiryDate = scannedPrefillData?.expiryDate,
            prefillFee = scannedPrefillData?.renewalFee,
            prefillName = scannedPrefillData?.customerName,
            prefillPhone = scannedPrefillData?.phone,
            onDismiss = {
                showAddEditDialog = false
                customerToEdit = null
                scannedPrefillData = null
            },
            onSaveCustomer = { customer ->
                if (customer.id == 0L) {
                    viewModel.addCustomer(customer)
                } else {
                    viewModel.updateCustomer(customer)
                }
                showAddEditDialog = false
                customerToEdit = null
                scannedPrefillData = null
            }
        )
    }

    if (showScanDialog) {
        ScanLicenseDialog(
            onDismiss = { showScanDialog = false },
            onScanSuccess = { scanned ->
                scannedPrefillData = scanned
                customerToEdit = null
                showScanDialog = false
                showAddEditDialog = true
            }
        )
    }

    // Delete Confirmation Dialog (Soft Delete / Move to Recycle Bin)
    if (customerToDelete != null) {
        AlertDialog(
            onDismissRequest = { customerToDelete = null },
            title = {
                Text(
                    text = "Move to Recycle Bin?",
                    color = TextWhite,
                    fontWeight = FontWeight.Bold
                )
            },
            text = {
                Text(
                    text = "Are you sure you want to move ${customerToDelete?.name} (${customerToDelete?.vehicleRegistration}) to the Recycle Bin? You can restore this customer at any time from the Recycle Bin or permanently delete it.",
                    color = TextLightGray
                )
            },
            containerColor = CharcoalCard,
            confirmButton = {
                Button(
                    onClick = {
                        customerToDelete?.let { viewModel.deleteCustomer(it.id) }
                        customerToDelete = null
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = StatusRed)
                ) {
                    Text("Move to Bin", color = TextWhite, fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { customerToDelete = null }) {
                    Text("Cancel", color = TextLightGray)
                }
            }
        )
    }
}

@Composable
fun CustomerCard(
    customer: Customer,
    onEdit: () -> Unit,
    onDelete: () -> Unit,
    onWhatsApp: () -> Unit,
    onEmail: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onEdit() }
            .testTag("customer_card_${customer.id}"),
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = CharcoalCard),
        border = BorderStroke(1.dp, CharcoalBorder)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            // Top: Plate and Expiry status badge
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                VehiclePlateBadge(plate = customer.vehicleRegistration)
                StatusBadge(
                    status = customer.status,
                    daysLeft = customer.daysUntilExpiry
                )
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Customer Name & Vehicle Info
            Text(
                text = customer.name,
                fontWeight = FontWeight.Bold,
                fontSize = 16.sp,
                color = TextWhite
            )

            if (customer.companyName.isNotBlank() || customer.idNumber.isNotBlank()) {
                val meta = buildString {
                    if (customer.companyName.isNotBlank()) append(customer.companyName)
                    if (customer.companyName.isNotBlank() && customer.idNumber.isNotBlank()) append(" • ")
                    if (customer.idNumber.isNotBlank()) append("ID: ${customer.idNumber}")
                }
                Text(
                    text = meta,
                    fontSize = 12.sp,
                    color = IQYellow.copy(alpha = 0.9f),
                    fontWeight = FontWeight.Medium
                )
            }

            Text(
                text = "${customer.vehicleMakeModel} • ${customer.vehicleType}",
                fontSize = 13.sp,
                color = TextLightGray
            )

            Spacer(modifier = Modifier.height(6.dp))

            // Disc number, issue date and renewal fee
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                val discLabel = if (customer.issueDate.isNotBlank()) {
                    "Disc #${customer.licenseDiscNumber} • Issued: ${customer.issueDate}"
                } else {
                    "Disc #${customer.licenseDiscNumber}"
                }
                Text(
                    text = discLabel,
                    fontSize = 11.sp,
                    color = TextMuted
                )

                if (customer.renewalFee > 0) {
                    Text(
                        text = "Fee: R${"%.2f".format(customer.renewalFee)}",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        color = IQYellow
                    )
                }
            }

            // Expiry Date row
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 4.dp),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = "Expires: ${customer.expiryDate}",
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Medium,
                    color = when (customer.status) {
                        com.example.data.model.RenewalStatus.EXPIRED -> StatusRed
                        com.example.data.model.RenewalStatus.DUE_TODAY -> com.example.ui.theme.StatusOrange
                        com.example.data.model.RenewalStatus.EXPIRING_SOON -> IQYellow
                        com.example.data.model.RenewalStatus.ACTIVE -> StatusGreen
                    }
                )

                if (!customer.lastReminderSent.isNullOrEmpty()) {
                    Text(
                        text = customer.lastReminderSent,
                        fontSize = 11.sp,
                        color = TextMuted
                    )
                }
            }

            // Reminder schedule summary
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 2.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = if (customer.reminderEnabled) "Reminders: ${customer.reminderScheduleSummary}" else "Reminders: Disabled",
                    fontSize = 10.sp,
                    color = if (customer.reminderEnabled) TextMuted else StatusOrange,
                    fontWeight = FontWeight.Medium
                )
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Action row: WhatsApp, Email, Edit, Delete
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    // WhatsApp quick button
                    Surface(
                        shape = RoundedCornerShape(8.dp),
                        color = StatusGreen.copy(alpha = 0.2f),
                        modifier = Modifier.clickable { onWhatsApp() }
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                imageVector = Icons.Default.NotificationsActive,
                                contentDescription = "WhatsApp",
                                tint = StatusGreen,
                                modifier = Modifier.size(15.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = "WhatsApp",
                                color = StatusGreen,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }

                    // Email quick button
                    Surface(
                        shape = RoundedCornerShape(8.dp),
                        color = CharcoalElevated,
                        border = BorderStroke(1.dp, CharcoalBorder),
                        modifier = Modifier.clickable { onEmail() }
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                imageVector = Icons.Default.Email,
                                contentDescription = "Email",
                                tint = TextLightGray,
                                modifier = Modifier.size(15.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = "Email",
                                color = TextLightGray,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Medium
                            )
                        }
                    }
                }

                Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    IconButton(
                        onClick = onEdit,
                        modifier = Modifier.size(32.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Edit,
                            contentDescription = "Edit Customer",
                            tint = IQYellow,
                            modifier = Modifier.size(17.dp)
                        )
                    }

                    IconButton(
                        onClick = onDelete,
                        modifier = Modifier.size(32.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Delete,
                            contentDescription = "Delete Customer",
                            tint = StatusRed.copy(alpha = 0.8f),
                            modifier = Modifier.size(17.dp)
                        )
                    }
                }
            }
        }
    }
}
