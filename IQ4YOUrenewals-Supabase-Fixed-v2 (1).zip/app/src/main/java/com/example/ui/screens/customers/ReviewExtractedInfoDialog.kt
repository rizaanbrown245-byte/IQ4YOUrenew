package com.example.ui.screens.customers

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Notes
import androidx.compose.material.icons.filled.AttachMoney
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.CalendarToday
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.DirectionsCar
import androidx.compose.material.icons.filled.Email
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Phone
import androidx.compose.material.icons.filled.PictureAsPdf
import androidx.compose.material.icons.filled.Tag
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardCapitalization
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.data.model.ExtractedRenewalInfo
import com.example.ui.theme.CharcoalBorder
import com.example.ui.theme.CharcoalCard
import com.example.ui.theme.CharcoalElevated
import com.example.ui.theme.IQYellow
import com.example.ui.theme.StatusGreen
import com.example.ui.theme.TextDark
import com.example.ui.theme.TextLightGray
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextWhite

@Composable
fun ReviewExtractedInfoDialog(
    extractedInfo: ExtractedRenewalInfo,
    onDismiss: () -> Unit,
    onConfirmAndPopulate: (ExtractedRenewalInfo) -> Unit
) {
    var name by remember { mutableStateOf(extractedInfo.customerName) }
    var idNumber by remember { mutableStateOf(extractedInfo.idNumber) }
    var companyName by remember { mutableStateOf(extractedInfo.companyName) }
    var phone by remember { mutableStateOf(extractedInfo.phone) }
    var email by remember { mutableStateOf(extractedInfo.email) }
    var address by remember { mutableStateOf(extractedInfo.address) }
    var registration by remember { mutableStateOf(extractedInfo.vehicleRegistration) }
    var makeModel by remember { mutableStateOf(extractedInfo.vehicleMakeModel) }
    var discNumber by remember { mutableStateOf(extractedInfo.licenseDiscNumber) }
    var issueDate by remember { mutableStateOf(extractedInfo.issueDate) }
    var expiryDate by remember { mutableStateOf(extractedInfo.expiryDate) }
    var feeStr by remember { mutableStateOf(extractedInfo.renewalFee.toString()) }
    var notes by remember { mutableStateOf(extractedInfo.notes) }

    val vehicleTypes = listOf("Sedan", "SUV", "Bakkie / Pickup", "Commercial Truck", "Commercial Van", "Motorcycle")
    var selectedVehicleType by remember {
        mutableStateOf(
            vehicleTypes.firstOrNull { it.equals(extractedInfo.vehicleType, ignoreCase = true) } ?: vehicleTypes[0]
        )
    }

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Card(
            modifier = Modifier
                .fillMaxWidth(0.95f)
                .padding(vertical = 16.dp)
                .testTag("dialog_review_extracted_info"),
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = CharcoalCard),
            border = BorderStroke(1.dp, IQYellow.copy(alpha = 0.6f))
        ) {
            Column(
                modifier = Modifier
                    .padding(20.dp)
                    .verticalScroll(rememberScrollState())
            ) {
                // Header with Gemini Branding
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = IQYellow
                        ) {
                            Icon(
                                imageVector = Icons.Default.AutoAwesome,
                                contentDescription = "Gemini AI",
                                tint = TextDark,
                                modifier = Modifier
                                    .padding(6.dp)
                                    .size(20.dp)
                            )
                        }
                        Spacer(modifier = Modifier.width(10.dp))
                        Column {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(
                                    text = "Review Extracted Info",
                                    style = MaterialTheme.typography.titleMedium,
                                    color = TextWhite,
                                    fontWeight = FontWeight.Bold
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Surface(
                                    shape = RoundedCornerShape(4.dp),
                                    color = StatusGreen.copy(alpha = 0.2f),
                                    border = BorderStroke(0.5.dp, StatusGreen)
                                ) {
                                    Text(
                                        text = "AI PARSED",
                                        color = StatusGreen,
                                        fontSize = 9.sp,
                                        fontWeight = FontWeight.Bold,
                                        modifier = Modifier.padding(horizontal = 4.dp, vertical = 2.dp)
                                    )
                                }
                            }
                            Text(
                                text = "Check and edit fields before populating the form",
                                fontSize = 11.sp,
                                color = TextMuted
                            )
                        }
                    }

                    IconButton(
                        onClick = onDismiss,
                        modifier = Modifier.size(28.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Close,
                            contentDescription = "Close",
                            tint = TextMuted
                        )
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                // Source Document Card
                Surface(
                    shape = RoundedCornerShape(10.dp),
                    color = CharcoalElevated,
                    border = BorderStroke(1.dp, CharcoalBorder),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier.padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        val isPdf = extractedInfo.sourceFileName.endsWith(".pdf", ignoreCase = true) ||
                                extractedInfo.sourceMimeType.contains("pdf", ignoreCase = true)

                        Box(
                            modifier = Modifier
                                .size(36.dp)
                                .clip(RoundedCornerShape(6.dp))
                                .background(if (isPdf) Color(0xFFE53935).copy(alpha = 0.2f) else IQYellow.copy(alpha = 0.2f)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = if (isPdf) Icons.Default.PictureAsPdf else Icons.Default.Image,
                                contentDescription = null,
                                tint = if (isPdf) Color(0xFFEF5350) else IQYellow,
                                modifier = Modifier.size(20.dp)
                            )
                        }

                        Spacer(modifier = Modifier.width(10.dp))

                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = extractedInfo.sourceFileName.ifBlank { "Analyzed Document" },
                                color = TextWhite,
                                fontWeight = FontWeight.Bold,
                                fontSize = 12.sp,
                                maxLines = 1
                            )
                            Text(
                                text = extractedInfo.confidenceNotes.ifBlank { "Analyzed by Gemini 3.5 Flash" },
                                color = TextLightGray,
                                fontSize = 10.sp
                            )
                        }

                        Surface(
                            shape = RoundedCornerShape(10.dp),
                            color = StatusGreen.copy(alpha = 0.15f)
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Box(
                                    modifier = Modifier
                                        .size(6.dp)
                                        .clip(CircleShape)
                                        .background(StatusGreen)
                                )
                                Spacer(modifier = Modifier.width(4.dp))
                                Text(
                                    text = "Ready",
                                    color = StatusGreen,
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                // Extracted Fields for Review & Editing
                Text(
                    text = "CUSTOMER DETAILS",
                    color = IQYellow,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 0.5.sp
                )
                Spacer(modifier = Modifier.height(6.dp))

                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it },
                    label = { Text("Customer / Owner Name") },
                    leadingIcon = { Icon(Icons.Default.Person, contentDescription = null, tint = IQYellow) },
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("input_review_name"),
                    colors = outlinedFieldColors(),
                    singleLine = true
                )

                Spacer(modifier = Modifier.height(8.dp))

                Row(modifier = Modifier.fillMaxWidth()) {
                    OutlinedTextField(
                        value = idNumber,
                        onValueChange = { idNumber = it },
                        label = { Text("ID / Registration #") },
                        modifier = Modifier
                            .weight(1f)
                            .testTag("input_review_id_number"),
                        colors = outlinedFieldColors(),
                        singleLine = true
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    OutlinedTextField(
                        value = companyName,
                        onValueChange = { companyName = it },
                        label = { Text("Company / Business") },
                        modifier = Modifier
                            .weight(1f)
                            .testTag("input_review_company"),
                        colors = outlinedFieldColors(),
                        singleLine = true
                    )
                }

                Spacer(modifier = Modifier.height(8.dp))

                Row(modifier = Modifier.fillMaxWidth()) {
                    OutlinedTextField(
                        value = phone,
                        onValueChange = { phone = it },
                        label = { Text("Phone / WhatsApp") },
                        leadingIcon = { Icon(Icons.Default.Phone, contentDescription = null, tint = IQYellow) },
                        modifier = Modifier
                            .weight(1f)
                            .testTag("input_review_phone"),
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                        colors = outlinedFieldColors(),
                        singleLine = true
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    OutlinedTextField(
                        value = email,
                        onValueChange = { email = it },
                        label = { Text("Email (Optional)") },
                        leadingIcon = { Icon(Icons.Default.Email, contentDescription = null, tint = IQYellow) },
                        modifier = Modifier
                            .weight(1f)
                            .testTag("input_review_email"),
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Email),
                        colors = outlinedFieldColors(),
                        singleLine = true
                    )
                }

                Spacer(modifier = Modifier.height(8.dp))

                OutlinedTextField(
                    value = address,
                    onValueChange = { address = it },
                    label = { Text("Physical / Postal Address") },
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("input_review_address"),
                    colors = outlinedFieldColors(),
                    singleLine = true
                )

                Spacer(modifier = Modifier.height(16.dp))

                Text(
                    text = "VEHICLE & RENEWAL PARTICULARS",
                    color = IQYellow,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 0.5.sp
                )
                Spacer(modifier = Modifier.height(6.dp))

                Row(modifier = Modifier.fillMaxWidth()) {
                    OutlinedTextField(
                        value = registration,
                        onValueChange = { registration = it.uppercase() },
                        label = { Text("Registration Plate") },
                        leadingIcon = { Icon(Icons.Default.DirectionsCar, contentDescription = null, tint = IQYellow) },
                        modifier = Modifier
                            .weight(1f)
                            .testTag("input_review_plate"),
                        keyboardOptions = KeyboardOptions(capitalization = KeyboardCapitalization.Characters),
                        colors = outlinedFieldColors(),
                        singleLine = true
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    OutlinedTextField(
                        value = discNumber,
                        onValueChange = { discNumber = it },
                        label = { Text("License Disc #") },
                        leadingIcon = { Icon(Icons.Default.Tag, contentDescription = null, tint = IQYellow) },
                        modifier = Modifier
                            .weight(1f)
                            .testTag("input_review_disc"),
                        colors = outlinedFieldColors(),
                        singleLine = true
                    )
                }

                Spacer(modifier = Modifier.height(10.dp))

                OutlinedTextField(
                    value = makeModel,
                    onValueChange = { makeModel = it },
                    label = { Text("Vehicle Make & Model") },
                    leadingIcon = { Icon(Icons.Default.DirectionsCar, contentDescription = null, tint = IQYellow) },
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("input_review_makemodel"),
                    colors = outlinedFieldColors(),
                    singleLine = true
                )

                Spacer(modifier = Modifier.height(10.dp))

                Text(
                    text = "Vehicle Classification:",
                    color = TextLightGray,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Medium
                )
                Spacer(modifier = Modifier.height(4.dp))
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    vehicleTypes.forEach { type ->
                        val isSelected = selectedVehicleType == type
                        FilterChip(
                            selected = isSelected,
                            onClick = { selectedVehicleType = type },
                            label = { Text(type, fontSize = 11.sp) },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = IQYellow,
                                selectedLabelColor = TextDark,
                                containerColor = CharcoalElevated,
                                labelColor = TextLightGray
                            ),
                            border = FilterChipDefaults.filterChipBorder(
                                enabled = true,
                                selected = isSelected,
                                borderColor = if (isSelected) IQYellow else CharcoalBorder
                            )
                        )
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                Row(modifier = Modifier.fillMaxWidth()) {
                    OutlinedTextField(
                        value = issueDate,
                        onValueChange = { issueDate = it },
                        label = { Text("Issue Date (Optional)") },
                        leadingIcon = { Icon(Icons.Default.CalendarToday, contentDescription = null, tint = IQYellow) },
                        modifier = Modifier
                            .weight(1f)
                            .testTag("input_review_issue_date"),
                        colors = outlinedFieldColors(),
                        singleLine = true
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    OutlinedTextField(
                        value = expiryDate,
                        onValueChange = { expiryDate = it },
                        label = { Text("Expiry Date (YYYY-MM-DD)") },
                        leadingIcon = { Icon(Icons.Default.CalendarToday, contentDescription = null, tint = IQYellow) },
                        modifier = Modifier
                            .weight(1f)
                            .testTag("input_review_expiry"),
                        colors = outlinedFieldColors(),
                        singleLine = true
                    )
                }

                Spacer(modifier = Modifier.height(10.dp))

                OutlinedTextField(
                    value = feeStr,
                    onValueChange = { feeStr = it },
                    label = { Text("Renewal Fee (ZAR)") },
                    leadingIcon = { Icon(Icons.Default.AttachMoney, contentDescription = null, tint = IQYellow) },
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("input_review_fee"),
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                    colors = outlinedFieldColors(),
                    singleLine = true
                )

                Spacer(modifier = Modifier.height(10.dp))

                OutlinedTextField(
                    value = notes,
                    onValueChange = { notes = it },
                    label = { Text("Extracted Document Notes & VIN") },
                    leadingIcon = { Icon(Icons.AutoMirrored.Filled.Notes, contentDescription = null, tint = IQYellow) },
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("input_review_notes"),
                    minLines = 2,
                    colors = outlinedFieldColors()
                )

                Spacer(modifier = Modifier.height(18.dp))
                HorizontalDivider(color = CharcoalBorder)
                Spacer(modifier = Modifier.height(14.dp))

                // Bottom Action Buttons
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.End,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    OutlinedButton(
                        onClick = onDismiss,
                        shape = RoundedCornerShape(8.dp),
                        border = BorderStroke(1.dp, CharcoalBorder),
                        modifier = Modifier.testTag("btn_cancel_review")
                    ) {
                        Text("Cancel", color = TextLightGray, fontSize = 12.sp)
                    }

                    Spacer(modifier = Modifier.width(10.dp))

                    Button(
                        onClick = {
                            val feeVal = feeStr.toDoubleOrNull() ?: 480.0
                            val verified = extractedInfo.copy(
                                customerName = name.trim(),
                                idNumber = idNumber.trim(),
                                companyName = companyName.trim(),
                                phone = phone.trim(),
                                email = email.trim(),
                                address = address.trim(),
                                vehicleRegistration = registration.trim(),
                                vehicleMakeModel = makeModel.trim(),
                                vehicleType = selectedVehicleType,
                                licenseDiscNumber = discNumber.trim(),
                                issueDate = issueDate.trim(),
                                expiryDate = expiryDate.trim(),
                                renewalFee = feeVal,
                                notes = notes.trim()
                            )
                            onConfirmAndPopulate(verified)
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = IQYellow),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.testTag("btn_confirm_populate_form")
                    ) {
                        Icon(
                            imageVector = Icons.Default.CheckCircle,
                            contentDescription = null,
                            tint = TextDark,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "Confirm & Populate Form",
                            color = TextDark,
                            fontWeight = FontWeight.Bold,
                            fontSize = 12.sp
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun outlinedFieldColors() = OutlinedTextFieldDefaults.colors(
    focusedContainerColor = CharcoalElevated,
    unfocusedContainerColor = CharcoalElevated,
    focusedBorderColor = IQYellow,
    unfocusedBorderColor = CharcoalBorder,
    cursorColor = IQYellow,
    focusedTextColor = TextWhite,
    unfocusedTextColor = TextWhite,
    focusedLabelColor = IQYellow,
    unfocusedLabelColor = TextMuted
)
