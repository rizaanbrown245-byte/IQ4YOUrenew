package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// IQ4YOU Dark Charcoal & Yellow Brand Palette
val CharcoalBlack = Color(0xFF0B0E14)
val CharcoalSurface = Color(0xFF151B23)
val CharcoalCard = Color(0xFF1C2330)
val CharcoalElevated = Color(0xFF242C3C)
val CharcoalBorder = Color(0xFF2D3748)

val IQYellow = Color(0xFFF5B700)
val IQYellowLight = Color(0xFFFFD147)
val IQYellowDark = Color(0xFFC79200)

val StatusRed = Color(0xFFEF4444)
val StatusOrange = Color(0xFFF97316)
val StatusYellow = Color(0xFFFACC15)
val StatusGreen = Color(0xFF22C55E)
val StatusBlue = Color(0xFF38BDF8)

val TextWhite = Color(0xFFFFFFFF)
val TextLightGray = Color(0xFFE2E8F0)
val TextMuted = Color(0xFF94A3B8)
val TextDark = Color(0xFF0F172A)

