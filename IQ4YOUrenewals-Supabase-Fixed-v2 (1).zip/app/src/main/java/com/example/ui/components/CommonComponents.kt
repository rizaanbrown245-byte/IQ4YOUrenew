package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.RenewalStatus
import com.example.ui.theme.CharcoalElevated
import com.example.ui.theme.IQYellow
import com.example.ui.theme.StatusGreen
import com.example.ui.theme.StatusOrange
import com.example.ui.theme.StatusRed
import com.example.ui.theme.StatusYellow
import com.example.ui.theme.TextDark
import com.example.ui.theme.TextLightGray
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextWhite

@Composable
fun BrandHeader(
    modifier: Modifier = Modifier,
    isOnline: Boolean = true
) {
    Row(
        modifier = modifier.padding(vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Surface(
                shape = RoundedCornerShape(8.dp),
                color = IQYellow,
                modifier = Modifier.padding(end = 8.dp)
            ) {
                Text(
                    text = "IQ4YOU",
                    color = TextDark,
                    fontWeight = FontWeight.Black,
                    fontSize = 13.sp,
                    letterSpacing = 0.5.sp,
                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                )
            }
            Text(
                text = "Renewals",
                color = TextWhite,
                fontWeight = FontWeight.Bold,
                fontSize = 20.sp
            )
        }

        // Connection status pill
        Surface(
            shape = RoundedCornerShape(16.dp),
            color = CharcoalElevated,
            modifier = Modifier.clip(RoundedCornerShape(16.dp))
        ) {
            Row(
                modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    modifier = Modifier
                        .size(8.dp)
                        .clip(CircleShape)
                        .background(if (isOnline) StatusGreen else StatusOrange)
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = if (isOnline) "ONLINE" else "OFFLINE",
                    color = if (isOnline) StatusGreen else StatusOrange,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold
                )
            }
        }
    }
}

@Composable
fun VehiclePlateBadge(
    plate: String,
    modifier: Modifier = Modifier
) {
    Surface(
        modifier = modifier
            .border(1.dp, Color(0xFF4A5568), RoundedCornerShape(6.dp)),
        shape = RoundedCornerShape(6.dp),
        color = Color(0xFF1A202C)
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(6.dp)
                    .clip(CircleShape)
                    .background(IQYellow)
            )
            Spacer(modifier = Modifier.width(6.dp))
            Text(
                text = plate.uppercase(),
                color = TextWhite,
                fontWeight = FontWeight.ExtraBold,
                fontSize = 13.sp,
                fontFamily = FontFamily.Monospace,
                letterSpacing = 0.8.sp
            )
        }
    }
}

@Composable
fun StatusBadge(
    status: RenewalStatus,
    daysLeft: Long? = null,
    modifier: Modifier = Modifier
) {
    val (bgColor, textColor, label) = when (status) {
        RenewalStatus.EXPIRED -> Triple(
            StatusRed.copy(alpha = 0.15f),
            StatusRed,
            if (daysLeft != null && daysLeft < 0) "EXPIRED (${-daysLeft}d ago)" else "EXPIRED"
        )
        RenewalStatus.DUE_TODAY -> Triple(
            StatusOrange.copy(alpha = 0.18f),
            StatusOrange,
            "DUE TODAY"
        )
        RenewalStatus.EXPIRING_SOON -> Triple(
            StatusYellow.copy(alpha = 0.18f),
            StatusYellow,
            if (daysLeft != null) "DUE IN ${daysLeft}d" else "EXPIRING SOON"
        )
        RenewalStatus.ACTIVE -> Triple(
            StatusGreen.copy(alpha = 0.15f),
            StatusGreen,
            if (daysLeft != null) "ACTIVE (${daysLeft}d)" else "ACTIVE"
        )
    }

    Surface(
        modifier = modifier,
        shape = RoundedCornerShape(8.dp),
        color = bgColor
    ) {
        Text(
            text = label,
            color = textColor,
            fontSize = 11.sp,
            fontWeight = FontWeight.Bold,
            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
        )
    }
}

@Composable
fun SectionHeader(
    title: String,
    badgeCount: Int? = null,
    actionText: String? = null,
    onActionClick: (() -> Unit)? = null,
    modifier: Modifier = Modifier
) {
    Row(
        modifier = modifier.padding(vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(
                text = title,
                style = MaterialTheme.typography.titleMedium,
                color = TextWhite,
                fontWeight = FontWeight.Bold
            )
            if (badgeCount != null) {
                Spacer(modifier = Modifier.width(8.dp))
                Surface(
                    shape = RoundedCornerShape(10.dp),
                    color = CharcoalElevated
                ) {
                    Text(
                        text = badgeCount.toString(),
                        color = TextLightGray,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                    )
                }
            }
        }

        if (actionText != null && onActionClick != null) {
            Text(
                text = actionText,
                color = IQYellow,
                fontSize = 12.sp,
                fontWeight = FontWeight.SemiBold
            )
        }
    }
}

@Composable
fun RbDigitalSolutionsFooter(
    modifier: Modifier = Modifier
) {
    Surface(
        modifier = modifier
            .fillMaxWidth()
            .border(
                width = 0.5.dp,
                color = Color(0xFF2D3748),
                shape = RoundedCornerShape(0.dp)
            ),
        color = Color(0xFF14171C)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 6.dp, horizontal = 16.dp),
            horizontalArrangement = Arrangement.Center,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "Made by ",
                fontSize = 11.sp,
                fontWeight = FontWeight.Normal,
                color = TextMuted
            )
            Text(
                text = "Rb digital solutions",
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                color = IQYellow,
                letterSpacing = 0.3.sp
            )
        }
    }
}

