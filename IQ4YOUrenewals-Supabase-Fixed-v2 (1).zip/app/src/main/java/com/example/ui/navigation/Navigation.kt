package com.example.ui.navigation

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material.icons.filled.Dashboard
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.People
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.outlined.CalendarMonth
import androidx.compose.material.icons.outlined.Dashboard
import androidx.compose.material.icons.outlined.Delete
import androidx.compose.material.icons.outlined.History
import androidx.compose.material.icons.outlined.People
import androidx.compose.material.icons.outlined.Settings
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.components.RbDigitalSolutionsFooter
import com.example.ui.screens.calendar.CalendarScreen
import com.example.ui.screens.customers.CustomersScreen
import com.example.ui.screens.dashboard.DashboardScreen
import com.example.ui.screens.history.RenewalHistoryScreen
import com.example.ui.screens.recyclebin.RecycleBinScreen
import com.example.ui.screens.settings.SettingsScreen
import com.example.ui.theme.CharcoalBlack
import com.example.ui.theme.CharcoalElevated
import com.example.ui.theme.CharcoalSurface
import com.example.ui.theme.IQYellow
import com.example.ui.theme.TextDark
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextWhite
import com.example.ui.viewmodel.RenewalsViewModel

enum class AppDestination(
    val label: String,
    val selectedIcon: ImageVector,
    val unselectedIcon: ImageVector,
    val tag: String,
    val showInBottomNav: Boolean = true
) {
    DASHBOARD(
        label = "Dashboard",
        selectedIcon = Icons.Filled.Dashboard,
        unselectedIcon = Icons.Outlined.Dashboard,
        tag = "nav_dashboard"
    ),
    CUSTOMERS(
        label = "Customers",
        selectedIcon = Icons.Filled.People,
        unselectedIcon = Icons.Outlined.People,
        tag = "nav_customers"
    ),
    CALENDAR(
        label = "Calendar",
        selectedIcon = Icons.Filled.CalendarMonth,
        unselectedIcon = Icons.Outlined.CalendarMonth,
        tag = "nav_calendar"
    ),
    HISTORY(
        label = "History",
        selectedIcon = Icons.Filled.History,
        unselectedIcon = Icons.Outlined.History,
        tag = "nav_history"
    ),
    SETTINGS(
        label = "Settings",
        selectedIcon = Icons.Filled.Settings,
        unselectedIcon = Icons.Outlined.Settings,
        tag = "nav_settings"
    ),
    RECYCLE_BIN(
        label = "Recycle Bin",
        selectedIcon = Icons.Filled.Delete,
        unselectedIcon = Icons.Outlined.Delete,
        tag = "nav_recycle_bin",
        showInBottomNav = false
    )
}

@Composable
fun MainAppNavigation(
    viewModel: RenewalsViewModel,
    modifier: Modifier = Modifier
) {
    var currentDestination by rememberSaveable { mutableStateOf(AppDestination.DASHBOARD) }

    // Native Android Back Navigation: return to Customers/Dashboard first before exiting
    BackHandler(enabled = currentDestination != AppDestination.DASHBOARD) {
        if (currentDestination == AppDestination.RECYCLE_BIN) {
            currentDestination = AppDestination.CUSTOMERS
        } else {
            currentDestination = AppDestination.DASHBOARD
        }
    }

    Scaffold(
        modifier = modifier
            .fillMaxSize()
            .statusBarsPadding(),
        containerColor = CharcoalBlack,
        bottomBar = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .navigationBarsPadding()
            ) {
                RbDigitalSolutionsFooter(
                    modifier = Modifier.testTag("footer_rb_digital_solutions")
                )
                NavigationBar(
                    modifier = Modifier.testTag("bottom_nav_bar"),
                    containerColor = CharcoalSurface,
                    tonalElevation = 8.dp
                ) {
                    AppDestination.values().filter { it.showInBottomNav }.forEach { destination ->
                        val isSelected = currentDestination == destination
                        NavigationBarItem(
                            selected = isSelected,
                            onClick = { currentDestination = destination },
                            icon = {
                                Icon(
                                    imageVector = if (isSelected) destination.selectedIcon else destination.unselectedIcon,
                                    contentDescription = destination.label,
                                    modifier = Modifier.size(22.dp)
                                )
                            },
                            label = {
                                Text(
                                    text = destination.label,
                                    fontSize = 11.sp,
                                    fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
                                )
                            },
                            colors = NavigationBarItemDefaults.colors(
                                selectedIconColor = TextDark,
                                selectedTextColor = IQYellow,
                                indicatorColor = IQYellow,
                                unselectedIconColor = TextMuted,
                                unselectedTextColor = TextMuted
                            ),
                            modifier = Modifier.testTag(destination.tag)
                        )
                    }
                }
            }
        }
    ) { innerPadding ->
        when (currentDestination) {
            AppDestination.DASHBOARD -> DashboardScreen(
                viewModel = viewModel,
                onNavigateToCustomers = { currentDestination = AppDestination.CUSTOMERS },
                onNavigateToHistory = { currentDestination = AppDestination.HISTORY },
                onNavigateToRecycleBin = { currentDestination = AppDestination.RECYCLE_BIN },
                modifier = Modifier.padding(innerPadding)
            )
            AppDestination.CUSTOMERS -> CustomersScreen(
                viewModel = viewModel,
                onNavigateToRecycleBin = { currentDestination = AppDestination.RECYCLE_BIN },
                modifier = Modifier.padding(innerPadding)
            )
            AppDestination.CALENDAR -> CalendarScreen(
                viewModel = viewModel,
                modifier = Modifier.padding(innerPadding)
            )
            AppDestination.HISTORY -> RenewalHistoryScreen(
                viewModel = viewModel,
                modifier = Modifier.padding(innerPadding)
            )
            AppDestination.SETTINGS -> SettingsScreen(
                viewModel = viewModel,
                onNavigateToRecycleBin = { currentDestination = AppDestination.RECYCLE_BIN },
                modifier = Modifier.padding(innerPadding)
            )
            AppDestination.RECYCLE_BIN -> RecycleBinScreen(
                viewModel = viewModel,
                onBack = { currentDestination = AppDestination.CUSTOMERS },
                modifier = Modifier.padding(innerPadding)
            )
        }
    }
}
