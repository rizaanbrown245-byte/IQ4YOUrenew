package com.example.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable

private val DarkColorScheme = darkColorScheme(
  primary = IQYellow,
  onPrimary = TextDark,
  primaryContainer = IQYellowDark,
  onPrimaryContainer = TextWhite,
  secondary = IQYellowLight,
  onSecondary = TextDark,
  secondaryContainer = CharcoalElevated,
  onSecondaryContainer = TextLightGray,
  tertiary = StatusBlue,
  onTertiary = TextDark,
  background = CharcoalBlack,
  onBackground = TextWhite,
  surface = CharcoalSurface,
  onSurface = TextWhite,
  surfaceVariant = CharcoalCard,
  onSurfaceVariant = TextMuted,
  outline = CharcoalBorder,
  error = StatusRed,
  onError = TextWhite,
)

@Composable
fun MyApplicationTheme(
  content: @Composable () -> Unit,
) {
  MaterialTheme(
    colorScheme = DarkColorScheme,
    typography = Typography,
    content = content
  )
}
