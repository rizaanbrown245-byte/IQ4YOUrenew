package com.example.ui.screens.settings

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.Android
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Cloud
import androidx.compose.material.icons.filled.CloudDone
import androidx.compose.material.icons.filled.CloudOff
import androidx.compose.material.icons.filled.Dataset
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Dns
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.ExpandLess
import androidx.compose.material.icons.filled.ExpandMore
import androidx.compose.material.icons.filled.NotificationsActive
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Restore
import androidx.compose.material.icons.filled.Schedule
import androidx.compose.material.icons.filled.Storage
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.ui.components.BrandHeader
import com.example.ui.components.SectionHeader
import com.example.ui.theme.CharcoalBorder
import com.example.ui.theme.CharcoalCard
import com.example.ui.theme.CharcoalElevated
import com.example.ui.theme.IQYellow
import com.example.ui.theme.StatusGreen
import com.example.ui.theme.StatusOrange
import com.example.ui.theme.TextDark
import com.example.ui.theme.TextLightGray
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextWhite
import com.example.ui.viewmodel.RenewalsViewModel

@Composable
fun SettingsScreen(
    viewModel: RenewalsViewModel,
    onNavigateToRecycleBin: () -> Unit = {},
    modifier: Modifier = Modifier
) {
    val settings by viewModel.appSettings.collectAsState()
    val backendTestResult by viewModel.backendTestStatus.collectAsState()
    val isTestingBackend by viewModel.isBackendTesting.collectAsState()
    val recycleBinCustomers by viewModel.recycleBinCustomers.collectAsState()
    val context = LocalContext.current

    var customEndpointUrl by remember(settings.backendUrl) { mutableStateOf(settings.backendUrl.ifBlank { com.example.BuildConfig.SUPABASE_URL }) }
    var reminderTimeInput by remember(settings.reminderTime) { mutableStateOf(settings.reminderTime) }
    var showDownloadGuide by remember { mutableStateOf(true) }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp)
            .testTag("settings_screen"),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            BrandHeader(isOnline = settings.backendConnected)
        }

        // Section: Backend Connection Status
        item {
            Text(
                text = "BACKEND & SYNC ARCHITECTURE",
                color = TextMuted,
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                letterSpacing = 0.8.sp
            )
        }

        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = CharcoalCard),
                border = BorderStroke(1.dp, CharcoalBorder)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                modifier = Modifier
                                    .size(36.dp)
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(StatusGreen.copy(alpha = 0.15f)),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Storage,
                                    contentDescription = null,
                                    tint = StatusGreen,
                                    modifier = Modifier.size(20.dp)
                                )
                            }
                            Spacer(modifier = Modifier.width(10.dp))
                            Column {
                                Text(
                                    text = "Local Storage Sync Engine",
                                    color = TextWhite,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 15.sp
                                )
                                Text(
                                    text = "Ready for Free-Tier Backend",
                                    color = IQYellow,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Medium
                                )
                            }
                        }

                        Surface(
                            shape = RoundedCornerShape(12.dp),
                            color = CharcoalElevated
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Box(
                                    modifier = Modifier
                                        .size(7.dp)
                                        .clip(CircleShape)
                                        .background(StatusGreen)
                                )
                                Spacer(modifier = Modifier.width(5.dp))
                                Text(
                                    text = "ACTIVE",
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = StatusGreen
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    Text(
                        text = "Emergent is completely disconnected. The app runs autonomously with clean interfaces, ready to plug into any free-tier database (Supabase, Firebase Free Tier, Cloudflare D1/Workers, or custom REST API).",
                        fontSize = 12.sp,
                        color = TextLightGray,
                        lineHeight = 16.sp
                    )

                    Spacer(modifier = Modifier.height(14.dp))

                    // Optional Free-Tier Backend Endpoint URL
                    OutlinedTextField(
                        value = customEndpointUrl,
                        onValueChange = {
                            customEndpointUrl = it
                            viewModel.updateSettings(settings.copy(backendUrl = it))
                        },
                        label = { Text("Supabase / Backend URL") },
                        placeholder = { Text("e.g. https://your-project.supabase.co") },
                        leadingIcon = {
                            Icon(Icons.Default.Dns, contentDescription = null, tint = IQYellow)
                        },
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("input_backend_url"),
                        singleLine = true,
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedContainerColor = CharcoalElevated,
                            unfocusedContainerColor = CharcoalElevated,
                            focusedBorderColor = IQYellow,
                            unfocusedBorderColor = CharcoalBorder,
                            cursorColor = IQYellow,
                            focusedTextColor = TextWhite,
                            unfocusedTextColor = TextWhite
                        )
                    )

                    Spacer(modifier = Modifier.height(12.dp))

                    // Test Connection & Retry Controls
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Button(
                            onClick = { viewModel.testBackendConnection() },
                            enabled = !isTestingBackend,
                            modifier = Modifier
                                .weight(1f)
                                .testTag("btn_test_connection"),
                            shape = RoundedCornerShape(10.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = IQYellow)
                        ) {
                            if (isTestingBackend) {
                                CircularProgressIndicator(
                                    color = TextDark,
                                    modifier = Modifier.size(16.dp),
                                    strokeWidth = 2.dp
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("Pinging...", color = TextDark, fontWeight = FontWeight.Bold)
                            } else {
                                Icon(
                                    imageVector = Icons.Default.Refresh,
                                    contentDescription = null,
                                    tint = TextDark,
                                    modifier = Modifier.size(16.dp)
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("Test Connection", color = TextDark, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                            }
                        }
                    }

                    // Display test result if present
                    if (backendTestResult != null) {
                        Spacer(modifier = Modifier.height(10.dp))
                        Surface(
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(8.dp),
                            color = CharcoalElevated,
                            border = BorderStroke(1.dp, CharcoalBorder)
                        ) {
                            Column(modifier = Modifier.padding(10.dp)) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(
                                        imageVector = Icons.Default.CheckCircle,
                                        contentDescription = null,
                                        tint = StatusGreen,
                                        modifier = Modifier.size(14.dp)
                                    )
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text(
                                        text = "Ping Success (${backendTestResult!!.latencyMs}ms)",
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = StatusGreen
                                    )
                                }
                                Text(
                                    text = backendTestResult!!.message,
                                    fontSize = 11.sp,
                                    color = TextLightGray
                                )
                            }
                        }
                    }
                }
            }
        }

        // Section: Automatic Reminders
        item {
            Text(
                text = "AUTOMATIC REMINDER RULES",
                color = TextMuted,
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                letterSpacing = 0.8.sp
            )
        }

        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = CharcoalCard),
                border = BorderStroke(1.dp, CharcoalBorder)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    // Master toggle: Automatic Reminders
                    SettingToggleRow(
                        title = "Automatic Reminders",
                        description = "Enable scheduled license renewal notifications",
                        checked = settings.automaticReminders,
                        onCheckedChange = {
                            viewModel.updateSettings(settings.copy(automaticReminders = it))
                        }
                    )

                    HorizontalDivider(
                        color = CharcoalBorder,
                        modifier = Modifier.padding(vertical = 12.dp)
                    )

                    // Rule 1: 30 days before expiry
                    SettingToggleRow(
                        title = "30 Days Before Expiry",
                        description = "Send initial notification 1 month prior",
                        checked = settings.remind30DaysBefore,
                        enabled = settings.automaticReminders,
                        onCheckedChange = {
                            viewModel.updateSettings(settings.copy(remind30DaysBefore = it))
                        }
                    )

                    HorizontalDivider(
                        color = CharcoalBorder,
                        modifier = Modifier.padding(vertical = 12.dp)
                    )

                    // Rule 2: 7 days before expiry
                    SettingToggleRow(
                        title = "7 Days Before Expiry",
                        description = "Urgent reminder 1 week before expiry date",
                        checked = settings.remind7DaysBefore,
                        enabled = settings.automaticReminders,
                        onCheckedChange = {
                            viewModel.updateSettings(settings.copy(remind7DaysBefore = it))
                        }
                    )

                    HorizontalDivider(
                        color = CharcoalBorder,
                        modifier = Modifier.padding(vertical = 12.dp)
                    )

                    // Rule 3: Consolidated reminders per contact
                    SettingToggleRow(
                        title = "Consolidated Reminders",
                        description = "Group multiple fleet vehicles into one message per contact",
                        checked = settings.consolidatePerContact,
                        enabled = settings.automaticReminders,
                        onCheckedChange = {
                            viewModel.updateSettings(settings.copy(consolidatePerContact = it))
                        }
                    )

                    HorizontalDivider(
                        color = CharcoalBorder,
                        modifier = Modifier.padding(vertical = 12.dp)
                    )

                    // Reminder Time
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "Daily Reminder Dispatch Time",
                                color = TextWhite,
                                fontWeight = FontWeight.Bold,
                                fontSize = 14.sp
                            )
                            Text(
                                text = "Standard business notification schedule",
                                color = TextMuted,
                                fontSize = 11.sp
                            )
                        }

                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = CharcoalElevated,
                            border = BorderStroke(1.dp, CharcoalBorder)
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Schedule,
                                    contentDescription = null,
                                    tint = IQYellow,
                                    modifier = Modifier.size(14.dp)
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = settings.reminderTime,
                                    color = TextWhite,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 13.sp
                                )
                            }
                        }
                    }
                }
            }
        }

        // Section: Testing & Administrative Controls
        item {
            Text(
                text = "TESTING & DATA ACTIONS",
                color = TextMuted,
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                letterSpacing = 0.8.sp
            )
        }

        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = CharcoalCard),
                border = BorderStroke(1.dp, CharcoalBorder)
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    // Test reminder button
                    Button(
                        onClick = { viewModel.sendTestReminder(context) },
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("btn_send_test_reminder"),
                        shape = RoundedCornerShape(10.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = CharcoalElevated),
                        border = BorderStroke(1.dp, IQYellow)
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.Send,
                            contentDescription = null,
                            tint = IQYellow,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "Send Test Renewal Reminder",
                            color = IQYellow,
                            fontWeight = FontWeight.Bold,
                            fontSize = 13.sp
                        )
                    }

                    // Recycle Bin button
                    Button(
                        onClick = onNavigateToRecycleBin,
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("btn_settings_recycle_bin"),
                        shape = RoundedCornerShape(10.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = CharcoalElevated),
                        border = BorderStroke(1.dp, CharcoalBorder)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Delete,
                            contentDescription = null,
                            tint = IQYellow,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "Recycle Bin (${recycleBinCustomers.size} deleted)",
                            color = TextWhite,
                            fontWeight = FontWeight.Medium,
                            fontSize = 13.sp
                        )
                    }

                    // Reset Data button
                    OutlinedButton(
                        onClick = { viewModel.resetData(context) },
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("btn_reset_sample_data"),
                        shape = RoundedCornerShape(10.dp),
                        border = BorderStroke(1.dp, CharcoalBorder)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Restore,
                            contentDescription = null,
                            tint = TextLightGray,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "Restore Initial Vehicle Records",
                            color = TextLightGray,
                            fontSize = 13.sp
                        )
                    }
                }
            }
        }

        // Section: APK Download & Mobile Installation Guide
        item {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("card_apk_install_guide"),
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = CharcoalCard),
                border = BorderStroke(1.dp, IQYellow.copy(alpha = 0.5f))
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { showDownloadGuide = !showDownloadGuide },
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.weight(1f)
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(36.dp)
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(IQYellow.copy(alpha = 0.2f)),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Android,
                                    contentDescription = null,
                                    tint = IQYellow,
                                    modifier = Modifier.size(22.dp)
                                )
                            }
                            Spacer(modifier = Modifier.width(12.dp))
                            Column {
                                Text(
                                    text = "Download & Install APK Guide",
                                    color = TextWhite,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 15.sp
                                )
                                Text(
                                    text = "Step-by-step visual instructions",
                                    color = TextMuted,
                                    fontSize = 11.sp
                                )
                            }
                        }

                        Icon(
                            imageVector = if (showDownloadGuide) Icons.Default.ExpandLess else Icons.Default.ExpandMore,
                            contentDescription = if (showDownloadGuide) "Collapse" else "Expand",
                            tint = IQYellow,
                            modifier = Modifier.size(24.dp)
                        )
                    }

                    if (showDownloadGuide) {
                        Spacer(modifier = Modifier.height(14.dp))
                        HorizontalDivider(color = CharcoalBorder)
                        Spacer(modifier = Modifier.height(14.dp))

                        // Step 1
                        Text(
                            text = "STEP 1: DOWNLOAD THE APK",
                            color = IQYellow,
                            fontWeight = FontWeight.Bold,
                            fontSize = 11.sp,
                            letterSpacing = 0.5.sp
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "Download app-debug.apk from the file tree at app/build/outputs/apk/debug/ or click Export APK in the top menu.",
                            color = TextLightGray,
                            fontSize = 12.sp,
                            lineHeight = 16.sp
                        )
                        Spacer(modifier = Modifier.height(10.dp))
                        Image(
                            painter = painterResource(id = R.drawable.guide_download_apk),
                            contentDescription = "APK Download Guide Diagram",
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(10.dp))
                                .border(BorderStroke(1.dp, CharcoalBorder))
                        )

                        Spacer(modifier = Modifier.height(18.dp))

                        // Step 2 & 3
                        Text(
                            text = "STEP 2 & 3: ALLOW & INSTALL ON PHONE",
                            color = IQYellow,
                            fontWeight = FontWeight.Bold,
                            fontSize = 11.sp,
                            letterSpacing = 0.5.sp
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "Open the downloaded APK on your Android phone. When prompted by Android security, toggle 'Allow from this source', then tap 'Install'.",
                            color = TextLightGray,
                            fontSize = 12.sp,
                            lineHeight = 16.sp
                        )
                        Spacer(modifier = Modifier.height(10.dp))
                        Image(
                            painter = painterResource(id = R.drawable.guide_install_prompt),
                            contentDescription = "Android Phone Install Prompt Guide",
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(10.dp))
                                .border(BorderStroke(1.dp, CharcoalBorder))
                        )
                    }
                }
            }
        }

        // About & Branding footer
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = CharcoalElevated)
            ) {
                Column(
                    modifier = Modifier.padding(14.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text(
                        text = "IQ4YOU Renewals v2.0",
                        color = IQYellow,
                        fontWeight = FontWeight.Bold,
                        fontSize = 13.sp
                    )
                    Text(
                        text = "Single-Client Vehicle & Roadworthy Renewal Suite",
                        color = TextMuted,
                        fontSize = 11.sp
                    )
                    Text(
                        text = "Standalone Architecture • Free-Tier Ready",
                        color = TextMuted,
                        fontSize = 10.sp
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    HorizontalDivider(
                        color = CharcoalBorder,
                        modifier = Modifier.padding(horizontal = 24.dp)
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Row(
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "Made by ",
                            color = TextLightGray,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Medium
                        )
                        Text(
                            text = "Rb digital solutions",
                            color = IQYellow,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            letterSpacing = 0.3.sp
                        )
                    }
                }
            }
        }

        item {
            Spacer(modifier = Modifier.height(24.dp))
        }
    }
}

@Composable
private fun SettingToggleRow(
    title: String,
    description: String,
    checked: Boolean,
    enabled: Boolean = true,
    onCheckedChange: (Boolean) -> Unit
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(modifier = Modifier.weight(1f).padding(end = 12.dp)) {
            Text(
                text = title,
                color = if (enabled) TextWhite else TextMuted,
                fontWeight = FontWeight.Bold,
                fontSize = 14.sp
            )
            Text(
                text = description,
                color = TextMuted,
                fontSize = 11.sp
            )
        }

        Switch(
            checked = checked,
            onCheckedChange = onCheckedChange,
            enabled = enabled,
            colors = SwitchDefaults.colors(
                checkedThumbColor = TextDark,
                checkedTrackColor = IQYellow,
                uncheckedThumbColor = TextLightGray,
                uncheckedTrackColor = CharcoalElevated
            )
        )
    }
}
