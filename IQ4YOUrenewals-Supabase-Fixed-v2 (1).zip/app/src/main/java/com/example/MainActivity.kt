package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import com.example.data.local.IQDatabase
import com.example.data.repository.RoomRenewalRepository
import com.example.data.service.RenewalReminderScheduler
import com.example.ui.navigation.MainAppNavigation
import com.example.ui.theme.MyApplicationTheme
import com.example.ui.viewmodel.RenewalsViewModel

class MainActivity : ComponentActivity() {

    private val viewModel: RenewalsViewModel by viewModels {
        val database = IQDatabase.getDatabase(applicationContext)
        val repository = RoomRenewalRepository(database.iqDao(), applicationContext)
        RenewalsViewModel.Factory(repository)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        // Initialize daily background reminder checks
        RenewalReminderScheduler.scheduleDailyCheck(applicationContext)
        setContent {
            MyApplicationTheme {
                MainAppNavigation(viewModel = viewModel)
            }
        }
    }
}

