package com.example.ui.screens.customers

import android.content.Context
import android.graphics.Bitmap
import android.net.Uri
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.result.launch
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AttachFile
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Badge
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material.icons.filled.CameraAlt
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.DirectionsCar
import androidx.compose.material.icons.filled.Email
import androidx.compose.material.icons.filled.ExpandLess
import androidx.compose.material.icons.filled.ExpandMore
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Phone
import androidx.compose.material.icons.filled.PhotoLibrary
import androidx.compose.material.icons.filled.PictureAsPdf
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CheckboxDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardCapitalization
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import coil.compose.AsyncImage
import com.example.data.model.AttachedDocument
import com.example.data.model.Customer
import com.example.data.model.ExtractedRenewalInfo
import com.example.data.model.toJsonString
import com.example.data.service.GeminiDocumentAnalyzer
import com.example.data.util.LicenseDiscParser
import com.example.ui.theme.CharcoalBorder
import com.example.ui.theme.CharcoalCard
import com.example.ui.theme.CharcoalElevated
import com.example.ui.theme.IQYellow
import com.example.ui.theme.StatusGreen
import com.example.ui.theme.StatusRed
import com.example.ui.theme.TextDark
import com.example.ui.theme.TextLightGray
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextWhite
import com.example.ui.viewmodel.ScannedLicenseData
import kotlinx.coroutines.launch
import java.time.LocalDate
import java.util.UUID

@Composable
fun AddEditCustomerDialog(
    initialCustomer: Customer? = null,
    prefillRegistration: String? = null,
    prefillMakeModel: String? = null,
    prefillType: String? = null,
    prefillDiscNumber: String? = null,
    prefillExpiryDate: String? = null,
    prefillName: String? = null,
    prefillPhone: String? = null,
    prefillFee: Double? = null,
    onDismiss: () -> Unit,
    onSaveCustomer: (Customer) -> Unit
) {
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()

    // Form field states
    var name by remember {
        mutableStateOf(initialCustomer?.name ?: prefillName ?: "")
    }
    var phone by remember {
        mutableStateOf(initialCustomer?.phone ?: prefillPhone ?: "+27 ")
    }
    var email by remember {
        mutableStateOf(initialCustomer?.email ?: "")
    }
    var registration by remember {
        mutableStateOf(initialCustomer?.vehicleRegistration ?: prefillRegistration ?: "")
    }
    var makeModel by remember {
        mutableStateOf(initialCustomer?.vehicleMakeModel ?: prefillMakeModel ?: "")
    }
    var discNumber by remember {
        mutableStateOf(initialCustomer?.licenseDiscNumber ?: prefillDiscNumber ?: "")
    }
    var expiryDate by remember {
        mutableStateOf(
            initialCustomer?.expiryDate
                ?: prefillExpiryDate
                ?: "2026-08-31"
        )
    }
    var renewalFeeStr by remember {
        mutableStateOf(
            initialCustomer?.renewalFee?.toString()
                ?: prefillFee?.toString()
                ?: "480.0"
        )
    }
    var notes by remember {
        mutableStateOf(initialCustomer?.notes ?: "")
    }
    var idNumber by remember {
        mutableStateOf(initialCustomer?.idNumber ?: "")
    }
    var companyName by remember {
        mutableStateOf(initialCustomer?.companyName ?: "")
    }
    var address by remember {
        mutableStateOf(initialCustomer?.address ?: "")
    }
    var issueDate by remember {
        mutableStateOf(initialCustomer?.issueDate ?: "")
    }
    var reminderEnabled by remember {
        mutableStateOf(initialCustomer?.reminderEnabled ?: true)
    }
    var remind90Days by remember { mutableStateOf(initialCustomer?.remind90Days ?: true) }
    var remind60Days by remember { mutableStateOf(initialCustomer?.remind60Days ?: true) }
    var remind30Days by remember { mutableStateOf(initialCustomer?.remind30Days ?: true) }
    var remind14Days by remember { mutableStateOf(initialCustomer?.remind14Days ?: true) }
    var remind7Days by remember { mutableStateOf(initialCustomer?.remind7Days ?: true) }
    var remind1Day by remember { mutableStateOf(initialCustomer?.remind1Day ?: true) }

    val vehicleTypes = listOf("Motor vehicle", "Sedan", "SUV", "Bakkie / Pickup", "Commercial Truck", "Commercial Van", "Motorcycle")
    var selectedVehicleType by remember {
        mutableStateOf(
            initialCustomer?.vehicleType ?: prefillType ?: vehicleTypes[0]
        )
    }

    // License Photo & Document States
    var licensePhotoUri by remember {
        mutableStateOf(initialCustomer?.licensePhotoUri ?: "")
    }
    var licenseBitmap by remember { mutableStateOf<Bitmap?>(null) }
    val attachedDocuments = remember {
        mutableStateListOf<AttachedDocument>().apply {
            initialCustomer?.let { addAll(it.getAttachedDocuments()) }
        }
    }

    var isAnalyzing by remember { mutableStateOf(false) }
    var autoFilledBanner by remember { mutableStateOf<String?>(null) }
    var errorMessage by remember { mutableStateOf<String?>(null) }
    var showAdditionalDetails by remember { mutableStateOf(false) }
    var previewDocument by remember { mutableStateOf<AttachedDocument?>(null) }

    // Helper: Apply extracted data from disc
    fun applyExtractedInfo(extracted: ExtractedRenewalInfo, photoUriString: String? = null) {
        if (extracted.customerName.isNotBlank() && (name.isBlank() || name == "New Customer")) {
            name = extracted.customerName
        }
        if (extracted.phone.isNotBlank() && (phone.isBlank() || phone == "+27 ")) {
            phone = extracted.phone
        }
        if (extracted.email.isNotBlank() && email.isBlank()) {
            email = extracted.email
        }
        if (extracted.vehicleRegistration.isNotBlank()) {
            registration = extracted.vehicleRegistration
        }
        if (extracted.vehicleMakeModel.isNotBlank()) {
            makeModel = extracted.vehicleMakeModel
        }
        if (extracted.vehicleType.isNotBlank()) {
            selectedVehicleType = extracted.vehicleType
        }
        if (extracted.licenseDiscNumber.isNotBlank()) {
            discNumber = extracted.licenseDiscNumber
        }
        if (extracted.expiryDate.isNotBlank()) {
            expiryDate = extracted.expiryDate
        }
        if (extracted.issueDate.isNotBlank()) {
            issueDate = extracted.issueDate
        }
        if (extracted.renewalFee > 0.0) {
            renewalFeeStr = extracted.renewalFee.toString()
        }
        if (extracted.notes.isNotBlank()) {
            notes = if (notes.isBlank()) extracted.notes else "$notes\n${extracted.notes}"
        }
        if (photoUriString != null && photoUriString.isNotBlank()) {
            licensePhotoUri = photoUriString
            val exists = attachedDocuments.any { it.uri == photoUriString || it.name.contains("License Disc", ignoreCase = true) }
            if (!exists) {
                attachedDocuments.add(
                    0,
                    AttachedDocument(
                        id = UUID.randomUUID().toString(),
                        name = "License Disc Photo (${extracted.vehicleRegistration})",
                        type = "License Disc",
                        uri = photoUriString,
                        mimeType = "image/jpeg",
                        addedDate = LocalDate.now().toString(),
                        fileSize = "Photo"
                    )
                )
            }
        }
        autoFilledBanner = "✓ Auto-filled: ${extracted.vehicleRegistration} • ${extracted.vehicleMakeModel} • Expires $expiryDate"
    }

    // Camera launcher
    val cameraLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.TakePicturePreview()
    ) { bitmap: Bitmap? ->
        if (bitmap != null) {
            licenseBitmap = bitmap
            isAnalyzing = true
            errorMessage = null
            coroutineScope.launch {
                val savedUri = GeminiDocumentAnalyzer.saveBitmapToInternalStorage(context, bitmap, "license_disc_${System.currentTimeMillis()}.jpg")
                val uriStr = savedUri?.toString() ?: ""
                val result = GeminiDocumentAnalyzer.analyzeBitmap(context, bitmap, "license_disc.jpg")
                isAnalyzing = false
                result.fold(
                    onSuccess = { extracted ->
                        applyExtractedInfo(extracted, uriStr)
                    },
                    onFailure = { err ->
                        errorMessage = "Disc analysis: ${err.message}"
                    }
                )
            }
        }
    }

    // Gallery launcher for license disc photo
    val galleryLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri: Uri? ->
        if (uri != null) {
            isAnalyzing = true
            errorMessage = null
            coroutineScope.launch {
                val savedUri = GeminiDocumentAnalyzer.copyUriToInternalStorage(context, uri, "license_disc.jpg")
                val uriStr = savedUri?.toString() ?: uri.toString()
                val result = GeminiDocumentAnalyzer.analyzeDocument(context, uri, "license_disc.jpg")
                isAnalyzing = false
                result.fold(
                    onSuccess = { extracted ->
                        applyExtractedInfo(extracted, uriStr)
                    },
                    onFailure = { err ->
                        errorMessage = "Disc analysis: ${err.message}"
                    }
                )
            }
        }
    }

    // Document attachment file picker (PDF or Image)
    val documentPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetContent()
    ) { uri: Uri? ->
        if (uri != null) {
            coroutineScope.launch {
                val mimeType = context.contentResolver.getType(uri) ?: "application/octet-stream"
                val isPdf = mimeType.contains("pdf", ignoreCase = true)
                val ext = if (isPdf) "pdf" else "jpg"
                val savedUri = GeminiDocumentAnalyzer.copyUriToInternalStorage(context, uri, "attached_doc.$ext")
                val finalUri = savedUri?.toString() ?: uri.toString()
                val docName = if (isPdf) "Roadworthy / Certificate (${LocalDate.now()})" else "Attached Image Document (${LocalDate.now()})"
                attachedDocuments.add(
                    AttachedDocument(
                        id = UUID.randomUUID().toString(),
                        name = docName,
                        type = if (isPdf) "PDF Document" else "Image Document",
                        uri = finalUri,
                        mimeType = mimeType,
                        addedDate = LocalDate.now().toString(),
                        fileSize = if (isPdf) "PDF File" else "Image File"
                    )
                )
                Toast.makeText(context, "Document attached successfully", Toast.LENGTH_SHORT).show()
            }
        }
    }

    Dialog(onDismissRequest = onDismiss) {
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 10.dp),
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = CharcoalCard),
            border = BorderStroke(1.dp, CharcoalBorder)
        ) {
            Column(
                modifier = Modifier
                    .padding(20.dp)
                    .verticalScroll(rememberScrollState())
            ) {
                // Header: Title, Subtitle, and Close Button
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = if (initialCustomer != null) "Edit customer" else "Add customer",
                            style = MaterialTheme.typography.titleLarge,
                            color = TextWhite,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "Capture a renewal record",
                            fontSize = 12.sp,
                            color = TextMuted
                        )
                    }

                    IconButton(
                        onClick = onDismiss,
                        modifier = Modifier.size(32.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Close,
                            contentDescription = "Close",
                            tint = TextMuted
                        )
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                // LICENSE PHOTO SECTION
                Surface(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp),
                    color = CharcoalElevated,
                    border = BorderStroke(1.dp, CharcoalBorder)
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Surface(
                                shape = RoundedCornerShape(6.dp),
                                color = IQYellow
                            ) {
                                Icon(
                                    imageVector = Icons.Default.CameraAlt,
                                    contentDescription = null,
                                    tint = TextDark,
                                    modifier = Modifier
                                        .padding(4.dp)
                                        .size(16.dp)
                                )
                            }
                            Spacer(modifier = Modifier.width(8.dp))
                            Column {
                                Text(
                                    text = "License photo",
                                    color = TextWhite,
                                    fontSize = 14.sp,
                                    fontWeight = FontWeight.Bold
                                )
                                Text(
                                    text = "Snap the disc first — we'll auto-fill the fields below.",
                                    color = TextMuted,
                                    fontSize = 11.sp
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(12.dp))

                        // Camera & Gallery Buttons side by side
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            OutlinedButton(
                                onClick = { cameraLauncher.launch() },
                                modifier = Modifier
                                    .weight(1f)
                                    .height(44.dp)
                                    .testTag("btn_license_camera"),
                                shape = RoundedCornerShape(8.dp),
                                border = BorderStroke(1.dp, IQYellow.copy(alpha = 0.6f)),
                                colors = ButtonDefaults.outlinedButtonColors(
                                    containerColor = CharcoalCard
                                )
                            ) {
                                Icon(
                                    imageVector = Icons.Default.CameraAlt,
                                    contentDescription = null,
                                    tint = IQYellow,
                                    modifier = Modifier.size(18.dp)
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = "Camera",
                                    color = TextWhite,
                                    fontWeight = FontWeight.SemiBold,
                                    fontSize = 13.sp
                                )
                            }

                            OutlinedButton(
                                onClick = {
                                    galleryLauncher.launch(
                                        PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                                    )
                                },
                                modifier = Modifier
                                    .weight(1f)
                                    .height(44.dp)
                                    .testTag("btn_license_gallery"),
                                shape = RoundedCornerShape(8.dp),
                                border = BorderStroke(1.dp, CharcoalBorder),
                                colors = ButtonDefaults.outlinedButtonColors(
                                    containerColor = CharcoalCard
                                )
                            ) {
                                Icon(
                                    imageVector = Icons.Default.PhotoLibrary,
                                    contentDescription = null,
                                    tint = TextLightGray,
                                    modifier = Modifier.size(18.dp)
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = "Gallery",
                                    color = TextWhite,
                                    fontWeight = FontWeight.SemiBold,
                                    fontSize = 13.sp
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(8.dp))

                        // 1-Tap Quick Sample Disc Button (User's exact Toyota Hatchback KBF624EC)
                        Surface(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable {
                                    val disc = LicenseDiscParser.getSampleDiscs().first()
                                    registration = disc.vehiclePlate
                                    makeModel = disc.vehicleMakeModel
                                    selectedVehicleType = "Motor vehicle"
                                    discNumber = disc.licenseDiscNumber
                                    expiryDate = disc.expiryDate
                                    renewalFeeStr = disc.renewalFee.toString()
                                    if (name.isBlank() || name == "New Customer") name = disc.customerName
                                    if (phone.isBlank() || phone == "+27 ") phone = disc.phone
                                    issueDate = "2022-09-17"
                                    notes = "Toyota Hatch back • VIN: AHT54ZEC003027837 • Engine: 4ZZE219217 • Register: DHL564S • Disc: 1037020D7FNM • Tare: 1101kg, GVM: 1630kg"
                                    autoFilledBanner = "✓ Auto-filled from South African License Disc: KBF624EC (Toyota Hatch back • Expires 2026-08-31)"
                                    if (!attachedDocuments.any { it.name.contains("KBF624EC") }) {
                                        attachedDocuments.add(
                                            0,
                                            AttachedDocument(
                                                id = UUID.randomUUID().toString(),
                                                name = "License Disc (KBF624EC • Toyota Hatch)",
                                                type = "License Disc",
                                                uri = "sample_kbf624ec_disc.jpg",
                                                mimeType = "image/jpeg",
                                                addedDate = LocalDate.now().toString(),
                                                fileSize = "Sample Disc"
                                            )
                                        )
                                    }
                                    Toast.makeText(context, "Auto-filled with Toyota Hatch (KBF624EC)", Toast.LENGTH_SHORT).show()
                                }
                                .testTag("btn_sample_toyota_disc"),
                            shape = RoundedCornerShape(8.dp),
                            color = CharcoalCard,
                            border = BorderStroke(1.dp, IQYellow.copy(alpha = 0.35f))
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 7.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(
                                        imageVector = Icons.Default.AutoAwesome,
                                        contentDescription = null,
                                        tint = IQYellow,
                                        modifier = Modifier.size(15.dp)
                                    )
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text(
                                        text = "Read Example Disc (Toyota Hatch • KBF624EC)",
                                        color = IQYellow,
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                                Text(
                                    text = "Auto-Fill",
                                    color = TextWhite,
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.SemiBold
                                )
                            }
                        }

                        // Progress Indicator during analysis
                        if (isAnalyzing) {
                            Spacer(modifier = Modifier.height(10.dp))
                            LinearProgressIndicator(
                                modifier = Modifier.fillMaxWidth(),
                                color = IQYellow,
                                trackColor = CharcoalBorder
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = "Analyzing license disc with Gemini AI...",
                                color = IQYellow,
                                fontSize = 11.sp
                            )
                        }

                        // Preview of captured photo
                        if (licenseBitmap != null || licensePhotoUri.isNotBlank()) {
                            Spacer(modifier = Modifier.height(10.dp))
                            Surface(
                                modifier = Modifier.fillMaxWidth(),
                                shape = RoundedCornerShape(8.dp),
                                color = CharcoalCard,
                                border = BorderStroke(1.dp, StatusGreen.copy(alpha = 0.5f))
                            ) {
                                Row(
                                    modifier = Modifier.padding(8.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Box(
                                        modifier = Modifier
                                            .size(54.dp)
                                            .clip(RoundedCornerShape(6.dp))
                                            .background(CharcoalBorder),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        if (licenseBitmap != null) {
                                            Image(
                                                bitmap = licenseBitmap!!.asImageBitmap(),
                                                contentDescription = "Disc Photo",
                                                modifier = Modifier.fillMaxSize(),
                                                contentScale = ContentScale.Crop
                                            )
                                        } else if (licensePhotoUri.isNotBlank()) {
                                            AsyncImage(
                                                model = licensePhotoUri,
                                                contentDescription = "Disc Photo",
                                                modifier = Modifier.fillMaxSize(),
                                                contentScale = ContentScale.Crop
                                            )
                                        }
                                    }

                                    Spacer(modifier = Modifier.width(10.dp))

                                    Column(modifier = Modifier.weight(1f)) {
                                        Row(verticalAlignment = Alignment.CenterVertically) {
                                            Icon(
                                                imageVector = Icons.Default.CheckCircle,
                                                contentDescription = null,
                                                tint = StatusGreen,
                                                modifier = Modifier.size(14.dp)
                                            )
                                            Spacer(modifier = Modifier.width(4.dp))
                                            Text(
                                                text = "License photo captured",
                                                color = StatusGreen,
                                                fontSize = 12.sp,
                                                fontWeight = FontWeight.Bold
                                            )
                                        }
                                        Text(
                                            text = if (registration.isNotBlank()) "$registration • $selectedVehicleType" else "Disc image attached",
                                            color = TextLightGray,
                                            fontSize = 11.sp
                                        )
                                    }

                                    IconButton(
                                        onClick = {
                                            licenseBitmap = null
                                            licensePhotoUri = ""
                                            attachedDocuments.removeAll { it.type == "License Disc" }
                                        },
                                        modifier = Modifier.size(28.dp)
                                    ) {
                                        Icon(
                                            imageVector = Icons.Default.Delete,
                                            contentDescription = "Remove photo",
                                            tint = StatusRed,
                                            modifier = Modifier.size(16.dp)
                                        )
                                    }
                                }
                            }
                        }
                    }
                }

                // Success Banner if Auto-filled
                if (autoFilledBanner != null) {
                    Spacer(modifier = Modifier.height(10.dp))
                    Surface(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(8.dp),
                        color = StatusGreen.copy(alpha = 0.12f),
                        border = BorderStroke(1.dp, StatusGreen.copy(alpha = 0.6f))
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                imageVector = Icons.Default.CheckCircle,
                                contentDescription = null,
                                tint = StatusGreen,
                                modifier = Modifier.size(15.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = autoFilledBanner!!,
                                color = StatusGreen,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Medium
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                // FORM FIELDS SECTION
                // 1. Name *
                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it },
                    label = { Text("Name *") },
                    placeholder = { Text("Full name") },
                    trailingIcon = {
                        Icon(
                            imageVector = Icons.Default.Person,
                            contentDescription = "Person",
                            tint = TextMuted
                        )
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("input_customer_name"),
                    singleLine = true,
                    colors = customTextFieldColors()
                )

                Spacer(modifier = Modifier.height(10.dp))

                // 2. Phone
                OutlinedTextField(
                    value = phone,
                    onValueChange = { phone = it },
                    label = { Text("Phone") },
                    placeholder = { Text("+27 82 000 0000") },
                    trailingIcon = {
                        Icon(
                            imageVector = Icons.Default.Phone,
                            contentDescription = "Phone",
                            tint = TextMuted
                        )
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("input_customer_phone"),
                    singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                    colors = customTextFieldColors()
                )

                Spacer(modifier = Modifier.height(10.dp))

                // 3. Email
                OutlinedTextField(
                    value = email,
                    onValueChange = { email = it },
                    label = { Text("Email") },
                    placeholder = { Text("customer@example.com") },
                    trailingIcon = {
                        Icon(
                            imageVector = Icons.Default.Email,
                            contentDescription = "Email",
                            tint = TextMuted
                        )
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("input_customer_email"),
                    singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Email),
                    colors = customTextFieldColors()
                )

                Spacer(modifier = Modifier.height(10.dp))

                // 4. License type
                OutlinedTextField(
                    value = selectedVehicleType,
                    onValueChange = { selectedVehicleType = it },
                    label = { Text("License type") },
                    placeholder = { Text("Motor vehicle / motorcycle / other") },
                    trailingIcon = {
                        Icon(
                            imageVector = Icons.Default.DirectionsCar,
                            contentDescription = "Vehicle",
                            tint = TextMuted
                        )
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("input_license_type"),
                    singleLine = true,
                    colors = customTextFieldColors()
                )

                Spacer(modifier = Modifier.height(6.dp))

                // Quick chips for License Type
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    vehicleTypes.forEach { type ->
                        val isSelected = selectedVehicleType.equals(type, ignoreCase = true)
                        FilterChip(
                            selected = isSelected,
                            onClick = { selectedVehicleType = type },
                            label = { Text(type, fontSize = 11.sp) },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = IQYellow,
                                selectedLabelColor = TextDark,
                                containerColor = CharcoalElevated,
                                labelColor = TextLightGray
                            ),
                            border = BorderStroke(1.dp, if (isSelected) IQYellow else CharcoalBorder)
                        )
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                // 5. Plate number
                OutlinedTextField(
                    value = registration,
                    onValueChange = { registration = it.uppercase() },
                    label = { Text("Plate number") },
                    placeholder = { Text("ABC 123 GP") },
                    trailingIcon = {
                        Icon(
                            imageVector = Icons.Default.Badge,
                            contentDescription = "Plate",
                            tint = IQYellow
                        )
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("input_vehicle_plate"),
                    singleLine = true,
                    keyboardOptions = KeyboardOptions(capitalization = KeyboardCapitalization.Characters),
                    colors = customTextFieldColors()
                )

                Spacer(modifier = Modifier.height(10.dp))

                // 6. Expiration date
                OutlinedTextField(
                    value = expiryDate,
                    onValueChange = { expiryDate = it },
                    label = { Text("Expiration date") },
                    placeholder = { Text("YYYY-MM-DD") },
                    trailingIcon = {
                        Icon(
                            imageVector = Icons.Default.CalendarMonth,
                            contentDescription = "Calendar",
                            tint = TextMuted
                        )
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("input_expiry_date"),
                    singleLine = true,
                    colors = customTextFieldColors()
                )

                Spacer(modifier = Modifier.height(6.dp))

                // Quick date presets
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    val today = LocalDate.now()
                    QuickDateButton("2026-08-31") { expiryDate = "2026-08-31" }
                    QuickDateButton("+30 Days") { expiryDate = today.plusDays(30).toString() }
                    QuickDateButton("+60 Days") { expiryDate = today.plusDays(60).toString() }
                    QuickDateButton("+1 Year") { expiryDate = today.plusYears(1).toString() }
                }

                Spacer(modifier = Modifier.height(10.dp))

                // 7. Notes
                OutlinedTextField(
                    value = notes,
                    onValueChange = { notes = it },
                    label = { Text("Notes") },
                    placeholder = { Text("Anything useful for renewal") },
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("input_notes"),
                    minLines = 3,
                    colors = customTextFieldColors()
                )

                Spacer(modifier = Modifier.height(16.dp))

                // ATTACHED DOCUMENTS SECTION
                Surface(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp),
                    color = CharcoalElevated,
                    border = BorderStroke(1.dp, CharcoalBorder)
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = "Attached documents",
                                    color = TextWhite,
                                    fontSize = 14.sp,
                                    fontWeight = FontWeight.Bold
                                )
                                Text(
                                    text = "Attach additional documents (Roadworthy Certificate, ID, proof of address, insurance, invoice)",
                                    color = TextMuted,
                                    fontSize = 11.sp
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(10.dp))

                        // Attached Documents List
                        if (attachedDocuments.isEmpty()) {
                            Surface(
                                modifier = Modifier.fillMaxWidth(),
                                shape = RoundedCornerShape(8.dp),
                                color = CharcoalCard,
                                border = BorderStroke(1.dp, CharcoalBorder)
                            ) {
                                Row(
                                    modifier = Modifier.padding(12.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Description,
                                        contentDescription = null,
                                        tint = TextMuted,
                                        modifier = Modifier.size(20.dp)
                                    )
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text(
                                        text = "No documents attached yet.",
                                        color = TextMuted,
                                        fontSize = 12.sp
                                    )
                                }
                            }
                        } else {
                            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                attachedDocuments.forEachIndexed { index, doc ->
                                    val isPdf = doc.mimeType.contains("pdf", ignoreCase = true) || doc.name.endsWith(".pdf", ignoreCase = true)
                                    Surface(
                                        modifier = Modifier.fillMaxWidth(),
                                        shape = RoundedCornerShape(8.dp),
                                        color = CharcoalCard,
                                        border = BorderStroke(0.5.dp, CharcoalBorder)
                                    ) {
                                        Row(
                                            modifier = Modifier.padding(10.dp),
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            Surface(
                                                shape = RoundedCornerShape(6.dp),
                                                color = if (isPdf) StatusRed.copy(alpha = 0.2f) else IQYellow.copy(alpha = 0.2f),
                                                modifier = Modifier.size(34.dp)
                                            ) {
                                                Box(contentAlignment = Alignment.Center) {
                                                    Icon(
                                                        imageVector = if (isPdf) Icons.Default.PictureAsPdf else Icons.Default.Image,
                                                        contentDescription = null,
                                                        tint = if (isPdf) StatusRed else IQYellow,
                                                        modifier = Modifier.size(18.dp)
                                                    )
                                                }
                                            }

                                            Spacer(modifier = Modifier.width(10.dp))

                                            Column(modifier = Modifier.weight(1f)) {
                                                Text(
                                                    text = doc.name,
                                                    color = TextWhite,
                                                    fontSize = 12.sp,
                                                    fontWeight = FontWeight.SemiBold,
                                                    maxLines = 1
                                                )
                                                Row(verticalAlignment = Alignment.CenterVertically) {
                                                    Text(
                                                        text = doc.type,
                                                        color = IQYellow,
                                                        fontSize = 10.sp,
                                                        fontWeight = FontWeight.Medium
                                                    )
                                                    if (doc.addedDate.isNotBlank()) {
                                                        Text(
                                                            text = " • ${doc.addedDate}",
                                                            color = TextMuted,
                                                            fontSize = 10.sp
                                                        )
                                                    }
                                                }
                                            }

                                            // Preview button
                                            IconButton(
                                                onClick = { previewDocument = doc },
                                                modifier = Modifier.size(28.dp)
                                            ) {
                                                Icon(
                                                    imageVector = Icons.Default.Visibility,
                                                    contentDescription = "View document",
                                                    tint = TextLightGray,
                                                    modifier = Modifier.size(16.dp)
                                                )
                                            }

                                            // Delete button
                                            IconButton(
                                                onClick = { attachedDocuments.removeAt(index) },
                                                modifier = Modifier.size(28.dp)
                                            ) {
                                                Icon(
                                                    imageVector = Icons.Default.Delete,
                                                    contentDescription = "Remove document",
                                                    tint = StatusRed,
                                                    modifier = Modifier.size(16.dp)
                                                )
                                            }
                                        }
                                    }
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(10.dp))

                        // Attach Document Action Button
                        OutlinedButton(
                            onClick = { documentPickerLauncher.launch("*/*") },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(40.dp)
                                .testTag("btn_attach_document"),
                            shape = RoundedCornerShape(8.dp),
                            border = BorderStroke(1.dp, IQYellow),
                            colors = ButtonDefaults.outlinedButtonColors(
                                containerColor = CharcoalCard
                            )
                        ) {
                            Icon(
                                imageVector = Icons.Default.AttachFile,
                                contentDescription = null,
                                tint = IQYellow,
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "+ Attach Document (PDF or Image)",
                                color = IQYellow,
                                fontWeight = FontWeight.Bold,
                                fontSize = 12.sp
                            )
                        }

                        Spacer(modifier = Modifier.height(8.dp))

                        // Quick presets for common South African renewal documents
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .horizontalScroll(rememberScrollState()),
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            QuickDocPresetChip("+ Roadworthy (COF)") {
                                attachedDocuments.add(
                                    AttachedDocument(
                                        name = "Roadworthy Certificate (COF)",
                                        type = "Roadworthy",
                                        uri = "roadworthy_cert.pdf",
                                        mimeType = "application/pdf",
                                        addedDate = LocalDate.now().toString(),
                                        fileSize = "Certificate"
                                    )
                                )
                                Toast.makeText(context, "Roadworthy (COF) added", Toast.LENGTH_SHORT).show()
                            }
                            QuickDocPresetChip("+ ID Document") {
                                attachedDocuments.add(
                                    AttachedDocument(
                                        name = "ID Document Copy",
                                        type = "Identity",
                                        uri = "id_document.pdf",
                                        mimeType = "application/pdf",
                                        addedDate = LocalDate.now().toString(),
                                        fileSize = "ID Copy"
                                    )
                                )
                                Toast.makeText(context, "ID Document added", Toast.LENGTH_SHORT).show()
                            }
                            QuickDocPresetChip("+ Proof of Residence") {
                                attachedDocuments.add(
                                    AttachedDocument(
                                        name = "Proof of Residence (Utility)",
                                        type = "Address",
                                        uri = "proof_of_residence.pdf",
                                        mimeType = "application/pdf",
                                        addedDate = LocalDate.now().toString(),
                                        fileSize = "Utility Bill"
                                    )
                                )
                                Toast.makeText(context, "Proof of residence added", Toast.LENGTH_SHORT).show()
                            }
                            QuickDocPresetChip("+ Insurance Certificate") {
                                attachedDocuments.add(
                                    AttachedDocument(
                                        name = "Comprehensive Insurance Certificate",
                                        type = "Insurance",
                                        uri = "insurance_policy.pdf",
                                        mimeType = "application/pdf",
                                        addedDate = LocalDate.now().toString(),
                                        fileSize = "Policy"
                                    )
                                )
                                Toast.makeText(context, "Insurance certificate added", Toast.LENGTH_SHORT).show()
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                // ADDITIONAL DETAILS & REMINDERS ACCORDION
                Surface(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { showAdditionalDetails = !showAdditionalDetails },
                    shape = RoundedCornerShape(10.dp),
                    color = CharcoalElevated,
                    border = BorderStroke(0.5.dp, CharcoalBorder)
                ) {
                    Row(
                        modifier = Modifier.padding(12.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "Additional Details & Automated Reminders",
                            color = TextLightGray,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.SemiBold
                        )
                        Icon(
                            imageVector = if (showAdditionalDetails) Icons.Default.ExpandLess else Icons.Default.ExpandMore,
                            contentDescription = null,
                            tint = TextMuted
                        )
                    }
                }

                if (showAdditionalDetails) {
                    Spacer(modifier = Modifier.height(10.dp))
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            OutlinedTextField(
                                value = makeModel,
                                onValueChange = { makeModel = it },
                                label = { Text("Make & Model") },
                                placeholder = { Text("Toyota Hatch back") },
                                modifier = Modifier.weight(1f),
                                singleLine = true,
                                colors = customTextFieldColors()
                            )
                            OutlinedTextField(
                                value = discNumber,
                                onValueChange = { discNumber = it },
                                label = { Text("Disc Number") },
                                placeholder = { Text("1037020D7FNM") },
                                modifier = Modifier.weight(1f),
                                singleLine = true,
                                colors = customTextFieldColors()
                            )
                        }

                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            OutlinedTextField(
                                value = issueDate,
                                onValueChange = { issueDate = it },
                                label = { Text("Issue Date") },
                                placeholder = { Text("YYYY-MM-DD") },
                                modifier = Modifier.weight(1f),
                                singleLine = true,
                                colors = customTextFieldColors()
                            )
                            OutlinedTextField(
                                value = renewalFeeStr,
                                onValueChange = { renewalFeeStr = it },
                                label = { Text("Fee (R)") },
                                modifier = Modifier.weight(1f),
                                singleLine = true,
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                                colors = customTextFieldColors()
                            )
                        }

                        OutlinedTextField(
                            value = address,
                            onValueChange = { address = it },
                            label = { Text("Address") },
                            placeholder = { Text("Physical / Postal address") },
                            modifier = Modifier.fillMaxWidth(),
                            singleLine = true,
                            colors = customTextFieldColors()
                        )

                        // Automated reminders toggle
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text(
                                    text = "Automated Reminders",
                                    color = TextWhite,
                                    fontSize = 13.sp,
                                    fontWeight = FontWeight.Bold
                                )
                                Text(
                                    text = "Notify client before expiry date",
                                    color = TextMuted,
                                    fontSize = 11.sp
                                )
                            }
                            Switch(
                                checked = reminderEnabled,
                                onCheckedChange = { reminderEnabled = it },
                                colors = SwitchDefaults.colors(
                                    checkedThumbColor = TextDark,
                                    checkedTrackColor = IQYellow
                                )
                            )
                        }

                        if (reminderEnabled) {
                            ReminderIntervalCheckbox("90 days before expiry", remind90Days) { remind90Days = it }
                            ReminderIntervalCheckbox("60 days before expiry", remind60Days) { remind60Days = it }
                            ReminderIntervalCheckbox("30 days before expiry", remind30Days) { remind30Days = it }
                            ReminderIntervalCheckbox("14 days before expiry", remind14Days) { remind14Days = it }
                            ReminderIntervalCheckbox("7 days before expiry", remind7Days) { remind7Days = it }
                            ReminderIntervalCheckbox("1 day before expiry", remind1Day) { remind1Day = it }
                        }
                    }
                }

                if (errorMessage != null) {
                    Spacer(modifier = Modifier.height(10.dp))
                    Text(
                        text = errorMessage!!,
                        color = StatusRed,
                        fontSize = 12.sp
                    )
                }

                Spacer(modifier = Modifier.height(18.dp))

                // BOTTOM ACTION BUTTONS: Cancel and Save Record
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    OutlinedButton(
                        onClick = onDismiss,
                        modifier = Modifier
                            .weight(1f)
                            .height(46.dp),
                        shape = RoundedCornerShape(10.dp),
                        border = BorderStroke(1.dp, CharcoalBorder)
                    ) {
                        Text("Cancel", color = TextWhite)
                    }

                    Button(
                        onClick = {
                            if (name.isBlank()) {
                                errorMessage = "Customer name is required"
                                return@Button
                            }
                            val validRegistration = if (registration.isNotBlank()) {
                                registration.trim().uppercase()
                            } else {
                                "MV-${System.currentTimeMillis() % 100000}"
                            }
                            val parsedFee = renewalFeeStr.toDoubleOrNull() ?: 480.0

                            val documentsJson = attachedDocuments.toList().toJsonString()

                            val customerToSave = Customer(
                                id = initialCustomer?.id ?: 0,
                                name = name.trim(),
                                phone = phone.trim(),
                                email = email.trim(),
                                vehicleRegistration = validRegistration,
                                vehicleType = selectedVehicleType.trim(),
                                vehicleMakeModel = if (makeModel.isBlank()) selectedVehicleType else makeModel.trim(),
                                licenseDiscNumber = if (discNumber.isBlank()) "SA-$validRegistration" else discNumber.trim(),
                                expiryDate = expiryDate.trim(),
                                renewalFee = parsedFee,
                                notes = notes.trim(),
                                lastReminderSent = initialCustomer?.lastReminderSent,
                                idNumber = idNumber.trim(),
                                companyName = companyName.trim(),
                                address = address.trim(),
                                issueDate = issueDate.trim(),
                                reminderEnabled = reminderEnabled,
                                remind90Days = remind90Days,
                                remind60Days = remind60Days,
                                remind30Days = remind30Days,
                                remind14Days = remind14Days,
                                remind7Days = remind7Days,
                                remind1Day = remind1Day,
                                attachedDocumentsJson = documentsJson,
                                licensePhotoUri = licensePhotoUri
                            )
                            onSaveCustomer(customerToSave)
                        },
                        modifier = Modifier
                            .weight(1.4f)
                            .height(46.dp)
                            .testTag("submit_customer_button"),
                        shape = RoundedCornerShape(10.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = IQYellow)
                    ) {
                        Text(
                            text = if (initialCustomer != null) "Save Changes" else "Save Record",
                            color = TextDark,
                            fontWeight = FontWeight.Bold,
                            fontSize = 14.sp
                        )
                    }
                }
            }
        }
    }

    // Modal to preview an attached document
    if (previewDocument != null) {
        val doc = previewDocument!!
        val isPdf = doc.mimeType.contains("pdf", ignoreCase = true)
        Dialog(onDismissRequest = { previewDocument = null }) {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = CharcoalCard),
                border = BorderStroke(1.dp, CharcoalBorder)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = doc.name,
                            color = TextWhite,
                            fontWeight = FontWeight.Bold,
                            fontSize = 14.sp,
                            maxLines = 1,
                            modifier = Modifier.weight(1f)
                        )
                        IconButton(
                            onClick = { previewDocument = null },
                            modifier = Modifier.size(28.dp)
                        ) {
                            Icon(Icons.Default.Close, contentDescription = "Close", tint = TextMuted)
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    if (!isPdf && doc.uri.isNotBlank() && (doc.uri.startsWith("content://") || doc.uri.startsWith("file://") || doc.uri.startsWith("http"))) {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(220.dp)
                                .clip(RoundedCornerShape(8.dp))
                                .background(CharcoalBorder),
                            contentAlignment = Alignment.Center
                        ) {
                            AsyncImage(
                                model = doc.uri,
                                contentDescription = doc.name,
                                modifier = Modifier.fillMaxSize(),
                                contentScale = ContentScale.Fit
                            )
                        }
                    } else {
                        Surface(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(160.dp),
                            shape = RoundedCornerShape(8.dp),
                            color = CharcoalElevated,
                            border = BorderStroke(1.dp, CharcoalBorder)
                        ) {
                            Column(
                                modifier = Modifier.fillMaxSize(),
                                horizontalAlignment = Alignment.CenterHorizontally,
                                verticalArrangement = Arrangement.Center
                            ) {
                                Icon(
                                    imageVector = if (isPdf) Icons.Default.PictureAsPdf else Icons.Default.Description,
                                    contentDescription = null,
                                    tint = if (isPdf) StatusRed else IQYellow,
                                    modifier = Modifier.size(48.dp)
                                )
                                Spacer(modifier = Modifier.height(8.dp))
                                Text(
                                    text = if (isPdf) "PDF Document Attached" else "Document Attached",
                                    color = TextWhite,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 13.sp
                                )
                                Text(
                                    text = "Type: ${doc.type} • Date: ${doc.addedDate}",
                                    color = TextMuted,
                                    fontSize = 11.sp
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    Button(
                        onClick = { previewDocument = null },
                        modifier = Modifier.fillMaxWidth(),
                        colors = ButtonDefaults.buttonColors(containerColor = IQYellow),
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Text("Close Preview", color = TextDark, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}

@Composable
private fun QuickDocPresetChip(
    label: String,
    onClick: () -> Unit
) {
    Surface(
        shape = RoundedCornerShape(6.dp),
        color = CharcoalCard,
        border = BorderStroke(1.dp, CharcoalBorder),
        onClick = onClick
    ) {
        Text(
            text = label,
            color = TextLightGray,
            fontSize = 11.sp,
            fontWeight = FontWeight.Medium,
            modifier = Modifier.padding(horizontal = 8.dp, vertical = 5.dp)
        )
    }
}

@Composable
private fun QuickDateButton(label: String, onClick: () -> Unit) {
    Surface(
        shape = RoundedCornerShape(6.dp),
        color = CharcoalElevated,
        border = BorderStroke(1.dp, CharcoalBorder),
        onClick = onClick
    ) {
        Text(
            text = label,
            color = IQYellow,
            fontSize = 10.sp,
            fontWeight = FontWeight.SemiBold,
            modifier = Modifier.padding(horizontal = 6.dp, vertical = 3.dp)
        )
    }
}

@Composable
private fun ReminderIntervalCheckbox(
    label: String,
    checked: Boolean,
    onCheckedChange: (Boolean) -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onCheckedChange(!checked) }
            .padding(vertical = 2.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Checkbox(
            checked = checked,
            onCheckedChange = onCheckedChange,
            colors = CheckboxDefaults.colors(
                checkedColor = IQYellow,
                uncheckedColor = TextMuted,
                checkmarkColor = TextDark
            ),
            modifier = Modifier.size(24.dp)
        )
        Spacer(modifier = Modifier.width(8.dp))
        Text(
            text = label,
            color = if (checked) TextWhite else TextMuted,
            fontSize = 12.sp,
            fontWeight = if (checked) FontWeight.Medium else FontWeight.Normal
        )
    }
}

@Composable
private fun customTextFieldColors() = OutlinedTextFieldDefaults.colors(
    focusedBorderColor = IQYellow,
    unfocusedBorderColor = CharcoalBorder,
    focusedLabelColor = IQYellow,
    unfocusedLabelColor = TextMuted,
    cursorColor = IQYellow,
    focusedTextColor = TextWhite,
    unfocusedTextColor = TextWhite,
    focusedContainerColor = CharcoalElevated,
    unfocusedContainerColor = CharcoalElevated
)
