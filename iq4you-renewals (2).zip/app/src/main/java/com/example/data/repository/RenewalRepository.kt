package com.example.data.repository

import com.example.data.model.AppSettings
import com.example.data.model.Customer
import com.example.data.model.DashboardStats
import com.example.data.model.ReminderChannel
import com.example.data.model.ReminderLog
import com.example.data.service.ReminderRunResult
import kotlinx.coroutines.flow.Flow

/**
 * Clean data interface for IQ4YOU Renewals.
 * Decoupled from the storage implementation so that this is backed by
 * persistent Room local database and integrated with Firebase Firestore cloud persistence.
 */
interface RenewalRepository {
    fun getCustomers(): Flow<List<Customer>>
    fun getActiveCustomers(): Flow<List<Customer>>
    fun getRecycleBinCustomers(): Flow<List<Customer>>
    fun getCustomerById(id: Long): Flow<Customer?>

    suspend fun addCustomer(customer: Customer): Long
    suspend fun updateCustomer(customer: Customer)
    suspend fun softDeleteCustomer(id: Long)
    suspend fun restoreCustomer(id: Long)
    suspend fun permanentlyDeleteCustomer(id: Long)
    suspend fun emptyRecycleBin()

    fun getDashboardStats(): Flow<DashboardStats>

    fun getReminderLogs(): Flow<List<ReminderLog>>
    suspend fun logReminder(log: ReminderLog): Long
    suspend fun clearReminderLogs()

    fun getSettings(): Flow<AppSettings>
    suspend fun saveSettings(settings: AppSettings)

    fun getRenewalRecords(): Flow<List<com.example.data.model.RenewalRecord>>
    suspend fun addRenewalRecord(record: com.example.data.model.RenewalRecord): Long

    suspend fun sendTestReminder(customerId: Long?, channel: ReminderChannel): ReminderLog
    suspend fun runScheduledRemindersCheck(): ReminderRunResult
    suspend fun syncWithCloud(): Boolean
    suspend fun testBackendConnection(endpointUrl: String): BackendTestResult
    suspend fun resetToSampleData()
    suspend fun ensureDataInitialized()
}

data class BackendTestResult(
    val isSuccess: Boolean,
    val latencyMs: Long,
    val message: String,
    val timestamp: String
)

