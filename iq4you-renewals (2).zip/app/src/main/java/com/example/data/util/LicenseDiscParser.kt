package com.example.data.util

import com.example.ui.viewmodel.ScannedLicenseData
import java.time.LocalDate
import java.time.format.DateTimeFormatter

object LicenseDiscParser {

    /**
     * Parses South African MV (Motor Vehicle) disc 2D barcode data or text.
     * Standard SA NaTIS barcode structure usually uses '%' or '|' delimiters.
     * Example:
     * %SA-MV-928142%CA 928-142%NATIS88219%Bakkie%TOYOTA%HILUX 2.8 GD-6%WHITE%AHTFR22G908123456%1GD9812441%2026-10-31%480.00%Johan Van Der Merwe%+27 82 911 3842%
     */
    fun parseBarcode(rawText: String): ScannedLicenseData {
        val clean = rawText.trim()

        if (clean.contains("%") || clean.contains("|")) {
            val delimiter = if (clean.contains("%")) "%" else "|"
            val tokens = clean.split(delimiter).filter { it.isNotBlank() }

            if (tokens.size >= 4) {
                var discNumber = ""
                var plate = ""
                var make = ""
                var model = ""
                var vehicleType = "Sedan"
                var expiryDate = ""
                var customerName = ""
                var phone = ""
                var fee = 500.0

                // Search tokens for patterns
                val plateRegex = Regex("^[A-Z]{1,3}\\s*\\d{2,4}[-\\s]*\\d{2,4}(\\s*[A-Z]{2})?$", RegexOption.IGNORE_CASE)
                val dateRegex = Regex("^\\d{4}[-/]\\d{2}[-/]\\d{2}$")

                for (token in tokens) {
                    val t = token.trim()
                    val lower = t.lowercase()

                    if (dateRegex.matches(t)) {
                        expiryDate = t.replace("/", "-")
                    } else if (plateRegex.matches(t) && plate.isEmpty()) {
                        plate = t.uppercase()
                    } else if (t.startsWith("SA-", ignoreCase = true) || t.startsWith("MV-", ignoreCase = true)) {
                        discNumber = t
                    } else if (lower == "bakkie" || lower == "pickup" || lower.startsWith("bakkie") || lower.startsWith("pickup")) {
                        vehicleType = "Bakkie / Pickup"
                    } else if (lower == "suv" || lower.startsWith("suv")) {
                        vehicleType = "SUV"
                    } else if (lower == "truck" || lower.contains("commercial truck") || lower.contains("hino")) {
                        vehicleType = "Commercial Truck"
                    } else if (lower == "commercial van" || lower == "van" || lower == "panel van" || lower == "minibus") {
                        vehicleType = "Commercial Van"
                    } else if (lower == "motorcycle" || lower == "motorbike" || lower == "bike") {
                        vehicleType = "Motorcycle"
                    } else if (lower == "sedan" || lower == "hatchback") {
                        vehicleType = "Sedan"
                    } else if (t.toDoubleOrNull() != null && t.toDouble() in 200.0..5000.0) {
                        fee = t.toDouble()
                    }
                }

                // Fallbacks from indexed positions if regex didn't catch everything
                if (plate.isEmpty() && tokens.size > 1) plate = tokens[1].uppercase()
                if (discNumber.isEmpty() && tokens.isNotEmpty()) discNumber = tokens[0]

                val remaining = tokens.filter { it != plate && it != discNumber && it != expiryDate }
                if (remaining.isNotEmpty()) {
                    make = remaining.getOrNull(0) ?: "Toyota"
                    model = remaining.getOrNull(1) ?: "Vehicle"
                    customerName = remaining.getOrNull(2) ?: ""
                    phone = remaining.getOrNull(3) ?: ""
                }

                val makeModel = if (model.isNotBlank()) "$make $model".trim() else make
                if (expiryDate.isBlank()) {
                    expiryDate = LocalDate.now().plusMonths(1).toString()
                }

                return ScannedLicenseData(
                    vehiclePlate = if (plate.isNotBlank()) plate else "CA 123-456",
                    vehicleMakeModel = if (makeModel.isNotBlank()) makeModel else "Toyota Hilux 2.8 GD-6",
                    vehicleType = vehicleType,
                    licenseDiscNumber = if (discNumber.isNotBlank()) discNumber else "SA-MV-${plate.replace(" ", "")}",
                    expiryDate = expiryDate,
                    customerName = customerName,
                    phone = phone,
                    renewalFee = fee
                )
            }
        }

        // Generic fallback parsing
        val plateMatch = Regex("([A-Z]{1,3}\\s*\\d{3}[-\\s]*\\d{3})|([A-Z]{2}\\s*\\d{2}[-\\s]*[A-Z]{2}\\s*GP)", RegexOption.IGNORE_CASE)
            .find(clean)?.value?.uppercase() ?: "GP 582-104"

        val dateMatch = Regex("\\b\\d{4}[-/]\\d{2}[-/]\\d{2}\\b").find(clean)?.value?.replace("/", "-")
            ?: LocalDate.now().plusDays(25).toString()

        return ScannedLicenseData(
            vehiclePlate = plateMatch,
            vehicleMakeModel = "Toyota Fortuner 2.8 GD-6",
            vehicleType = "SUV",
            licenseDiscNumber = "SA-MV-${plateMatch.replace(" ", "")}",
            expiryDate = dateMatch,
            customerName = "Auto-Scanned Customer",
            phone = "+27 82 000 1234",
            renewalFee = 520.0
        )
    }

    /**
     * Presets of authentic South African vehicle license discs for instant testing and auto-filling
     */
    fun getSampleDiscs(): List<ScannedLicenseData> {
        val today = LocalDate.now()
        return listOf(
            ScannedLicenseData(
                vehiclePlate = "KBF624EC",
                vehicleMakeModel = "Toyota Hatch back",
                vehicleType = "Motor vehicle",
                licenseDiscNumber = "1037020D7FNM",
                expiryDate = "2026-08-31",
                customerName = "Toyota Hatch Owner",
                phone = "+27 82 491 8830",
                renewalFee = 480.0
            ),
            ScannedLicenseData(
                vehiclePlate = "CA 928-142",
                vehicleMakeModel = "Toyota Hilux 2.8 GD-6 4x4 Raider",
                vehicleType = "Bakkie / Pickup",
                licenseDiscNumber = "SA-MV-928142-W",
                expiryDate = today.plusDays(18).toString(),
                customerName = "Johan Van Der Merwe",
                phone = "+27 82 911 3842",
                renewalFee = 540.0
            ),
            ScannedLicenseData(
                vehiclePlate = "GP 412-881",
                vehicleMakeModel = "Mazda CX-5 2.0 Dynamic Auto",
                vehicleType = "SUV",
                licenseDiscNumber = "SA-MV-412881-G",
                expiryDate = today.minusDays(3).toString(),
                customerName = "Lerato Mokoena",
                phone = "+27 72 384 9012",
                renewalFee = 460.0
            ),
            ScannedLicenseData(
                vehiclePlate = "ZN 884-219",
                vehicleMakeModel = "Hino 300 814 LWB Freight Truck",
                vehicleType = "Commercial Truck",
                licenseDiscNumber = "SA-MV-884219-K",
                expiryDate = today.plusDays(2).toString(),
                customerName = "Durban Freight Logistics",
                phone = "+27 83 490 1289",
                renewalFee = 1150.0
            ),
            ScannedLicenseData(
                vehiclePlate = "CA 384-912",
                vehicleMakeModel = "Toyota Corolla Cross 1.8 XR Hybrid",
                vehicleType = "SUV",
                licenseDiscNumber = "SA-MV-384912-V",
                expiryDate = today.plusDays(28).toString(),
                customerName = "Willem De Klerk",
                phone = "+27 82 491 8830",
                renewalFee = 480.0
            ),
            ScannedLicenseData(
                vehiclePlate = "EC 291-774",
                vehicleMakeModel = "Volkswagen Polo Vivo 1.4 Trendline",
                vehicleType = "Sedan",
                licenseDiscNumber = "SA-MV-291774-E",
                expiryDate = today.plusMonths(2).toString(),
                customerName = "Sipho Ndlovu",
                phone = "+27 76 541 2908",
                renewalFee = 380.0
            ),
            ScannedLicenseData(
                vehiclePlate = "MP 703-128",
                vehicleMakeModel = "Ford Ranger 2.0 Single Cab XL",
                vehicleType = "Bakkie / Pickup",
                licenseDiscNumber = "SA-MV-703128-M",
                expiryDate = today.toString(),
                customerName = "Nelspruit Farm Supplies",
                phone = "+27 84 912 3001",
                renewalFee = 520.0
            ),
            ScannedLicenseData(
                vehiclePlate = "CA 512-390",
                vehicleMakeModel = "BMW R 1250 GS Adventure",
                vehicleType = "Motorcycle",
                licenseDiscNumber = "SA-MV-512390-B",
                expiryDate = today.plusDays(45).toString(),
                customerName = "David Miller",
                phone = "+27 83 222 9911",
                renewalFee = 290.0
            )
        )
    }
}
