package com.example.data.model

import java.time.LocalDate
import java.time.temporal.ChronoUnit

enum class RenewalStatus(val label: String) {
    EXPIRED("Expired"),
    DUE_TODAY("Due Today"),
    EXPIRING_SOON("Expiring Soon"),
    ACTIVE("Active");

    companion object {
        fun fromExpiryDate(expiryDateStr: String): RenewalStatus {
            return try {
                val expiry = LocalDate.parse(expiryDateStr)
                val today = LocalDate.now()
                val days = ChronoUnit.DAYS.between(today, expiry)
                when {
                    days < 0 -> EXPIRED
                    days == 0L -> DUE_TODAY
                    days <= 30 -> EXPIRING_SOON
                    else -> ACTIVE
                }
            } catch (e: Exception) {
                ACTIVE
            }
        }
    }
}

data class Customer(
    val id: Long = 0,
    val name: String,
    val phone: String,
    val email: String,
    val vehicleRegistration: String,
    val vehicleType: String = "Sedan", // Sedan, SUV, Bakkie / Pickup, Commercial Truck, Commercial Van, Motorcycle
    val vehicleMakeModel: String = "",
    val licenseDiscNumber: String = "",
    val expiryDate: String, // "YYYY-MM-DD"
    val renewalFee: Double = 0.0,
    val notes: String = "",
    val lastReminderSent: String? = null,
    val idNumber: String = "",
    val companyName: String = "",
    val address: String = "",
    val issueDate: String = "",
    val isDeleted: Boolean = false,
    val deletedAt: Long? = null,
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis(),
    val reminderEnabled: Boolean = true,
    val remind90Days: Boolean = true,
    val remind60Days: Boolean = true,
    val remind30Days: Boolean = true,
    val remind14Days: Boolean = true,
    val remind7Days: Boolean = true,
    val remind1Day: Boolean = true,
    val attachedDocumentsJson: String = "",
    val licensePhotoUri: String = ""
) {
    val status: RenewalStatus
        get() = RenewalStatus.fromExpiryDate(expiryDate)

    fun getAttachedDocuments(): List<AttachedDocument> {
        if (attachedDocumentsJson.isBlank()) return emptyList()
        return try {
            val jsonArray = org.json.JSONArray(attachedDocumentsJson)
            val list = mutableListOf<AttachedDocument>()
            for (i in 0 until jsonArray.length()) {
                val obj = jsonArray.getJSONObject(i)
                list.add(
                    AttachedDocument(
                        id = obj.optString("id", java.util.UUID.randomUUID().toString()),
                        name = obj.optString("name", "Document"),
                        type = obj.optString("type", "Document"),
                        uri = obj.optString("uri", ""),
                        mimeType = obj.optString("mimeType", "image/jpeg"),
                        addedDate = obj.optString("addedDate", ""),
                        fileSize = obj.optString("fileSize", "")
                    )
                )
            }
            list
        } catch (e: Exception) {
            emptyList()
        }
    }

    val daysUntilExpiry: Long
        get() {
            return try {
                val expiry = LocalDate.parse(expiryDate)
                ChronoUnit.DAYS.between(LocalDate.now(), expiry)
            } catch (e: Exception) {
                999L
            }
        }

    val reminderScheduleSummary: String
        get() {
            if (!reminderEnabled) return "Disabled"
            val intervals = mutableListOf<String>()
            if (remind90Days) intervals.add("90d")
            if (remind60Days) intervals.add("60d")
            if (remind30Days) intervals.add("30d")
            if (remind14Days) intervals.add("14d")
            if (remind7Days) intervals.add("7d")
            if (remind1Day) intervals.add("1d")
            return if (intervals.isEmpty()) "None" else intervals.joinToString(", ")
        }
}

enum class ReminderChannel(val displayName: String) {
    WHATSAPP("WhatsApp"),
    EMAIL("Email"),
    SYSTEM("System Notification"),
    SMS("SMS")
}

enum class ReminderStatus(val displayName: String) {
    DELIVERED("Delivered"),
    SENT("Sent"),
    QUEUED("Queued"),
    FAILED("Failed")
}

data class ReminderLog(
    val id: Long = 0,
    val customerId: Long,
    val customerName: String,
    val vehiclePlate: String,
    val channel: ReminderChannel,
    val status: ReminderStatus,
    val messageText: String,
    val timestamp: Long = System.currentTimeMillis(),
    val recipientEmail: String = "",
    val renewalDate: String = "",
    val reminderInterval: String = "", // e.g. "90_DAYS", "60_DAYS", "30_DAYS", "14_DAYS", "7_DAYS", "1_DAY", "MANUAL"
    val errorMessage: String? = null
)

data class AppSettings(
    val automaticReminders: Boolean = true,
    val remind90DaysDefault: Boolean = true,
    val remind60DaysDefault: Boolean = true,
    val remind30DaysBefore: Boolean = true,
    val remind14DaysBefore: Boolean = true,
    val remind7DaysBefore: Boolean = true,
    val remind1DayBefore: Boolean = true,
    val consolidatePerContact: Boolean = true,
    val reminderTime: String = "09:00 AM",
    val emailSubjectTemplate: String = "License Renewal Reminder – {CustomerName}",
    val emailBodyTemplate: String = "Hello {CustomerName},\n\nThis is a reminder that your {LicenseType} is due for renewal on {RenewalDate}.\n\nLicense Number: {LicenseNumber}\n\nPlease contact us if you require assistance with your renewal.\n\nKind regards,\nIQ4U Renewals",
    val backendUrl: String = "", // Modular placeholder for cloud sync
    val backendConnected: Boolean = true,
    val lastSyncTime: String = "Just now",
    val cloudSyncEnabled: Boolean = true
)

data class DashboardStats(
    val dueToday: Int,
    val dueThisWeek: Int,
    val expired: Int,
    val totalCustomers: Int,
    val totalReminders: Int,
    val activeCount: Int,
    val recycleBinCount: Int = 0,
    val dueIn7Days: Int = 0,
    val dueIn30Days: Int = 0,
    val dueIn60Days: Int = 0,
    val dueIn90Days: Int = 0,
    val remindersDisabledCount: Int = 0,
    val lastReminderSentSummary: String = "No reminders sent yet",
    val nextScheduledCheck: String = "Daily at 09:00 AM"
)

data class ExtractedRenewalInfo(
    val customerName: String = "",
    val idNumber: String = "",
    val companyName: String = "",
    val phone: String = "",
    val email: String = "",
    val address: String = "",
    val vehicleRegistration: String = "",
    val vehicleMakeModel: String = "",
    val vehicleType: String = "Sedan",
    val licenseDiscNumber: String = "",
    val issueDate: String = "",
    val expiryDate: String = "",
    val renewalFee: Double = 0.0,
    val notes: String = "",
    val sourceFileName: String = "",
    val sourceMimeType: String = "",
    val confidenceNotes: String = "",
    val isAiExtracted: Boolean = true
)

data class AttachedDocument(
    val id: String = java.util.UUID.randomUUID().toString(),
    val name: String,
    val type: String = "Document",
    val uri: String,
    val mimeType: String = "image/jpeg",
    val addedDate: String = java.time.LocalDate.now().toString(),
    val fileSize: String = ""
)

data class RenewalRecord(
    val id: Long = 0,
    val customerName: String,
    val licenseType: String,
    val expiryDate: String,
    val status: String,
    val licenseNumber: String = "",
    val renewalFee: Double = 0.0,
    val issueDate: String = "",
    val notes: String = "",
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis(),
    val attachedDocumentsJson: String = "",
    val photoUri: String = ""
) {
    fun getAttachedDocuments(): List<AttachedDocument> {
        if (attachedDocumentsJson.isBlank()) return emptyList()
        return try {
            val jsonArray = org.json.JSONArray(attachedDocumentsJson)
            val list = mutableListOf<AttachedDocument>()
            for (i in 0 until jsonArray.length()) {
                val obj = jsonArray.getJSONObject(i)
                list.add(
                    AttachedDocument(
                        id = obj.optString("id", java.util.UUID.randomUUID().toString()),
                        name = obj.optString("name", "Document"),
                        type = obj.optString("type", "Document"),
                        uri = obj.optString("uri", ""),
                        mimeType = obj.optString("mimeType", "image/jpeg"),
                        addedDate = obj.optString("addedDate", ""),
                        fileSize = obj.optString("fileSize", "")
                    )
                )
            }
            list
        } catch (e: Exception) {
            emptyList()
        }
    }
}

fun List<AttachedDocument>.toJsonString(): String {
    if (isEmpty()) return ""
    return try {
        val array = org.json.JSONArray()
        for (doc in this) {
            val obj = org.json.JSONObject()
            obj.put("id", doc.id)
            obj.put("name", doc.name)
            obj.put("type", doc.type)
            obj.put("uri", doc.uri)
            obj.put("mimeType", doc.mimeType)
            obj.put("addedDate", doc.addedDate)
            obj.put("fileSize", doc.fileSize)
            array.put(obj)
        }
        array.toString()
    } catch (e: Exception) {
        ""
    }
}
