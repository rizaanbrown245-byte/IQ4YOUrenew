package com.example.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey
import com.example.data.model.RenewalRecord

/**
 * Room database entity representing a renewal record.
 * Contains mandatory fields for customer name, license type, expiry date, and status,
 * along with additional supporting metadata for managing renewals.
 */
@Entity(tableName = "renewal_records")
data class RenewalRecordEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val customerName: String,
    val licenseType: String,
    val expiryDate: String,
    val status: String,
    val licenseNumber: String = "",
    val renewalFee: Double = 0.0,
    val issueDate: String = "",
    val notes: String = "",
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis(),
    val attachedDocumentsJson: String = "",
    val photoUri: String = ""
) {
    fun toDomain(): RenewalRecord = RenewalRecord(
        id = id,
        customerName = customerName,
        licenseType = licenseType,
        expiryDate = expiryDate,
        status = status,
        licenseNumber = licenseNumber,
        renewalFee = renewalFee,
        issueDate = issueDate,
        notes = notes,
        createdAt = createdAt,
        updatedAt = updatedAt,
        attachedDocumentsJson = attachedDocumentsJson,
        photoUri = photoUri
    )

    companion object {
        fun fromDomain(record: RenewalRecord): RenewalRecordEntity = RenewalRecordEntity(
            id = record.id,
            customerName = record.customerName,
            licenseType = record.licenseType,
            expiryDate = record.expiryDate,
            status = record.status,
            licenseNumber = record.licenseNumber,
            renewalFee = record.renewalFee,
            issueDate = record.issueDate,
            notes = record.notes,
            createdAt = record.createdAt,
            updatedAt = record.updatedAt,
            attachedDocumentsJson = record.attachedDocumentsJson,
            photoUri = record.photoUri
        )
    }
}
