package com.example.data.local

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

/**
 * Data Access Object (DAO) for managing [RenewalRecordEntity] in the Room database.
 * Provides operations to insert, update, query, filter, and delete renewal records.
 */
@Dao
interface RenewalRecordDao {

    @Query("SELECT * FROM renewal_records ORDER BY expiryDate ASC")
    fun getAllRenewalRecords(): Flow<List<RenewalRecordEntity>>

    @Query("SELECT * FROM renewal_records ORDER BY expiryDate ASC")
    suspend fun getAllRenewalRecordsList(): List<RenewalRecordEntity>

    @Query("SELECT * FROM renewal_records WHERE status = :status ORDER BY expiryDate ASC")
    fun getRenewalRecordsByStatus(status: String): Flow<List<RenewalRecordEntity>>

    @Query("SELECT * FROM renewal_records WHERE customerName LIKE '%' || :query || '%' OR licenseNumber LIKE '%' || :query || '%' OR licenseType LIKE '%' || :query || '%' ORDER BY expiryDate ASC")
    fun searchRenewalRecords(query: String): Flow<List<RenewalRecordEntity>>

    @Query("SELECT * FROM renewal_records WHERE customerName = :customerName ORDER BY expiryDate ASC")
    fun getRenewalRecordsForCustomer(customerName: String): Flow<List<RenewalRecordEntity>>

    @Query("SELECT * FROM renewal_records WHERE licenseType = :licenseType ORDER BY expiryDate ASC")
    fun getRenewalRecordsByLicenseType(licenseType: String): Flow<List<RenewalRecordEntity>>

    @Query("SELECT * FROM renewal_records WHERE expiryDate <= :beforeDate AND status != 'RENEWED' ORDER BY expiryDate ASC")
    fun getUpcomingRenewals(beforeDate: String): Flow<List<RenewalRecordEntity>>

    @Query("SELECT * FROM renewal_records WHERE expiryDate < :currentDate AND status != 'RENEWED' ORDER BY expiryDate ASC")
    fun getExpiredRenewals(currentDate: String): Flow<List<RenewalRecordEntity>>

    @Query("SELECT * FROM renewal_records WHERE id = :id")
    fun getRenewalRecordById(id: Long): Flow<RenewalRecordEntity?>

    @Query("SELECT * FROM renewal_records WHERE id = :id")
    suspend fun getRenewalRecordByIdSync(id: Long): RenewalRecordEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertRenewalRecord(record: RenewalRecordEntity): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertRenewalRecords(records: List<RenewalRecordEntity>): List<Long>

    @Update
    suspend fun updateRenewalRecord(record: RenewalRecordEntity): Int

    @Query("UPDATE renewal_records SET status = :status, updatedAt = :updatedAt WHERE id = :id")
    suspend fun updateRenewalStatus(id: Long, status: String, updatedAt: Long = System.currentTimeMillis()): Int

    @Delete
    suspend fun deleteRenewalRecord(record: RenewalRecordEntity): Int

    @Query("DELETE FROM renewal_records WHERE id = :id")
    suspend fun deleteRenewalRecordById(id: Long): Int

    @Query("SELECT COUNT(*) FROM renewal_records")
    suspend fun getRenewalRecordCount(): Int

    @Query("SELECT COUNT(*) FROM renewal_records WHERE status = :status")
    suspend fun getRenewalRecordCountByStatus(status: String): Int

    @Query("DELETE FROM renewal_records")
    suspend fun clearAllRenewalRecords()
}
