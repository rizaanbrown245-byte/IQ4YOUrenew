package com.example

import android.content.Context
import androidx.room.Room
import androidx.test.core.app.ApplicationProvider
import com.example.data.local.IQDatabase
import com.example.data.local.RenewalRecordDao
import com.example.data.local.RenewalRecordEntity
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.runBlocking
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config
import java.io.IOException

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class RenewalRecordDaoTest {

    private lateinit var db: IQDatabase
    private lateinit var dao: RenewalRecordDao

    @Before
    fun createDb() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        db = Room.inMemoryDatabaseBuilder(context, IQDatabase::class.java)
            .allowMainThreadQueries()
            .build()
        dao = db.renewalRecordDao()
    }

    @After
    @Throws(IOException::class)
    fun closeDb() {
        db.close()
    }

    @Test
    fun insertAndGetRenewalRecord() = runBlocking {
        val record = RenewalRecordEntity(
            customerName = "Thabo Sithole",
            licenseType = "Drivers License",
            expiryDate = "2026-12-31",
            status = "ACTIVE",
            licenseNumber = "DL-883192",
            renewalFee = 250.0
        )
        val id = dao.insertRenewalRecord(record)
        assertTrue(id > 0)

        val retrieved = dao.getRenewalRecordById(id).first()
        assertNotNull(retrieved)
        assertEquals("Thabo Sithole", retrieved?.customerName)
        assertEquals("Drivers License", retrieved?.licenseType)
        assertEquals("2026-12-31", retrieved?.expiryDate)
        assertEquals("ACTIVE", retrieved?.status)
    }

    @Test
    fun filterByStatusAndCustomer() = runBlocking {
        dao.insertRenewalRecord(
            RenewalRecordEntity(
                customerName = "Alice Smith",
                licenseType = "Vehicle License Disc",
                expiryDate = "2026-08-15",
                status = "PENDING"
            )
        )
        dao.insertRenewalRecord(
            RenewalRecordEntity(
                customerName = "Bob Jones",
                licenseType = "Operating License",
                expiryDate = "2026-05-10",
                status = "EXPIRED"
            )
        )

        val pending = dao.getRenewalRecordsByStatus("PENDING").first()
        assertEquals(1, pending.size)
        assertEquals("Alice Smith", pending[0].customerName)

        val aliceRecords = dao.getRenewalRecordsForCustomer("Alice Smith").first()
        assertEquals(1, aliceRecords.size)

        val count = dao.getRenewalRecordCount()
        assertEquals(2, count)
    }

    @Test
    fun updateStatusAndDelete() = runBlocking {
        val id = dao.insertRenewalRecord(
            RenewalRecordEntity(
                customerName = "Charlie Brown",
                licenseType = "Commercial Permit",
                expiryDate = "2026-09-01",
                status = "PENDING"
            )
        )

        dao.updateRenewalStatus(id, "RENEWED")
        val updated = dao.getRenewalRecordByIdSync(id)
        assertEquals("RENEWED", updated?.status)

        dao.deleteRenewalRecordById(id)
        val deleted = dao.getRenewalRecordByIdSync(id)
        assertNull(deleted)
    }
}
