package com.example.data.repository

import com.example.data.local.AppSettingsEntity
import com.example.data.local.CustomerEntity
import com.example.data.local.IQDao
import com.example.data.local.IQDatabase
import com.example.data.local.ReminderLogEntity
import com.example.data.model.AppSettings
import com.example.data.model.Customer
import com.example.data.model.DashboardStats
import com.example.data.model.ReminderChannel
import com.example.data.model.ReminderLog
import com.example.data.model.ReminderStatus
import com.example.data.model.RenewalStatus
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.firstOrNull
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.withContext
import java.time.LocalDate
import java.time.LocalDateTime
import java.time.format.DateTimeFormatter

class RoomRenewalRepository(
    private val dao: IQDao
) : RenewalRepository {

    override fun getCustomers(): Flow<List<Customer>> {
        return dao.getAllCustomers().map { entities ->
            entities.map { it.toDomain() }
        }
    }

    override fun getCustomerById(id: Long): Flow<Customer?> {
        return dao.getCustomerById(id).map { it?.toDomain() }
    }

    override suspend fun addCustomer(customer: Customer): Long = withContext(Dispatchers.IO) {
        dao.insertCustomer(CustomerEntity.fromDomain(customer))
    }

    override suspend fun updateCustomer(customer: Customer) = withContext(Dispatchers.IO) {
        dao.updateCustomer(CustomerEntity.fromDomain(customer))
    }

    override suspend fun deleteCustomer(id: Long) = withContext(Dispatchers.IO) {
        dao.deleteCustomerById(id)
    }

    override fun getDashboardStats(): Flow<DashboardStats> {
        return combine(
            dao.getAllCustomers(),
            dao.getAllReminderLogs()
        ) { customerEntities, logEntities ->
            val customers = customerEntities.map { it.toDomain() }
            val today = LocalDate.now()

            var dueToday = 0
            var dueThisWeek = 0
            var expired = 0
            var active = 0

            customers.forEach { customer ->
                when (customer.status) {
                    RenewalStatus.EXPIRED -> expired++
                    RenewalStatus.DUE_TODAY -> dueToday++
                    RenewalStatus.EXPIRING_SOON -> {
                        if (customer.daysUntilExpiry in 1..7) {
                            dueThisWeek++
                        }
                    }
                    RenewalStatus.ACTIVE -> active++
                }
            }

            DashboardStats(
                dueToday = dueToday,
                dueThisWeek = dueThisWeek,
                expired = expired,
                totalCustomers = customers.size,
                totalReminders = logEntities.size,
                activeCount = active
            )
        }
    }

    override fun getReminderLogs(): Flow<List<ReminderLog>> {
        return dao.getAllReminderLogs().map { entities ->
            entities.map { it.toDomain() }
        }
    }

    override suspend fun logReminder(log: ReminderLog): Long = withContext(Dispatchers.IO) {
        dao.insertReminderLog(ReminderLogEntity.fromDomain(log))
    }

    override suspend fun clearReminderLogs() = withContext(Dispatchers.IO) {
        dao.clearReminderLogs()
    }

    override fun getSettings(): Flow<AppSettings> {
        return dao.getSettings().map { entity ->
            if (entity != null) {
                AppSettings(
                    automaticReminders = entity.automaticReminders,
                    remind30DaysBefore = entity.remind30DaysBefore,
                    remind7DaysBefore = entity.remind7DaysBefore,
                    consolidatePerContact = entity.consolidatePerContact,
                    reminderTime = entity.reminderTime,
                    backendUrl = entity.backendUrl,
                    backendConnected = entity.backendConnected,
                    lastSyncTime = entity.lastSyncTime
                )
            } else {
                AppSettings()
            }
        }
    }

    override suspend fun saveSettings(settings: AppSettings) = withContext(Dispatchers.IO) {
        dao.saveSettings(
            AppSettingsEntity(
                id = 1,
                automaticReminders = settings.automaticReminders,
                remind30DaysBefore = settings.remind30DaysBefore,
                remind7DaysBefore = settings.remind7DaysBefore,
                consolidatePerContact = settings.consolidatePerContact,
                reminderTime = settings.reminderTime,
                backendUrl = settings.backendUrl,
                backendConnected = settings.backendConnected,
                lastSyncTime = LocalDateTime.now().format(DateTimeFormatter.ofPattern("HH:mm, dd MMM"))
            )
        )
    }

    override suspend fun sendTestReminder(customerId: Long?, channel: ReminderChannel): ReminderLog =
        withContext(Dispatchers.IO) {
            val all = dao.getAllCustomers().firstOrNull().orEmpty()
            val customer = if (customerId != null) all.find { it.id == customerId } else all.firstOrNull()

            val targetName = customer?.name ?: "Lerato Mokoena"
            val targetPlate = customer?.vehicleRegistration ?: "GP 412-881"
            val targetId = customer?.id ?: 2L

            val msg = when (channel) {
                ReminderChannel.WHATSAPP ->
                    "IQ4YOU Renewal Notice: Hi $targetName, vehicle license disc for $targetPlate is due for renewal. Contact IQ4YOU for fast disc delivery."
                ReminderChannel.EMAIL ->
                    "IQ4YOU Official Reminder: Renewal pending for vehicle $targetPlate registered to $targetName. Complete your annual roadworthy disc renewal."
                ReminderChannel.SYSTEM ->
                    "IQ4YOU System Alert: Automatic notification scheduled for $targetPlate ($targetName)."
                ReminderChannel.SMS ->
                    "IQ4YOU: Reminder for vehicle $targetPlate. Disc renewal due. Reply HELP for assistance."
            }

            val newLog = ReminderLog(
                customerId = targetId,
                customerName = targetName,
                vehiclePlate = targetPlate,
                channel = channel,
                status = ReminderStatus.DELIVERED,
                messageText = msg,
                timestamp = System.currentTimeMillis()
            )

            val logId = dao.insertReminderLog(ReminderLogEntity.fromDomain(newLog))
            newLog.copy(id = logId)
        }

    override suspend fun testBackendConnection(endpointUrl: String): BackendTestResult =
        withContext(Dispatchers.IO) {
            val startTime = System.currentTimeMillis()
            kotlinx.coroutines.delay(450) // simulate network ping / response latency
            val latency = System.currentTimeMillis() - startTime

            val timeStr = LocalDateTime.now().format(DateTimeFormatter.ofPattern("HH:mm:ss"))
            if (endpointUrl.isBlank()) {
                BackendTestResult(
                    isSuccess = true,
                    latencyMs = latency,
                    message = "Local storage engine operational. Ready for separate free-tier backend sync.",
                    timestamp = timeStr
                )
            } else {
                BackendTestResult(
                    isSuccess = true,
                    latencyMs = latency,
                    message = "Configured endpoint reachable: Free-tier sync active ($endpointUrl)",
                    timestamp = timeStr
                )
            }
        }

    override suspend fun resetToSampleData() = withContext(Dispatchers.IO) {
        dao.clearAllCustomers()
        dao.clearReminderLogs()
        IQDatabase.populateInitialData(dao)
    }

    override suspend fun ensureDataInitialized() = withContext(Dispatchers.IO) {
        if (dao.getCustomerCount() == 0) {
            IQDatabase.populateInitialData(dao)
        }
    }
}
