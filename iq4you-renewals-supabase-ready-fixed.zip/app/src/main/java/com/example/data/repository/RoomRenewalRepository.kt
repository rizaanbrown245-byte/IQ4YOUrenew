package com.example.data.repository

import com.example.data.local.AppSettingsEntity
import com.example.data.local.CustomerEntity
import com.example.data.local.IQDao
import com.example.data.local.IQDatabase
import com.example.data.local.ReminderLogEntity
import com.example.data.model.AppSettings
import com.example.data.model.Customer
import com.example.data.model.DashboardStats
import com.example.data.model.ReminderChannel
import com.example.data.model.ReminderLog
import com.example.data.model.ReminderStatus
import com.example.data.model.RenewalStatus
import com.example.data.remote.SupabaseRemote
import android.content.Context
import com.example.BuildConfig
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.firstOrNull
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.withContext
import java.time.LocalDate
import java.time.LocalDateTime
import java.time.format.DateTimeFormatter

class RoomRenewalRepository(
    private val dao: IQDao,
    context: Context
) : RenewalRepository {
    private val remote = SupabaseRemote(context.applicationContext)


    override fun getCustomers(): Flow<List<Customer>> {
        return dao.getAllCustomers().map { entities ->
            entities.map { it.toDomain() }
        }
    }

    override fun getCustomerById(id: Long): Flow<Customer?> {
        return dao.getCustomerById(id).map { it?.toDomain() }
    }

    override suspend fun addCustomer(customer: Customer): Long = withContext(Dispatchers.IO) {
        val id = dao.insertCustomer(CustomerEntity.fromDomain(customer))
        remote.upsertCustomer(CustomerEntity.fromDomain(customer.copy(id = id)))
        id
    }

    override suspend fun updateCustomer(customer: Customer) = withContext(Dispatchers.IO) {
        val entity = CustomerEntity.fromDomain(customer)
        dao.updateCustomer(entity)
        remote.upsertCustomer(entity)
    }

    override suspend fun deleteCustomer(id: Long) = withContext(Dispatchers.IO) {
        dao.deleteCustomerById(id)
        remote.deleteCustomer(id)
    }

    override fun getDashboardStats(): Flow<DashboardStats> {
        return combine(
            dao.getAllCustomers(),
            dao.getAllReminderLogs()
        ) { customerEntities, logEntities ->
            val customers = customerEntities.map { it.toDomain() }
            val today = LocalDate.now()

            var dueToday = 0
            var dueThisWeek = 0
            var expired = 0
            var active = 0

            customers.forEach { customer ->
                when (customer.status) {
                    RenewalStatus.EXPIRED -> expired++
                    RenewalStatus.DUE_TODAY -> dueToday++
                    RenewalStatus.EXPIRING_SOON -> {
                        if (customer.daysUntilExpiry in 1..7) {
                            dueThisWeek++
                        }
                    }
                    RenewalStatus.ACTIVE -> active++
                }
            }

            DashboardStats(
                dueToday = dueToday,
                dueThisWeek = dueThisWeek,
                expired = expired,
                totalCustomers = customers.size,
                totalReminders = logEntities.size,
                activeCount = active
            )
        }
    }

    override fun getReminderLogs(): Flow<List<ReminderLog>> {
        return dao.getAllReminderLogs().map { entities ->
            entities.map { it.toDomain() }
        }
    }

    override suspend fun logReminder(log: ReminderLog): Long = withContext(Dispatchers.IO) {
        val entity = ReminderLogEntity.fromDomain(log)
        val id = dao.insertReminderLog(entity)
        remote.upsertLog(entity.copy(id = id))
        id
    }

    override suspend fun clearReminderLogs() = withContext(Dispatchers.IO) {
        dao.clearReminderLogs()
        remote.clearLogs()
    }

    override fun getSettings(): Flow<AppSettings> {
        return dao.getSettings().map { entity ->
            if (entity != null) {
                AppSettings(
                    automaticReminders = entity.automaticReminders,
                    remind30DaysBefore = entity.remind30DaysBefore,
                    remind7DaysBefore = entity.remind7DaysBefore,
                    consolidatePerContact = entity.consolidatePerContact,
                    reminderTime = entity.reminderTime,
                    backendUrl = entity.backendUrl,
                    backendConnected = entity.backendConnected,
                    lastSyncTime = entity.lastSyncTime
                )
            } else {
                AppSettings()
            }
        }
    }

    override suspend fun saveSettings(settings: AppSettings) = withContext(Dispatchers.IO) {
        val entity = AppSettingsEntity(
            id = 1,
            automaticReminders = settings.automaticReminders,
            remind30DaysBefore = settings.remind30DaysBefore,
            remind7DaysBefore = settings.remind7DaysBefore,
            consolidatePerContact = settings.consolidatePerContact,
            reminderTime = settings.reminderTime,
            backendUrl = settings.backendUrl,
            backendConnected = settings.backendConnected,
            lastSyncTime = LocalDateTime.now().format(DateTimeFormatter.ofPattern("HH:mm, dd MMM"))
        )
        dao.saveSettings(entity)
        remote.upsertSettings(entity)
    }

    override suspend fun sendTestReminder(customerId: Long?, channel: ReminderChannel): ReminderLog =
        withContext(Dispatchers.IO) {
            val all = dao.getAllCustomers().firstOrNull().orEmpty()
            val customer = if (customerId != null) all.find { it.id == customerId } else all.firstOrNull()

            val targetName = customer?.name ?: "Lerato Mokoena"
            val targetPlate = customer?.vehicleRegistration ?: "GP 412-881"
            val targetId = customer?.id ?: 2L

            val msg = when (channel) {
                ReminderChannel.WHATSAPP ->
                    "IQ4YOU Renewal Notice: Hi $targetName, vehicle license disc for $targetPlate is due for renewal. Contact IQ4YOU for fast disc delivery."
                ReminderChannel.EMAIL ->
                    "IQ4YOU Official Reminder: Renewal pending for vehicle $targetPlate registered to $targetName. Complete your annual roadworthy disc renewal."
                ReminderChannel.SYSTEM ->
                    "IQ4YOU System Alert: Automatic notification scheduled for $targetPlate ($targetName)."
                ReminderChannel.SMS ->
                    "IQ4YOU: Reminder for vehicle $targetPlate. Disc renewal due. Reply HELP for assistance."
            }

            val newLog = ReminderLog(
                customerId = targetId,
                customerName = targetName,
                vehiclePlate = targetPlate,
                channel = channel,
                status = ReminderStatus.DELIVERED,
                messageText = msg,
                timestamp = System.currentTimeMillis()
            )

            val logId = logReminder(newLog)
            newLog.copy(id = logId)
        }

    override suspend fun testBackendConnection(endpointUrl: String): BackendTestResult =
        withContext(Dispatchers.IO) {
            val result = remote.testConnection()
            val timeStr = LocalDateTime.now().format(DateTimeFormatter.ofPattern("HH:mm:ss"))
            BackendTestResult(
                isSuccess = result.ok,
                latencyMs = result.latencyMs,
                message = result.message,
                timestamp = timeStr
            )
        }

    override suspend fun resetToSampleData() = withContext(Dispatchers.IO) {
        dao.clearAllCustomers()
        dao.clearReminderLogs()
        IQDatabase.populateInitialData(dao)
    }

    override suspend fun ensureDataInitialized() = withContext(Dispatchers.IO) {
        if (dao.getCustomerCount() == 0) {
            IQDatabase.populateInitialData(dao)
        }

        // Authenticate and synchronize. Local Room remains the source for the UI,
        // so the app continues to work when the network is unavailable.
        val auth = remote.signInAnonymously()
        if (auth.ok) {
            dao.getSettings().firstOrNull()?.let { current ->
                dao.saveSettings(current.copy(
                    backendUrl = BuildConfig.SUPABASE_URL,
                    backendConnected = true,
                    lastSyncTime = LocalDateTime.now().format(DateTimeFormatter.ofPattern("HH:mm, dd MMM"))
                ))
            }
            val remoteCustomers = remote.pullCustomers()
            if (remoteCustomers.isEmpty()) {
                dao.getAllCustomers().firstOrNull().orEmpty().forEach { remote.upsertCustomer(it) }
                dao.getAllReminderLogs().firstOrNull().orEmpty().forEach { remote.upsertLog(it) }
                dao.getSettings().firstOrNull()?.let { remote.upsertSettings(it) }
            } else {
                dao.clearAllCustomers()
                dao.insertCustomers(remoteCustomers)
                val remoteLogs = remote.pullLogs()
                dao.clearReminderLogs()
                if (remoteLogs.isNotEmpty()) dao.insertReminderLogs(remoteLogs)
                remote.pullSettings()?.let {
                    dao.clearSettings()
                    dao.saveSettings(it)
                }
            }
        }
    }
}
